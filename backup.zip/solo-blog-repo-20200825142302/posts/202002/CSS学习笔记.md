title: CSS 学习笔记
date: '2020-02-22 23:49:24'
updated: '2020-08-24 18:55:03'
tags: [前端, 学习笔记]
permalink: /articles/2020/02/22/1582386564521.html
---
### CSS

#### 基本知识

* CSS 也可以通过`<style> @import "path"; </style>` 的方式导入。
* CSS 每一对属性需要用`;` 隔开，最后一对可以不加。

#### CSS 选择器

* 并集选择器：`,`
  ```html
  p,span{
      color:red;
  }
  ```
* 交集选择器：`.`
  ```html
  <style>
      span.p1{
          color:red;
      }
  </style>
  <html>
      <body>
          <span>xxxx</span>
          <span class="p1">xxxx</span>
      </body>
  </html>
  ```
* 后代选择器：` `
  ```html
  #d1 span{}
  <div id="d1">
      <span></span>
  </div>
  <div>
      <span></span>
  </div>
  ```
* 子元素选择器：`>`
* 父元素选择器：`<`
* 相邻兄弟选择器：`+`
* 属性选择器：`a[href="zhi"]`，选择具有某种属性和某种值(可省略)的元素
* 伪类选择器：
  * `div:empty`，选择没有子元素的 div 元素
  * `p:not(.big, .medium)`：选择除了 class="big"，class="medium" 的 p 元素
* `<a>` 标签的伪类选择器：link、hover、active、visited
* 其他子元素选择器
  * `:first-child`：选择所有的第一个子元素
  * `p:first-child`：选择所有 p 为父元素第一个子元素的 p 元素
  * `div > p:first-child`：选择所有 p 是 div 的第一个子元素的 p 元素
  * `:last-child`：类似于 first-child
  * `:only-child`：选择父元素只有一个子元素的元素
  * `span:only-child`：选择父元素只有一个 span 的父元素的 span 元素
  * `ul > li:only-child`：选择 li 是 ul 唯一的子元素的 li 元素
  * `:nth-child(x)`：选择所有的第 x 个子元素，当 x="even" 时，表示偶数，odd 表示奇数
  * `:nth-last-child(x)`
* 选择器的优先级：内联(1000)>id 选择器(100)> 类和伪类选择器(10)> 元素选择器(1)> 通配*(0)> 继承的样式(没有)，当选择器包含多种选择器的时候，优先级相加，比如 p#p2 的优先级为 101，比#p2 高，但是不会超过他的最大数量级。
* 可在样式的最后添加！ important，则此时优先级最高。
  ```css
  .p1{
      background-color:greenyellow !important;
  }
  ```

#### CSS 属性

* 字体、文本
  * `font-size`：字体大小
  * `color`：文本颜色
  * `text-align`：对其方式
  * `line-height`：行高
* 背景：`background`
  * `background: url("img/logo.jpg") no-repeat center;`
* 边框：`border`，`border-radius` 边框弧度
* 尺寸：`width`、`height`
* `vertical-align:middle`：垂直居中
* `line-height`：可用于控制块元素中文字的垂直居中。
* 内边距 padding 默认情况下会影响盒子自身的大小。使用`box-sizing: border-box;` 可以解决此问题，让 width 和 height 就是最终盒子的大小。
* CSS 样式的继承：子元素会继承祖先元素的样式，但是背景相关的样式，边框相关的样式，定位相关的样式都不会被继承。

#### CSS 元素分类

* 块标签：div、p、h1-h6、hr、ul、ol、li、dl、dd、dt、form
  * 支持宽高，自上而下排列
  * 不受空格影响
  * 一般用于其他标签的容器
  * 默认宽度为 100%（独占一行）。
* 行内标签：**span**、i、**a**、b、strong、em、sub、sup、u、label、br、font
  * **不支持宽高**（宽高根据内容大小自动撑开），自左向右排列
  * 受空格影响
  * 不独占一行
* 行内块标签：img、textarea、input
  * **支持宽高**，自左向右排列
  * 受空格影响
  * 不独占一行
* 标签之间的转换
  * display：inline（转为行内元素）
  * inline-block（转为行内块元素）
  * block（转为块元素）
  * none（隐藏 不显示）

  > 注意：当元素浮动（float）时会转化成行内块元素特点。
  >

#### CSS 背景

| 属性 | 作用 | 值 |
| :- | :- | :- |
| background-color | 背景颜色 | 预定义的颜色值/十六进制/RGB代码 |
| background-image | 背景图片 | url(图片路径) |
| background-repeat | 是否平铺 | repeat/no-repeat/repeat-x/repeat-y |
| background-position | 背景位置 | length/position分别是x和y坐标 |
| background-attachment | 背景附着 | scroll（背景滚动）/fixed（背景固定） |
| 背景简写 | 书写更简单 | 背景颜色 背景图片地址 背景平铺 背景滚动 背景位置 |
| 背景色半透明 | 背景颜色半透明 | background:rgba(0,0,0,0.3); 后面必须是4个值 |

#### 定位

* position：定位方式
* static：静态定位（默认定位）
* relative：相对定位，内容元素相对于默认位置进行偏移，偏移后原来的位置依旧会被占用

  ```html
  <head>
      <style>
          div {
              width: 100px;
              height: 100px;
              border-style: dashed;
              border-color: green;
              border-width: 2px;
              text-align: center;
              line-height: 100px;
          }

          .position {
              left: 120px;
              top: 104px;
              position: relative;
          }
      </style>
  </head>
  <body>
      <div>1</div>
      <div class="position">2</div>
      <div>3</div>
  </body>
  ```
* absolute：绝对定位
* fixed：固定定位

#### 补充

* div 或 td 中内容过长，怎么以省略号显示
  ```css
  /* table添加style="table-layout: fixed" */
  /* td 或 div 添加 */
  .oneline {
      width: 100px;
      /* 规定段落中的文本不进行换行 */
      white-space: nowrap;
      /* 溢出的文字显示为省略号 */
      text-overflow: ellipsis;
      -o-text-overflow: ellipsis;
      /* 关闭滚动条 */
      overflow: hidden;
  }
  ```
  * 为 td 添加 title 属性可以做到鼠标覆盖显示全部
