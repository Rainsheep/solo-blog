title: 牛客多校第五次-G题-max
date: '2019-12-03 22:49:52'
updated: '2019-12-03 22:49:52'
tags: [acm, 数学问题]
permalink: /articles/2019/12/03/1575384591995.html
---
# 题目描述

Give two positive integer c, n. You need to find a pair of integer (a,b) satisfy 1&lt;=a,b&lt;=n and the greatest common division of a and b is c.And you need to maximize the product of a and b

# 输入描述:

The first line has two positive integer c,n

# 输出描述:

Output the maximum product of a and b.
If there are no such a and b, just output -1

# 示例 1

输入

```
2 4
```

输出

```
8
```

# 说明

```
a=2,b=4
```

# 备注:

```
1<=c,n<=10^9
```

# 题目描述

给定两个正整数 c,n，求一个数对 (a,b)，满足 1&lt;=a,b&lt;=n，且 gcd(a,b)=c
要求输出最大的 ab,不存在则输出-1
1&lt;=c,n&lt;=10^9

# 解题思路

首先 a 和 b 一定都是 c 的倍数，如果 n&lt;2c，那么选 a=b=c 最优
否则选 a=(n/c)*c , b=((n/c)-1)c

# 思路：

转化为 a'=a/c,,b'=b/c，a'*b'最大且 a' b'互质
相邻的两个数互质！则 a=a'*c,,b=b'*c，，a 与 b 的最大公约数为 c
需要注意 a==b 的情况和输出-1 的情况
总结：相邻的两个数互质！a' b'互质，则 a=a'*c,,b=b'*c，，a 与 b 的最大公约数为 c

```cpp
//牛客第五次多校G题
#include<bits/stdc++.h>
using namespace std;
int main() {
	int c, n;
	while (cin >> c >> n) {
		int a, b;
		if (c > n)cout << "-1" << endl;
		else if (n < 2 * c)cout << 1LL * c * c << endl;
		else {
			b = (int)(n / c)*c;
			a = b - c;
			cout << 1LL * a * b << endl;
		}
 
	}
}

```
