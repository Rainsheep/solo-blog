title: Java 格式化显示金额
date: '2020-03-31 02:00:49'
updated: '2020-03-31 02:00:49'
tags: [Java]
permalink: /articles/2020/03/31/1585591249751.html
---
```java
DecimalFormat decimalFormat = new DecimalFormat("###,###.00");
System.out.println(decimalFormat.format(1002200999.22323));    //1,002,200,999.22
```
