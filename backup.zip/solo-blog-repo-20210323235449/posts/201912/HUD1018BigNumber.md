title: HUD 1018 Big Number
date: '2019-12-03 13:07:47'
updated: '2019-12-03 13:07:47'
tags: [acm, 数学问题]
permalink: /articles/2019/12/03/1575349667467.html
---
求一个数阶乘的位数...一开始没思路。。。x表示位数，则x-1=lg（n!），后面可变为加法。。。很水，注意int 和double的转换
```C++
#include<iostream>
#include<string>
#include<vector>
#include<math.h>
using namespace std;
int main()
{
	int n,k,i;
	double l;
	cin>>n;
	while(n--)
	{
		l=0;
		cin>>k;
		for(i=1;i<=k;i++)
		l+=log10(i);
		l=l+1;
		printf("%d\n",(int)l);
	}
}


```
