title: 搭建frp内网穿透
date: '2020-01-28 22:10:51'
updated: '2020-01-28 22:15:07'
tags: [Linux]
permalink: /articles/2020/01/28/1580220651647.html
---
参考链接：
[fatedier/frp](https://github.com/fatedier/frp#visit-your-web-service-in-lan-by-custom-domains)
[内网穿透工具-frp傻瓜式搭建教程](https://blog.csdn.net/m0_37499059/article/details/79587771)
[手把手教你用frp实现内网穿透，进行远程桌面和http访问](https://www.jianshu.com/p/a6e9627dbe29)

frp 下载链接：
[https://github.com/fatedier/frp/releases](https://github.com/fatedier/frp/releases)
[frp0.31.1linuxamd64.zip](https://img.hacpai.com/file/2020/01/frp0.31.1linuxamd64-ced6a672.zip)
[frp0.31.1windowsamd64.zip](https://img.hacpai.com/file/2020/01/frp0.31.1windowsamd64-0e478310.zip)

![版本介绍](https://raw.githubusercontent.com/Rainsheep/pic-bed/master/img/2020-01-28+19:07:53+p_20200128070751.png)

其中 windows_386 表示 windows 平台 32 位机器;
windows_amd64 表示 windows 平台 64 位机器;
linux_386 表示 Linux 平台 32 位机器;
linux_amd64 表示 Linux 平台 64 位机器 **（Linux 平台一般使用这个）**
arm 代表嵌入式;
别的代表别的平台，可能是手机等不同环境;
**Linux 通过指令 arch 可以查看 CPU 体系结构，显示 x86_64 一般使用 amd64;**

> 搭建环境：
>1. CentOS 服务器（阿里云）
>2. 二级域名 frp.rainsheep.top 解析至服务器

# 通过自定义域名访问

### 1. 将 Linux 的 frp 工具传至服务器

### 2. 配置服务器端 frps.ini 配置文件

![](https://raw.githubusercontent.com/Rainsheep/pic-bed/master/img/2020-01-28+19:17:50+p_20200128071748.png)

> bind_port 代表软件端口;
> vhost_http_port 代表虚拟主机的端口，就是当通过域名访问内网主机中的 Web 项目时需要用到的端口。

### 3. 运行服务端

运行指令：`./frps -c ./frps.ini`
启动以后如下图所示：
![](https://raw.githubusercontent.com/Rainsheep/pic-bed/master/img/2020-01-28+19:24:38+p_20200128072432.png)

> 此窗口不可以关闭，此处通过 screen 实现后台运行，参考[Centos下screen命令](https://www.rainsheep.top/articles/2020/01/04/1578152561987.html)

### 4. 配置客户端

* 解压客户端工具（我为 windows10）
* 配置 frpc.ini 文件
  ```
  [common]
  server_addr = 39.105.149.231
  server_port = 7000

  [web]
  type = http
  local_ip = 127.0.0.1
  local_port = 8080
  custom_domains = frp.rainsheep.top
  ```

  > server_addr = 服务器 IP
  > server_port = 服务器配置文件中的 bind_port
  > local_port = 要访问的本地 Web 服务器端口
  > custom_domains = 自定义域名（前面已经解析至服务器）
  >

### 4. 客户端启动 frp

打开 cmd→进入 frp 文件夹 →输入命令`frpc.exe -c ./frpc.ini`
![](https://raw.githubusercontent.com/Rainsheep/pic-bed/master/img/2020-01-28+19:41:58+p_20200128074128.png)

### 5. 测试

本地访问：
![](https://raw.githubusercontent.com/Rainsheep/pic-bed/master/img/2020-01-28+19:43:25+p_20200128074315.png)
远程访问：
![](https://raw.githubusercontent.com/Rainsheep/pic-bed/master/img/2020-01-28+19:43:50+p_20200128074348.png)

# 通过 RDP 连接 Windows 桌面

### 1. 服务器端设置

服务器端的设置与上边设置相同，可以不更改，此项中服务器端的 vhost_http_port 不会用到，但可以设置以后放那不管。

### 2. 客户端配置

配置文件：

```
[common]
server_addr = 39.105.149.231
server_port = 7000

[RDP]
type = tcp
local_ip = 0.0.0.0
local_port = 3389
remote_port = 6000
```

> remote_port 就是远程连接桌面的时候需要连接的窗口

允许远程桌面连接：
计算机 →属性 →远程设置 →勾选远程协助中允许远程协助连接这台计算机 →勾选远程桌面中允许远程连接到此计算机

![](https://raw.githubusercontent.com/Rainsheep/pic-bed/master/img/2020-01-28+21:57:35+p_20200128095733.png)

> 远程连接需要账号密码，如果不知道账号密码，此电脑 →管理 →本地用户和组 →用户 →Administrator→设置密码

### 3. 远程连接

使用：服务器 IP:remote_port 即可
![](https://raw.githubusercontent.com/Rainsheep/pic-bed/master/img/2020-01-28+22:04:46+p_20200128100442.png)

# 通过 SSH 连接内网 Linux

### 1. 服务器端配置

与上类似

### 2. 客户端配置

```
[common]
server_addr = 39.105.149.231
server_port = 7000

[ssh]
type = tcp
local_ip = 127.0.0.1
local_port = 22
remote_port = 6000
```

运行方式：
`./frpc -c ./frpc.ini`

### 3. 远程连接方式

`ssh -oPort=6000 username@39.105.149.231`

# 综上

本地文件可以配置为一个文件：
```
[common]
server_addr = 39.105.149.231
server_port = 7000

[web]
type = http
local_ip = 127.0.0.1
local_port = 8080
custom_domains = frp.rainsheep.top

[RDP]
type = tcp
local_ip = 0.0.0.0
local_port = 3389
remote_port = 6000

[ssh]
type = tcp
local_ip = 127.0.0.1
local_port = 22
remote_port = 6001
```

>ssh的remote_port改为6001为了防止远程端口冲突（与RDP冲突）
