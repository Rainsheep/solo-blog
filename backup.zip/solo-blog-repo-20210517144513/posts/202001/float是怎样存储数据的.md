title: float是怎样存储数据的
date: '2020-01-06 12:41:44'
updated: '2020-01-06 12:41:44'
tags: [java]
permalink: /articles/2020/01/06/1578285704714.html
---
参考链接：
[Java语言中：float、double数据类型在内存中是如何存储的](https://www.cnblogs.com/Java-Script/p/11123897.html)
