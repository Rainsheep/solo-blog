title: Ubuntu16.04安装微信
date: '2020-07-17 10:35:38'
updated: '2020-07-20 21:04:33'
tags: [Linux]
permalink: /articles/2020/07/17/1594953338426.html
---
参考：[Ubuntu18.04使用deepin-wine安装微信](http://chenzhen.online/2020/04/20/Ubuntu18-04%E4%BD%BF%E7%94%A8deepin-wine%E5%AE%89%E8%A3%85%E5%BE%AE%E4%BF%A1/)

本文主要介绍在Ubuntu 16.04下使用deepin-wine安装微信的教程

> 系统语言：中文

### 一、deepin-wine的安装

> [https://github.com/wszqkzqk/deepin-wine-ubuntu](https://github.com/wszqkzqk/deepin-wine-ubuntu)

在链接中下载 `.zip`压缩包并解压;

```
cd deepin-wine-ubuntu-master
sh install_2.8.22.sh
```

安装成功;

可以在路径 `/opt/deepwine/`查看安装的内容;

查看版本:`deepin-wine --version`

### 二、安装微信

> [http://mirrors.aliyun.com/deepin/pool/non-free/d/deepin.com.wechat/](http://mirrors.aliyun.com/deepin/pool/non-free/d/deepin.com.wechat/)

在上面链接页面下下载 `deepin.com.wechat_2.6.8.65deepin0_i386.deb`

然后安装:

```
cd Downloads
sudo dpkg -i deepin.com.wechat_2.6.8.65deepin0_i386.deb
```

可以在 `/opt/deepinwine/apps`路径下看到 `/opt/deepinwine/apps`相关文件夹

然后,使用 `Win+A`搜索 `WeChat`既可打开并登录微信
