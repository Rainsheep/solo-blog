title: Ubuntu 创建快捷方式
date: '2020-08-15 19:11:22'
updated: '2020-08-15 19:11:22'
tags: [待分类]
permalink: /articles/2020/08/15/1597489882456.html
---
参考文献：

[Ubuntu18.04 创建桌面快捷方式](https://blog.csdn.net/u010071211/article/details/81114269)

[ubuntu18.04向添加快捷方式](https://blog.csdn.net/weixin_39394526/article/details/87938718?utm_medium=distribute.pc_relevant.none-task-blog-BlogCommendFromMachineLearnPai2-2.channel_param&depth_1-utm_source=distribute.pc_relevant.none-task-blog-BlogCommendFromMachineLearnPai2-2.channel_param)

[Linux桌面快捷方式 Desktop Entry 详解](https://blog.csdn.net/xkzju2010/article/details/45823533)

快捷方式在 `/usr/share/applications/` 目录下 `.desktop` 结尾的文件。

一般起名为 `software_name.desktop`

内容如下：

```
[Desktop Entry]
Version=1.0                                       # 软件的版本
Name=pycharm-2018.3.4                             # 软件显示的名称   
Exec=/opt/pycharm-2018.3.4/bin/pycharm.sh         # 开启软件的脚本或启动文件
Icon=/opt/pycharm-2018.3.4/bin/pycharm.png        # 软件的 logo
Terminal=false                                    # 是否需要在终端窗口运行
Type=Application                                  # 类型
Categories=Application;                           # 分
```

win+A 搜索即可
