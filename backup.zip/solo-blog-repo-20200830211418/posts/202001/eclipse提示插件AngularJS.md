title: eclipse提示插件：AngularJS
date: '2020-01-01 13:20:53'
updated: '2020-01-01 13:20:53'
tags: [软件教程]
permalink: /articles/2020/01/01/1577856053011.html
---
## 参考链接
[解决eclipse中没有js代码提示的问题](https://www.jb51.net/article/148556.htm)
[Eclipse中添加jQuery提示（angularjs插件）](https://blog.csdn.net/spectre_win/article/details/88826225)

## 作用
无论在js、html、jsp文件中都可以进行js代码的提示

## 安装方法
打开eclipse→help→install new software→add
name:angularjs
location:http://oss.opensagres.fr/angularjs-eclipse/1.2.0/ 
全选→下一步→重启eclipse→选中要用angularjs插件的项目，右键–Configure–Convent to Angularjs project→确定即可使用



