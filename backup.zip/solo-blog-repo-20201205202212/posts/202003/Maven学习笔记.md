title: Maven 学习笔记
date: '2020-03-01 14:24:45'
updated: '2020-03-02 13:02:45'
tags: [Java, 学习笔记]
permalink: /articles/2020/03/01/1583043885121.html
---
### 1. Maven 基础

* Maven 是一个项目管理工具，它包含了一个 项目对象模型 (POM：Project Object Model)，一组标准集合，一个项目生命周期 (Project Lifecycle)，一个依赖管理系统(Dependency Management System)，和用来运行定义在生命周期阶段(phase)中插件(plugin)目标(goal)的逻辑。
* Maven 可以解决的问题：

  * jar 包管理
  * Java 文件编译
  * 单元测试
  * 项目打包
* Maven 的依赖管理：maven 工程中不直接将 jar 包导入到工程中，而是通过在 pom.xml 文件中添加所需 jar
  包的坐标，这样就很好的避免了 jar 直接引入进来，在需要用到 jar 包的时候，只要查找 pom.xml 文件，再通过 pom.xml 文件中的坐标，到一个专门用于”存放 jar 包的仓库”(maven 仓库)中根据坐标从而找到这些 jar 包，再把这些 jar 包拿去运行。
* 项目的一键构建：

  * 项目从编译、测试、运行、打包、安装 ，部署整个过程都交给 maven 进行管理，这个过程称为构建。
  * 一键构建：指的是整个构建过程，使用一个 maven 命令就可以轻松完成整个工作。
* Maven 仓库![](https://raw.githubusercontent.com/Rainsheep/pic-bed/master/img/2020-03-01+02:25:43+maven仓库的种类和关系.png)

  * 本地仓库：用来存储从远程仓库或中央仓库下载的插件和 jar 包，项目使用的一些插件或 jar 包，
    优先从本地仓库查找，默认本地仓库位置在 ${user.dir}/.m2/repository，${user.dir}表示 windows 用户目录。
  * 远程仓库：如果本地需要插件或者 jar 包，本地仓库没有，默认去远程仓库下载。远程仓库可以在互联网内也可以在局域网内。
  * 中央仓库 ：在 maven 软件中内置一个远程仓库地址 `http://repo1.maven.org/maven2` ，它是中央仓库，服务于整个互联网，它是由 Maven 团队自己维护，里面存储了非常全的 jar 包，它包含了世界上大部分流行的开源项目构件。
* 全局 setting 与用户 setting

  maven 仓库地址、私服等配置信息需要在 setting.xml 文件中配置，分为全局配置和用户配置。
  在 maven 安装目录下的有 conf/setting.xml 文件，此 setting.xml 文件用于 maven 的所有 project
  项目，它作为 maven 的全局配置。
  如需要个性配置则需要在用户配置中设置，用户配置的 setting.xml 文件默认的位置在：${user.dir}
  /.m2/settings.xml 目录中,${user.dir} 指 windows 中的用户目录。
  maven 会先找用户配置，如果找到则以用户配置文件为准，否则使用全局配置文件。
* Maven 工程的目录结构

  * ![](https://raw.githubusercontent.com/Rainsheep/pic-bed/master/img/2020-03-01+02:40:07+p_20200301024004.png)
  * ![](https://raw.githubusercontent.com/Rainsheep/pic-bed/master/img/2020-03-01+02:42:17+p_20200301024150.png)
  * 如果是普通的 Java 项目，那么就没有 webapp 目录。
* mvn 命令

  * ` tomcat:run` ：进入 maven 工程目录（当前目录有 pom.xml 文件），运行 tomcat:run 命令。会部署项目并给出访问地址。
  * `compile`：compile 是 maven 工程的编译命令，作用是将 src/main/java 下的文件编译为 class 文件输出到 target 目录下。
  * `test`：test 是 maven 工程的测试命令 `mvn test`，会执行 src/test/java 下的单元测试类。此命令执行时会自动执行 compile 命令。
  * `clean`：clean 是 maven 工程的清理命令，执行 clean 会删除 target 目录及内容，清理编译信息。
  * `package`：package 是 maven 工程的打包命令，对于 Java 工程执行 package 打成 jar 包，对于 Web 工程打成 war 包。此命令会自动执行 compile 和 test 命令。
  * `install`：install 是 maven 工程的安装命令，执行 install 将 maven 打成 jar 包或 war 包发布到本地仓库。此命令会执行 compile，test，package 命令。
  * `deploy`：部署，运行此命令前需要先配置，会先执行 compile、test、package、install。
* maven 生命周期

  * maven 有三个生命周期，清理生命周期，默认生命周期，站点生命周期。![](https://raw.githubusercontent.com/Rainsheep/pic-bed/master/img/2020-03-01+03:16:18+maven生命周期.png)
* maven 概念模型图![](https://raw.githubusercontent.com/Rainsheep/pic-bed/master/img/2020-03-01+03:21:23+maven概念模型图.png)
* IDEA → Settings → Maven → Runner → VM Options:-DarchetypeCatalog=internal，此参数确保不联网的情况下 IDEA 也能创建 Maven 工程。
* 使用 IDEA 提供的骨架创建 Maven 的 Java 工程，`maven-archetype-quickstart`

  * 如需要，在 main 目录下手动创建 resources 目录，并标记为资源文件夹。
* 不使用骨架的时候会创建一个跟 maven 的 Java 工程标准目录的工程，包括 resources，推荐不使用骨架创建 maven 的 Java 工程。
* 使用 IDEA 提供的骨架创建 Maven 的 Web 工程，`maven-archetype-webapp`

  * 需要在 main 下创建 Java 目录，并标记为 Sources Root
  * Project Structs → model → Source Root 的对勾勾上
* 如在 pom.xml 中需要查找 jar 包的版本信息，去 maven 中央仓库，官方有每个版本的配置信息，贴过来会自动开始下载。
* 可以点击这个图标输入命令，比如 `tomcat:run` ![](https://raw.githubusercontent.com/Rainsheep/pic-bed/master/img/2020-03-01+18:37:17+p_20200301063714.png)
* tomcat:run 运行项目的时候，Tomcat 插件所用的 jar 包与 pom.xml 中配置的 jar 冲突(servlet 需要用此包，所以配置)，此时，可以用 scope 标签配置 pom 中 jar 包的作用域为 provided，表示只在写代码的时候起作用。
* Junit 作用域改为 test
* maven 内置 Tomcat 插件为 6.0 版本，不支持 jdk8，需要改为 tomcat7，运行命令是 `tomcat7:run`

  ```xml
  <plugin>
    <groupId>org.apache.tomcat.maven</groupId>
    <artifactId>tomcat7-maven-plugin</artifactId>
    <version>2.2</version>
  </plugin>
  ```
* 自定义模板：settings → Live Templates，定义完以后需要添加要在什么文件使用，可以自定义上述模板。
* maven 调试：运行配置 → 添加 Maven →填写运行命令![](https://raw.githubusercontent.com/Rainsheep/pic-bed/master/img/2020-03-01+13:54:13+p_20200301015410.png)

  ![](https://raw.githubusercontent.com/Rainsheep/pic-bed/master/img/2020-03-01+13:55:20+p_20200301015517.png)

  然后就可以运行和调试了。
* pom 基本配置：

  * \<project > ：文件的根节点 .
  * \<modelversion > ： pom.xml 使用的对象模型版本
  * \<groupId > ：组织名称 + 项目名称
  * \<artifactId > ：模块名称，子项目名或模块名称
  * \<version > ：产品的版本号 ，snapshot 为快照版本即非正式版本，release 为正式发布版本。
  * \<packaging > ：打包类型，一般有 jar、war、pom 等
  * \<name > ：项目的显示名，常用于 Maven 生成的文档。
  * \<description > ：项目描述，常用于 Maven 生成的文档。
  * \<dependencies> ：项目依赖构件配置，配置项目依赖构件的坐标
  * \<build> ：项目构建配置，配置编译、运行插件等。
* 依赖范围：

  * compile：编译范围，指 A 在编译时依赖 B，此范围为默认依赖范围。编译范围的依赖会用在
    编译、测试、运行，由于运行时需要所以编译范围的依赖会被打包。
  * provided：provided 依赖只有在当 JDK 或者一个容器已提供该依赖之后才使用， provided 依
    赖在编译和测试时需要，在运行时不需要，比如：servlet API 被 Tomcat 容器提供。
  * runtime：runtime 依赖在运行和测试系统的时候需要，但在编译的时候不需要。比如：JDBC
    的驱动包。由于运行时需要所以 runtime 范围的依赖会被打包。
  * test：test 范围依赖 在编译和运行时都不需要，它们只有在测试编译和测试运行阶段可用，
    比如：junit。由于运行时不需要所以 test 范围依赖不会被打包。
  * system：system 范围依赖与 provided 类似，但是你必须显式的提供一个对于本地系统中 JAR
    文件的路径，需要指定 systemPath 磁盘路径，system 依赖不推荐使用。
  * ![](https://raw.githubusercontent.com/Rainsheep/pic-bed/master/img/2020-03-01+14:09:06+p_20200301020817.png)
* 热部署：maven+tomcat 插件 +Jrebel 实现热部署：Jrebel 启动项目，改变类以后，Ctrl+f9 构建项目，触发 Jrebel 重新加载，直接刷新网页即可。
* 关于 target 目录，maven 运行时的目录结构。
  * target 用于存放编译、打包后的输出文件，tomcat 的配置也在这里面。
  * 对于静态资源，运行时并不放入target 目录，而是还在webapp 目录下，运行时直接访问 webapp 下的静态资源文件。(tomcat插件运行项目，不重启服务器，修改静态资源，没有缓存的情况下，可以加载，说明直接访问，不需要重新部署静态文件)
  * 对于 JSP 文件，则将编译后的文件放置在 `target\tomcat\work` 目录下。

