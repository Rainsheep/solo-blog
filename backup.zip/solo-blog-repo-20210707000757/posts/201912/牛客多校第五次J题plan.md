title: 牛客多校第五次-J题-plan
date: '2019-12-03 22:52:02'
updated: '2019-12-03 22:52:02'
tags: [acm]
permalink: /articles/2019/12/03/1575384722059.html
---
# 题目描述

There are n students going to travel. And hotel has two types room:double room and triple room. The price of a double room is p2 and the price of a triple room is p3

Now you need to calulate the minimum total cost of these students.

# 输入描述:

The first line has three integers n, p2, p3

# 输出描述:

Output the minimum total cost.

# 示例 1

输入

```
4 2 3
```

输出

```
4
```

# 示例 2

输入

```
5 1 3
```

输出

```
3
```

# 备注:

```
1<=n<=10^9
1<=p2,p3<=10^9
```

# 题目描述

n 个人出去玩，给定双人房和三人房的价格，求最少的住宿花费
1&lt;=n&lt;=10^9

# 解题思路

脑补一下可以发现：最后答案一定是几乎全选性价比最高的那种房间
然后再加上几间其他的
所以二人间和三人间里数量用的最少的房间不会超过 3
枚举一下用了几间就好了

一开始，枚举的剩余人，题解枚举最少的那个房间，很 NB

```cpp
int main() {
	int n, p2, p3;
	cin >> n >> p2 >> p3;
	LL ans = 1LL << 60;
	//+2是多的人也需要一个房间，max的作用是，防止剩余人数出现负数情况
	for (int i = 0; i < 5; i++)ans = min(ans, 1LL * p2*i + 1LL * max(0, (n - i * 2 + 2) / 3)*p3);
	for (int i = 0; i < 5; ++i)ans = min(ans, 1LL * p3*i + 1LL * max(0, (n - i * 3 + 1) / 2)*p2);
	cout << ans << endl;
}
```
