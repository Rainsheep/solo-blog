title: 全排列 java 实现
date: '2021-06-22 11:10:30'
updated: '2021-06-22 11:10:30'
tags: [java]
permalink: /articles/2021/06/22/1624331430103.html
---
```java
public boolean nextPermutation(int[] nums) {
    int n = nums.length;
    int i = n - 2;
    // 找到倒数第一个前面比后面小的元素
    while (i >= 0 && nums[i] >= nums[i + 1]) {
        i--;
    }
    // 已经是最大排列，没有下一个全排列
    if (i < 0) {
        return false;
    }
    // 从后往前找到第一个大于 nums[i] 的元素
    int j = n - 1;
    while (j >= 0 && nums[i] >= nums[j]) {
        j--;
    }
    swap(nums, i, j);
    reverse(nums, i + 1);
    return true;
}

// 交换 数组 i j 位置
public void swap(int[] arr, int i, int j) {
    int temp = arr[i];
    arr[i] = arr[j];
    arr[j] = temp;
}

// 从 start 位置反转数组
public void reverse(int[] arr, int start) {
    int left = start, right = arr.length - 1;
    while (left < right) {
        swap(arr, left, right);
        left++;
        right--;
    }
}
```
