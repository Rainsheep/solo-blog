title: Vue 学习笔记 简略
date: '2020-03-18 18:56:12'
updated: '2020-12-04 00:20:19'
tags: [学习笔记, 前端]
permalink: /articles/2020/03/18/1584528972534.html
---
### 1. VueJS 概述与快速入门

* Vue.js 是一个构建数据驱动的 web 界面的渐进式框架。
* MVVM 模式：Model-View-ViewModel，MVVM 就是将其中的 View 的状态和行为抽象化，让我们将视图 UI 和业务逻辑分开。
* Vue.js 是一个提供了 MVVM 风格的双向数据绑定的 Javascript 库，专注于View 层。它的核心是MVVM 中的 VM，也就是 ViewModel。ViewModel 负责连接 View 和 Model，保证视图和数据的一致性。
* 快速入门

  ```html
  <!DOCTYPE html>
  <html>
  	<head>
  		<meta charset="utf-8" />
  		<title>快速入门</title>
  		<script src="js/vuejs-2.5.16.js"></script>
  	</head>
  	<body>
  		<div id="app">
  			{{message}}<!--Vue的插值表达式，把data中定义的数据显示到此处-->
  		</div>
  	</body>
  	<script>
  		//view model
  		//创建Vue对象
  		new Vue({
  			el:"#app",//由vue接管id为app区域
  			data:{
  			    message:"Hello Vue!  EESY"//注意：此处不要加分号
  			}
  		});
  	</script>
  </html>
  ```

### 2. Vue 语法

* 双括号中可以写单个表达式，变量、三目运算符等，不能用来声明变量，不能写 if 语句。
* v-on：可以用 v-on 指令监听 DOM 事件，并在触发时运行一些 JS 代码。
* v-on:click 点击事件，也可以写成 @click

  * ```html
    <body>
    	<div id="app">
    		{{message}}
    		<button v-on:click="fun1">vue的onclick</button>
    	</div>
    </body>
    <script>
    	//view model
    	new Vue({
    		el:"#app",
    		data:{
    			message:"Hello Vue!"
    		},
    		methods:{
    			fun1:function () {
    				alert(1);
    			}
    		}
    	});
    </script>
    ```
  * 当方法有参数时

    ```html
    <body>
    <div id="app">
        {{message}}
        <button v-on:click="fun1('good')">vue的onclick</button>
    </div>
    </body>
    <script>
        //view model
        new Vue({
            el: "#app",
            data: {
                message: "Hello Vue!"
            },
            methods: {
                fun1: function (msg) {
                    this.message = msg;
                }
            }
        });
    </script>
    ```
* v-on:keydown 键盘事件

  ```html
  <body>
  <div id="app">
      <input type="text" v-on:keydown="fun($event)">
  </div>
  </body>
  <script>
      //view model
      new Vue({
          el: "#app",
          methods: {
              //$event 它是vue中的事件对象，和传统js的event对象是一样的
              fun: function (event) {
                  if (event.keyCode < 48 || event.keyCode > 57) {
                      //不让键盘起作用
                      event.preventDefault();
                  }
              }
          }
      });
  </script>
  ```
* `event.stopPropagation()`：停止事件的传播，接下来的事件不再执行。
* Vue.js 为 v-on 提供了事件修饰符来处理 DOM 事件细节，如 event.preventDefault() 或 event.stopPropagation() 的修饰符为 `.stop` 和 `.prevent`

  ```html
  <body>
  <div id="app">
      <div @mouseover="fun1" id="div">
          <textarea @mouseover.stop="fun2">这是一个文件域</textarea>
      </div>
  </div>
  </body>
  <script>
      //view model
      new Vue({
          el: "#app",
          methods: {
              fun1: function () {
                  alert("div");
              },
              fun2: function () {
                  alert("textarea");
              }
          }
      });
  </script>
  ```

  修饰符还有 `.capture`、`.self`、`.once`
* 按键修饰符：Vue 允许为 v-on 在监听键盘事件时添加按键修饰符

  * 按键修饰符有 `.enter`、`.tab`、`.delete`、`.esc`、`.space`、`.up`、`.down`、`.left`、`.right`、`.ctrl`、`.alt`、`.shift`、`.meta`
  * ```html
    <body>
    <div id="app">
        <input type="text" @keyup.enter="fun1">
    </div>
    </body>
    <script>
        //view model
        new Vue({
            el: "#app",
            methods: {
                fun1: function () {
                    alert("你按了回车");
                }
            }
        });
    </script>
    ```
* v-text 和 v-html：相当于 JQuery 的 `.text()` 和 `.html()`

  ```html
  <body>
  <div id="app">
      <div v-html="message"></div>
      <div v-text="message"></div>
  </div>
  </body>
  <script>
      //view model
      new Vue({
          el: "#app",
          data: {
              message: "<h1>TEST</h1>"
          }
      });
  </script>
  ```
* v-bind：差值语法不能作用在 HTML 特性上，应该使用 v-bind 指令，v-bind: 可以简写为 :

  ```html
  <body>
  <div id="app">
      <font v-bind:color="ys1">Test</font>
      <font :color="ys1">Test</font>
  </div>
  </body>
  <script>
      //view model
      new Vue({
          el: "#app",
          data: {
              ys1:"red"
          }
      });
  </script>
  ```
* v-for 遍历数组

  ```html
  <body>
  <div id="app">
      <ul>
          <li v-for="(item,index) in arr">{{item}}={{index}}</li>
      </ul>
  </div>
  </body>
  <script>
      //view model
      new Vue({
          el: "#app",
          data: {
              arr: [1, 2, 3, 4, 5]
          }
      });
  </script>
  ```
* v-for 遍历 JSON

  ```html
  <body>
  <div id="app">
      <ul>
          <li v-for="(key,value) in product">{{key}}==={{value}}</li>
      </ul>
  </div>
  </body>
  <script>
      //view model
      new Vue({
          el: "#app",
          data: {
              product:{
                  id:1,
                  name:"笔记本电脑",
                  price:5000
              }
          }
      });
  </script>
  ```
* v-for 操作对象数组

  ```html
  <body>
  <div id="app">
      <table border="1">
          <tr>
              <td>序号号</td>
              <td>编号</td>
              <td>名称</td>
              <td>价格</td>
          </tr>
          <tr v-for="(product,index) in products">
              <td>{{index+1}}</td>
              <td>{{product.id}}</td>
              <td>{{product.name}}</td>
              <td>{{product.price}}</td>
          </tr>
      </table>
  </div>
  </body>
  <script>
      //view model
      new Vue({
          el: "#app",
          data: {
              products: [
                  {id: 1, name: "笔记本电脑", price: 5000},
                  {id: 2, name: "手机", price: 3000},
                  {id: 3, name: "电视", price: 4000},
              ]
          }
      });
  </script>
  ```
* v-model：取对象的值

  ```html
  <body>
  <div id="app">
      <input type="text" v-model="user.username">
      <br>
      <input type="text" v-model="user.password">
  </div>
  </body>
  <script>
      //view model
      new Vue({
          el: "#app",
          data: {
              user: {
                  username: "admin",
                  password: "123456"
              }
          }
      });
  </script>
  ```
* v-if 和 v-show

  * v-if 是根据表达式的值来决定是否渲染元素
  * v-show是根据表达式的值来切换元素的display css属性(是否显示)
  * ```html
    <body>
    <div id="app">
        <span v-if="flag">TEST1</span><br>
        <span v-show="flag">TEST2</span><br>
        <button @click="toggle">切换</button><br>
    </div>
    </body>
    <script>
        //view model
        new Vue({
            el:"#app",
            data:{
                flag:false
            },
            methods:{
              toggle:function () {
                  this.flag=!this.flag;
              }
            }
        });
    </script>
    ```

### 3. VueJS 生命周期

![](https://raw.githubusercontent.com/Rainsheep/pic-bed/master/img/2020-03-16+16:47:59+331769-20180909094731362-16918169.png)

* vue对象初始化过程中，会执行到 beforeCreate,created,beforeMount,mounted

  * beforeCreate：数据还没有监听，没有绑定到 vue 对象实例，同时也没有挂载对象
  * created：数据已经绑定到了对象实例，但是还没有挂载对象
  * beforeMount：模板已经编译好了，根据数据和模板已经生成了对应的元素对象，将数据对象关联到了对象的 el 属性，el 属性是一个 HTMLElement 对象，也就是这个阶段，vue 实例通过原生的 createElement 等方法来创建这个 html 片段，准备注入到我们 vue 实例指明的el属性所对应的挂载点
  * mounted：将 el 的内容挂载到了 el，相当于我们在 jquery 执行了\$(el).html(el),生成页面上真正的dom，我们就会发现 dom 的元素和我们 el 的元素是一致的。在此之后，我们能够用方法来获取到 el 元素下的 dom 对象，并进行各种操作
  * 当我们的 data 发生改变时，会调用 beforeUpdate 和 updated 方法
    * beforeUpdate ：数据更新到 dom 之前，我们可以看到 \$el 对象已经修改，但是我们页面上 dom 的数据还没有发生改变
    * updated：dom结构会通过虚拟 dom 的原则，找到需要更新页面 dom 结构的最小路径，将改变更新到 dom上面，完成更新
  * beforeDestroy,destroed：实例的销毁，vue 实例还是存在的，只是解绑了事件的监听还有 watcher 对象数据与 view 的绑定，即数据驱动
* ```html
  <div id="app">
      {{message}}
  </div>
  </body>
  <script>
      var vm = new Vue({
          el: "#app",
          data: {
              message: 'hello world'
          },
          beforeCreate: function () {
              console.log(this);
              showData('创建vue实例前', this);
          },
          created: function () {
              showData('创建vue实例后', this);
          },
          beforeMount: function () {
              showData('挂载到dom前', this);
          },
          mounted: function () {
              showData('挂载到dom后', this);
          },
          beforeUpdate: function () {
              showData('数据变化更新前', this);
          },
          updated: function () {
              showData('数据变化更新后', this);
          },
          beforeDestroy: function () {
              vm.test = "3333";
              showData('vue实例销毁前', this);
          },
          destroyed: function () {
              showData('vue实例销毁后', this);
          }
      });

      function realDom() {
          console.log('真实dom结构：' + document.getElementById('app').innerHTML);
      }

      function showData(process, obj) {
          console.log(process);
          console.log('data 数据：' + obj.message)
          console.log('挂载的对象：')
          console.log(obj.$el)
          realDom();
          console.log('------------------')
          console.log('------------------')
      }

      vm.message = "good...";
      // vm.$destroy();
  </script>
  ```

  运行结果：

  ```
  创建vue实例前
  data 数据：undefined
  挂载的对象：undefined
  真实dom结构：{{message}}
  ------------------
  ------------------
  创建vue实例后
  data 数据：hello world
  挂载的对象：undefined
  真实dom结构：{{message}}
  ------------------
  ------------------
  挂载到dom前
  data 数据：hello world
  挂载的对象：<div id="app">{{message}}</div>
  真实dom结构：{{message}}
  ------------------
  ------------------
  挂载到dom后
  data 数据：hello world
  挂载的对象：<div id="app">good...</div>
  真实dom结构：hello world

  ------------------
  ------------------
  数据变化更新前
  data 数据：good...
  挂载的对象：<div id="app">good...</div>
  真实dom结构：hello world
  ------------------
  ------------------
  数据变化更新后
  data 数据：good...
  挂载的对象：<div id="app">good...</div>
  真实dom结构：good...
  ------------------
  ------------------
  ```

### 4. VueJS ajax

* 需要引入 axios.js
* get 请求

  ```
  //通过给定的ID来发送请求
  axios.get('/user?ID=12345')
  .then(function(response){
      console.log(response);
  })
  .catch(function(err){
      console.log(err);
  });

  //以上请求也可以通过这种方式来发送
  axios.get('/user',{
      params:{
          ID:12345
      }
  })
  .then(function(response){
      console.log(response);
  })
  .catch(function(err){
      console.log(err);
  });
  ```

  * `.then` 为回调函数，`.catch` 为捕获异常
* post 请求

  ```
  axios.post('/user',{
      firstName:'Fred',
      lastName:'Flintstone'
  })
  .then(function(res){
      console.log(res);
  })
  .catch(function(err){
      console.log(err);
  });
  ```

  * 注意，get 的第二种写法传送数据时需要写 params，post 则直接写数据即可。

### 5. 综合案例

* user.js

  ```js
  new Vue({
      el:"#app",
      data:{
          user:{
              id:"",
              username:"",
              password:"",
              email:"",
              age:"",
              sex:""
          },
          userList:[]
      },
      methods:{
          findAll:function () {
              var _this=this;
              axios.get('/vue/user/findAll.do').then(function (value) {
                  console.log(value);
                  _this.userList=value.data;
              }).catch(function (reason) {
                  console.log(reason);
              })
          },
          findById:function (userid) {

          },
          update:function (user) {

          }
      },
      created:function () {
          this.findAll();
      }
  });
  ```
  * 当 vue 对象被创建的时候，访问 controller 的 findAll 方法，获取 JSON 数据，存入到 userList，然后前台获取。
  * `var _this=this;`，在 axios.get 中使用 this 的话，对象为 axios，需要使用这条语句记录 vue 对象。
