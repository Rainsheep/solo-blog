title: Vector、set、string、map的区别
date: '2019-12-03 19:45:40'
updated: '2019-12-03 19:45:40'
tags: [STL, 知识点总结]
permalink: /articles/2019/12/03/1575373540912.html
---
# 插入的区别（主要看参数）

Vectore：

添加、删除用 push_back(x);pop_back();

插入用 index(it,x);

Set:

插入用 index(x);

String:

插入 insert(pos,str);在 pos 下标处插入 str;

Insert(it,it1,it2);在 it 出插入 it1~it2 内元素；

map：

mp.insert(make_pair(“haha”,5) );

mp.insert(pair&lt;string,int&gt;(“haha”,5));

若已有此键值时不会覆盖原元素；

mp[str]=int;

若已经有此 key 键，则会覆盖原元素

# 删除的区别
Erase(it)和 erase(it1,it2)通用

除此之外

Set 和 map 因为唯一性还可以用 erase(value)和 erase(key)删除元素

String 还可以 erase(pos,lenth);从 pos 位开始删除长度为 lenth 的字符个数

# 查找的区别
Vector 无查找函数

Set 和 map 查找为 find(value)和 find(key)，返回都为迭代器

String：

s.find(s2);查找子串，返回的为子串的第一位的下标

s.find(s2,pos);从 pos 位查找，返回值为下标

# 排序的区别
Vector 和 string 可用 sort 排序；

Set 和 map 自动从小到大排序，自定义排序方式方法完全一样

# s.at(i);和 s[i]的区别
Vector 和 string 中可以使用下标访问

name[index] 若是访问到不存在的元素

vector 中会乱出结果，string 中为‘/0’;

name.at(i);若是访问到不存在元素会报错。
