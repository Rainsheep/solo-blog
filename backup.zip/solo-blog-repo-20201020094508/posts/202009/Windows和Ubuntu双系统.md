title: Windows 和 Ubuntu 双系统
date: '2020-09-17 00:55:13'
updated: '2020-09-17 00:55:13'
tags: [Linux, windows]
permalink: /articles/2020/09/17/1600275313257.html
---
### Windows 和 Ubuntu 双系统

参考文献：

[win10下安装Ubuntu16.04双系统](https://blog.csdn.net/s717597589/article/details/79117112)
[UEFI windows10 + Ubuntu17.04双系统安装](https://zhuanlan.zhihu.com/p/30986396)
[(双硬盘(SSD+HDD)/单硬盘)双系统win10+ubuntu18.04安装记录](https://blog.csdn.net/ifreewolf_csdn/article/details/81330921)

> 系统版本 Windows 10 ，Ubuntu 16.04
>
> 安装环境：VMware

* Windows 要比 Ubuntu 先安装，最好是 UEFI 引导

  * 若先装 Ubuntu，windows10 的开机引导会覆盖 Ubuntu 的引导
* 先在硬盘上分出要安装 Ubuntu 的空间
* 并**在 Windows 所在的硬盘上**，分出 2G 左右的空间，作为 Ubuntu 的 /boot 分区，来引导双系统
* 使用软碟通(UltraISO)，将 Ubuntu 镜像刻到 U 盘中
* 然后插上 U 盘，正常安装就行，需要注意的是，Ubuntu 分区得到时候，选择手动分区，不要自动分区把 Windows 给删了。即不要选择 instgall Ubuntu along with windows, 选择 Something else
* 注意在分区时，安装启动引导器设备一定要选 windows boot manager 分区![image.png](https://b3logfile.com/file/2020/09/image-3510ebeb.png)
* 如果是虚拟机的话，CD/DVD(SATA) 镜像换成 Ubuntu 的镜像，然后选择**打开电源时进入固件**，在  boot manager 界面选择 SATA 硬盘即可进入 Ubuntu 的安装界面
* 安装完成后，重启，如果系统会直接进入Windows，而不是看到 Grub 引导选择界面。则还需要**进入UEFI设置界面，在 boot priority 那里，有两个选项，windows 和 Ubuntu，将Ubuntu选为第一个。（各主板给该选项起的名字可能不一样，要自己看下；不是启动设备选择U盘、硬盘、光盘那个选项）**
* 如果还是有问题，需要修复引导

  打开安装好的EasyBCD软件，
  选择左侧的“添加新条目”，
  选择右侧选项卡 “Linux/BSD”，
  可以适当的给这个 linux 启动项合适的名字，比如：Ubuntu 16.04
  选择驱动器：/boot分区
  点击右边的“添加条目”，即添加完成。![20170107234343024.png](https://b3logfile.com/file/2020/09/20170107234343024-5eddad20.png)

  选择左侧的栏目“编辑引导菜单”，
  可以对引导菜单上下移动，重命名或删除，
  可以设置引导菜单停留时间，最后别忘了点击“保存设置”。
  ![20170107234411730.png](https://b3logfile.com/file/2020/09/20170107234411730-a339a16e.png)

### Ubuntu分区

参考文献：

[Ubuntu分区方案(菜鸟方案、常用方案和进阶方案)](https://www.jianshu.com/p/f229cf403836)
[安装Ubuntu Linux系统时硬盘分区最合理的方法](https://blog.csdn.net/u012052268/article/details/77145427)

* /boot ：引导分区、逻辑分区、 大小为 2G、分区格式为 ext4
* swap：逻辑分区、充当虚拟内存、大小等于内存大小、分区格式为 swap
* /：主分区、存放系统文件、大小建议 30G、分区格式为 ext4
* /home：逻辑分区、用户空间、尽量大、 分区格式 ext4，主要用来防止重装系统的时候文件丢失，否则可以直接挂载到 / 下面

### 各个分区的作用

参考文献：

[Ubuntu分区方案(菜鸟方案、常用方案和进阶方案)](https://www.jianshu.com/p/f229cf403836)

* /bin, /sbin,  /lib,  /etc,  /dev

  这五个目录。绝对不可与/所在的分区分开，因为这五个目录，有系统必要的工具与资料存放。当根目录在开机过程中被挂载进来时，需要这些工具与资料来维持正常的运作。若是把这五个目录放在其它分区当中，系统就不能正常引导。
* /tmp

  用来存放临时文件。这对于多用户系统或者网络服务器来说是有必要的。这样即使程序运行时生成大量的临时文件，或者用户对系统进行了错误的操作，文件系统的其它部分仍然是安全的。因为文件系统的这一部分仍然还承受着读写操作，所以它通常会比其它的部分更快地发生问题。这个目录是任何人都能访问的，所以需要定期清理。
* /usr

  Linux系统存放软件的地方，如有可能应将最大空间分给它

  除了系统的基本程序外，其它所有的应用程序多放在这个目录当中。除了 /home,/var 这种变动数据的存放目录外，/usr大概是会是使用容量最大的目录，不过一般Linux下的应用程序通常不大。
* /bin, /usr/bin, /usr/local/bin

  存放标准系统实用程序。

  一些服务启动之后，这些服务所需要访问的数据目录。
* /etc

  系统主要的设置文件几乎都放在这个目录内。
* /lib, /usr/lib, /usr/local/lib

  系统使用的函数库的目录。
* /root

  系统管理员的家目录。
* /lost+found

  该目录在大多数情况下都是空的，但当实然停电或者非正常关机后，有些文件临时存入在此。
* /dev

  设备文件，在Linux系统上，任何设备都以文件类型存放在这个目录中，如硬盘设备文件，软驱、光驱设备文件等。
* /mnt
* /media

  挂载目录，用来临时挂载别的文件系统或者别的硬件设备（如光驱、软驱）。
* /opt

  用于存储第三方软件的目录，或者放在 /usr/local 下
* /proc

  此目录信息是在内存中由系统自行产生的，存储了一些当前的进程ID号和CPU、内存的映射等，因为这个目录下的数据都在内存中，所以本身不占任何硬盘空间。
* /sbin, /usr/sbin, /usr/local/sbin

  存放一些系统管理员才会用到的执行命令。
* /var

  主要放置系统执行过程中经常变化的文件，例如缓存（cache）或者是随时更改的登录文件（log file）。

  假如你的计算机主要是提供网页服务，或者是 MySQL 数据库，那 /var 会大量增加，你最好能够把 /var 额外分割出来。与 /home 的概念类似，重新安装时，不要格式化，仍可保留原来的数据。

  在服务器的应用时，数据的安全是相当重要的，额外分区对数据的安全也有所帮助。
* /var/log

  是系统 log 档保存的位置，养成有问题就去找 log 的好习惯，有助于解决问题。所以这也加强了额外分区的重要性。当一个服务器出现系统问题，甚至毁损时，除了你的数据外，之前的系统纪录也相当重要，找出为什么系统会出问题，可以帮助管理器快速排除障碍。

### 双系统下卸载 Ubuntu

参考文献：

[【转】Win10+Ubuntu双系统删除Ubuntu方法](https://www.cnblogs.com/exciting/p/11430173.html)

[在win10、Ubuntu双系统下，卸载Ubuntu](https://my.oschina.net/u/4344316/blog/3360959)

[Win10，Ubuntu双系统，如何卸载Ubuntu系统？](https://jingyan.baidu.com/article/642c9d34e371c3644b46f768.html)

[Windows、Ubuntu双系统正确卸载Ubuntu系统](http://www.360doc.com/content/19/1223/00/53299008_881477043.shtml)

* **不要直接删除 ubuntu 所在分区，会导致 windows 无法启动**
* 思路应该是先引导直接启动 windows，再删除 ubuntu 分区
* Legacy BIOS 和 UEFI 所对应的方法不一样，要区分开来
* 按 Win+R 打开运行，输入msinfo32，回车查看系统信息。在BIOS模式中如果显示“传统”，表示系统启动方式为Legacy BIOS；如果为UEFI，则显示UEFI。

#### Legacy BIOS 方式

方法一:

如果为 legacy启动，使用 mbrfix

1. 修复MBR
2. 进入windows，下载个软件 MbrFix，放在C:\windows\system32文件夹中
3. 打开命令提示符（以管理员身份启动）
4. 在命令提示符中输入 `MbrFix /drive 0 fixmbr /yes`
5. 此时已经修复了 MBR，重启电脑后会发现已经没有了 linux 启动选项，直接进入 windows 了
6. 删除 Ubuntu 分区

方法二：

1. 首先在 Windows 里安装上 EasyBCD
2. 点击BCD部署 → 选择系统分区 → 编写 MBR
3. 点击编辑引导菜单 → 验证是否只剩 windows 引导
4. 删除 Ubuntu 分区

#### UFEI 方式

1. 下载安装 easyUEFI
2. 找到 Ubuntu 引导，删除
3. 利用 DiskGenius 工具，删除 ESP > EFI > ubuntu 文件夹
4. 开机试试能否直接进入 windows
5. 删除 ubuntu 分区
