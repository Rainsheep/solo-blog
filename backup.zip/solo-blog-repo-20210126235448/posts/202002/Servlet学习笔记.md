title: Servlet 学习笔记
date: '2020-02-24 19:57:19'
updated: '2020-02-24 19:57:19'
tags: [Java, 学习笔记]
permalink: /articles/2020/02/24/1582545439417.html
---
### 1. Servlet 基础知识

* 概念：server applet，运行在服务器端的小程序。

  * Servlet 就是一个接口，定义了 Java 类被浏览器访问到 (tomcat 识别) 的规则。
  * 将来我们自定义一个类，实现 Servlet 接口，复写方法。

  ![](https://raw.githubusercontent.com/Rainsheep/pic-bed/master/img/2020-02-24+14:47:47+Servlet.bmp)
* 执行原理：

  1. 当服务器接受到客户端浏览器的请求后，会解析请求 URL 路径，获取访问的 Servlet 的资源路径
  2. 查找 web.xml 文件，是否有对应的 `<url-pattern>` 标签体内容。
  3. 如果有，则在找到对应的 `<servlet-class>` 全类名。
  4. tomca t 会将字节码文件加载进内存，并且创建其对象。
  5. 调用其方法。

  ![](https://raw.githubusercontent.com/Rainsheep/pic-bed/master/img/2020-02-24+14:50:26+Servlet执行原理.bmp)
* 快速入门：

  ```xml
  //web.xml
  <?xml version="1.0" encoding="UTF-8"?>
  <web-app xmlns="http://xmlns.jcp.org/xml/ns/javaee"
           xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
           xsi:schemaLocation="http://xmlns.jcp.org/xml/ns/javaee http://xmlns.jcp.org/xml/ns/javaee/web-app_3_1.xsd"
           version="3.1">
      <servlet>
          <servlet-name>demo1</servlet-name>
          <servlet-class>package1.web.servelt.ServletDemo01</servlet-class>
      </servlet>
      <servlet-mapping>
          <servlet-name>demo1</servlet-name>
          <url-pattern>/demo1</url-pattern>
      </servlet-mapping>
  </web-app>
  ```

  ```java
  //ServletDemo01.java
  package package1.web.servelt;

  import javax.servlet.*;
  import java.io.IOException;

  public class ServletDemo01 implements Servlet {
      @Override
      public void init(ServletConfig servletConfig) throws ServletException {

      }

      @Override
      public ServletConfig getServletConfig() {
          return null;
      }

      @Override
      public void service(ServletRequest servletRequest, ServletResponse servletResponse) throws ServletException, IOException {
          System.out.println("Hello Servlet");
      }

      @Override
      public String getServletInfo() {
          return null;
      }

      @Override
      public void destroy() {

      }
  }
  ```
* `getServletConfig()`：获取 Servlet 配置。
* `getServletInfo()`：获取 Servlet 的信息。
* Servlet3.0 开始，支持注解的方式

  * 在类上使用注解 `@WebServlet("资源路径")`
  * `@WebServlet 注解中有属性 String[] urlPatterns() default {};`
  * `@WebServlet 注解中有属性 String[] value() default {};`，此属性和 urlPatterns 一个意思，只是为了省略。
* 资源路径的定义规则：

  * 可以通过 `@WebServlet({"资源路径1", "资源路径2"})` 来配置多个访问路径。
  * `/xxx`：路径匹配
  * `/*`：全匹配，优先级最低，找不到对应路径的时候才会访问这个
    * `http://localhost:8080/项目虚拟路径/` 也会访问到这个，最后的 `/` 有没有是一样的
  * `/xxx/xxx`：多层路径
  * `/xxx/*`：同理
  * `*.do`
    * 只要是 `.do` 结尾都可以访问到
    * `http://localhost:8080/项目虚拟路径/xxx.do`
    * `http://localhost:8080/项目虚拟路径/xxx/yyy.do`
    * `http://localhost:8080/项目虚拟路径/.do` 都能访问到
    * `http://localhost:8080/项目虚拟路径.do`  访问不到

### 2. Servlet 生命周期方法

1. 被创建：执行 init 方法，只执行一次
   * Servlet 默认第一次被访问时，被创建。
   * 可用于加载资源。
   * 在 `<servlet>` 标签下通过 `<load-on-startup>` 标签配置 Servlet 的创建时机。
     * 值为负数，第一次被访问时创建
     * 值为 0 或正整数，在服务器启动时创建
   * 为什么要配置 Servlet 的创建时机？
     答：一个 Servlet 运行可能依赖于另外一个 Servlet，这时候就需要配置另外一个 Servlet 的创建时机。
2. 提供服务：执行 service 方法，执行多次
   * 次访问 Servlet 时，Service 方法都会被调用一次。
3. 被销毁：执行 destroy 方法，只执行一次
   * Servlet 被销毁时执行。服务器关闭时，Servlet 被销毁。
   * 只有服务器正常关闭时，才会执行 destroy 方法。
   * destroy 方法在 Servlet 被销毁之前执行，一般用于释放资源。

* Servlet 的 init 方法，只执行一次，说明一个 Servlet 在内存中只存在一个对象，Servlet 是单例的。
  * 那么多个用户同时访问时，可能存在线程安全问题。
  * 解决：尽量不要在 Servlet 中定义成员变量(可使用局部变量)。即使定义了成员变量，也不要对修改值，可以查询值，避免发生线程安全问题。

### 3. Servlet 的体系结构

* HTTP 一共有 7 种请求方式，常用的是 get 和 post 方式，通过网页直接请求 Servlet 使用的是 get 方式。
* `abstract HttpServlet extends abstract GenericServlet implement Servlet`
* GenericServlet：将 Servlet 接口中其他方法做了默认实现，只将 service() 方法作为抽象。

  * 定义 Servlet 类时，可以继承 GenericServlet，实现 service() 方法即可。
  * 如果需要使用其他方法，复写其他机房即可。
* HttpServlet：对 http 协议的一种封装，简化操作，一般继承这个类，复写 `doGet` 和 `doPost` 方法。
* 当 Servlet 接收到 http 的请求的时候，需要判断其请求方式，做出相应处理，HttpServlet 的 service 方法封装了 http 协议，并提供了 `doGet` 和 `doPost` 方法，让我们不需要再对请求方式做出判断，复写 `doGet` 和 `doPost` 即可。![](https://raw.githubusercontent.com/Rainsheep/pic-bed/master/img/2020-02-24+17:13:58+HttpServlet.bmp)
