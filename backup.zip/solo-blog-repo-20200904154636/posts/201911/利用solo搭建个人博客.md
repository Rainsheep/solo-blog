title: 利用solo搭建个人博客
date: '2019-11-26 19:40:48'
updated: '2020-09-04 11:14:25'
tags: [开源]
permalink: /articles/2019/11/26/1574768448759.html
---
![](https://img.hacpai.com/bing/20180604.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

参考链接：
[Solo 用户指南](https://hacpai.com/article/1492881378588)
[从零开始安装 solo 博客](https://hacpai.com/article/1565021959471)

---

# 搭建前提

* 购买服务器
* 购买域名（可不买）
* 域名解析与备案
* 为服务器安装系统

# 安装 docker

> 我的系统，Centos7.3

```shell
#使用yum更新仓库
yum update

#安装docker
yum -y install docker

#启动 Docker 后台服务
service docker start

#测试运行 hello-world
docker run hello-world
```

> 出现 hello world 就证明安装正常了

# 安装 MySQL

> 版本随意，我这里选择的 5.6，你可以选择更高版本的，这个没关系，不影响使用

```shell
# 安装mysql:5.6,直接docker run 他会自动去官方镜想下载
# MYSQL_ROOT_PASSWORD=你的数据库密码
docker run --name mysql -p 3306:3306 -e MYSQL_ROOT_PASSWORD=123456 -d mysql:5.6

# docker安装的mysql默认允许远程连接，可以使用xshell等软件连接数据库
# 进入容器mysql
docker exec -it mysql bash

# 进入数据库 p后面跟你的密码
mysql -uroot -p123456

# 创建数据库(数据库名:solo;字符集utf8mb4;排序规则utf8mb4_general_ci)
create database solo DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
# 出现Query OK, 1 row affected (0.00 sec)表示成功
#退出数据库
exit
#退出容器
exit
```

> 备份 SQL 文件的时候，可以通过 sqlyog 远程连接来备份。

> 当需要挂载本地目录(数据卷)到 docker 容器的时候，运行下面语句创建 MySQL 容器，这样可以使数据持久化，当将容器删除时，数据不会丢失。

```shell
docker run --name mysql -p 3306:3306 \
-v /dockerData/mysql/data:/var/lib/mysql \
-v /dockerData/mysql/mysqld.cnf:/etc/mysql/mysql.conf.d/mysqld.cnf \
-e MYSQL_ROOT_PASSWORD=123456 -d mysql:5.6
```

* `-v /dockerData/mysql/data:/var/lib/mysql`：将本地数据卷挂载到 MySQL 容器
* `-v /dockerData/mysql/mysqld.cnf:/etc/mysql/mysql.conf.d/mysqld.cnf`：将本地配置挂载到 MySQL 容器(配置中添加了 MySQL 内存优化的语句)

# 安装 solo

直接运行以下命令

```shell
docker run --detach --name solo --network=host \
--env RUNTIME_DB="MYSQL" \
--env JDBC_USERNAME="root" \
--env JDBC_PASSWORD="123456" \
--env JDBC_DRIVER="com.mysql.cj.jdbc.Driver" \
--env JDBC_URL="jdbc:mysql://127.0.0.1:3306/solo?useUnicode=yes&characterEncoding=UTF-8&useSSL=false&serverTimezone=UTC" \
--rm \
b3log/solo --listen_port=8080 --server_scheme=http --server_host=www.rainsheep.top
```

上面的命令建议手敲，免得出错，参数说明

* `--network=host` 让 solo 容器使用 docker 的 host 网络模式，使容器之间网络互通
* `--env JDBC_PASSWORD="123456"` 将 123456 换成你的密码
* `--listen_port=8080` 监听的端口
* `--server_scheme=http` 请求方式，暂时使用 http，后面我们会换成 https
* `--server_host=www.rainsheep.top` 你的域名，如果你没有域名可以写 ip 地址
* `--rm` 因为这个容器后面要删掉，带上 rm 会省很多事。

命令成功执行没有报错的话，通过 `docker ps` 查看执行的容器列表中是否存在 solo，存在这表示启动成功，直接访问你的域名加：8080 即可访问你的博客，http://www.rainsheep.top:8080
如果你尚在备案中，你可以收藏本帖，后面等备案通过了在研究后面的部分。
如果你不想使用 nginx 也不想升级 https，那么你可以先执行 `docker stop solo` ，然后将上面 `--listen_port=8080` 的 `8080` 换成 `80` ，然后去掉 `--rm` ，再执行一次就 ok。

> 进入网页可能会出现 Latke 配置错误，如果要配置 nginx 反代理的话不需要管，配完就好了
> 如果不配置反代理的话，在后面加上参数 `--server_port=8080` 或者 `--server_port=80` ，与前面监听端口一致

# 安装 nginx

```shell
# 切换到服务器根目录
cd /
# 创建主目录
mkdir dockerData
# 创建文件
mkdir dockerData/nginx dockerData/nginx/conf dockerData/nginx/logs dockerData/nginx/www dockerData/nginx/ssl
```

上面的 `dockerData` 可以换成自己喜欢的名字

* `dockerData/nginx` 用于存放 docker 下 nginx 自定义文件
* `dockerData/nginx/conf` 存放 nginx 配置文件
* `dockerData/nginx/log` 存放 nginx 日志文件
* `dockerData/nginx/www` 存放 nginx 访问的资源文件
* `dockerData/nginx/ssl` 存放 ssl 证书

启动 nginx
`docker run --name nginx -p 80:80 -d --rm --network=host nginx`

如果你没有备案，可以将上面的 `80:80` 换成 `8081:80` ，表示将本地的 `8081` 端口映射到容器内部的 `80` 端口，因为这个东西一会儿也要删掉，所以加上 `--rm` 参数，命令执行玩后通过 `docker ps` 查看 nginx 是否在运行，在运行的情况下访问你的域名加端口号查看是否正常安装， `80` 直接省略。访问出现 Welcome to nginx!表示成功。

导出配置文件

* `docker cp nginx:/etc/nginx/nginx.conf /dockerData/nginx/conf/nginx.conf` 导出配置文件 nginx.conf
* `docker cp nginx:/etc/nginx/conf.d /dockerData/nginx/conf/conf.d` 导出配置文件 nginx.conf

执行 `docker stop nginx` ，会自动删除现在的 nginx 容器，然后执行如下命令重新启动一个 nginx 容器

```shell
docker run -dit -p 80:80 --name nginx --network=host \
-v /dockerData/nginx/conf/nginx.conf:/etc/nginx/nginx.conf \
-v /dockerData/nginx/conf/conf.d:/etc/nginx/conf.d \
-v /dockerData/nginx/www:/usr/share/nginx/html \
-v /dockerData/nginx/logs:/var/log/nginx nginx
```

* `-v /dockerData/nginx/conf/nginx.conf:/etc/nginx/nginx.conf \` 挂载配置文件`nginx.conf`
* `-v /dockerData/nginx/conf/conf.d:/etc/nginx/conf.d` 挂载配置文件`default.conf`
* `-v /dockerData/nginx/www:/usr/share/nginx/html` 挂载项目文件
* `-v /dockerData/nginx/logs:/var/log/nginx` 挂载配置文件
* `-dit` 可以防止 nginx 容器自动关闭

新建欢迎界面

```shell
# 打开项目文件 
cd /dockerData/nginx/www 
# 使用vim 创建并编辑文件
vim index.html 
# 此时我们会进入vim界面，按 i 插入，然后输入 
<h1>Hello Docker-Nginx</h1> 
# 输入完后，按 esc，然后输入 :wq
```

访问域名，可看到 Hello Docker-Nginx

# 申请 ssl 证书，将 http 升级为 https(可跳过)

申请完 ssl 证书以后，下载证书
最后把 `Nginx` 下的两个文件上传至服务器 `/dockerDat/nginx/ssl` 目录下

> 我的两个证书名字为 `3118615_rainsheep.top.pem` 和 `3118615_rainsheep.top.key`

# 配置 nginx 配置文件

```shell
cd /dockerData/nginx/conf/conf.d 
vim default.conf
```

参考我的配置，配置自己的 default.conf 文件

```shell
upstream backend {
    server localhost:8080;   #使用localhost时，需要nginx和solo的容器处在同一网络，前面通过--network=host来实现
}

server {
    listen 443 ssl;    #443为https默认端口
    server_name  www.rainsheep.top;    #域名
    access_log off;
  
    #ssl证书相关
    ssl_certificate /ssl/3118615_rainsheep.top.pem;
    ssl_certificate_key /ssl/3118615_rainsheep.top.key;
    ssl_session_timeout 5m; 
    ssl_protocols TLSv1 TLSv1.1 TLSv1.2;
    ssl_ciphers ECDHE-RSA-AES128-GCM-SHA256:HIGH:!aNULL:!MD5:!RC4:!DHE;
    ssl_prefer_server_ciphers on; 

    location / { 
        proxy_pass http://backend$request_uri;
        proxy_set_header  Host $http_host;
        proxy_set_header  X-Real-IP  $remote_addr;
        client_max_body_size  10m;
    }   
}

#配置80端口跳转到https
server {
    listen       80; 
    server_name  www.rainsheep.top;
    rewrite ^(.*) https://${server_name}$1 permanent;
}
```

由于我们现在用的 nginx 容器并未监听 443 端口，所以需要删除现在的容器，重新启动一个新的 nginx 容器

```shell
docker stop nginx  # 停止容器
docker rm nginx # 删除容器
# 启动新的
docker run -d -p 80:80 -p 443:443 --name nginx --network=host \
-v /dockerData/nginx/conf/nginx.conf:/etc/nginx/nginx.conf \
-v /dockerData/nginx/conf/conf.d:/etc/nginx/conf.d \
-v /dockerData/nginx/ssl:/ssl/ \
-v /dockerData/nginx/www:/usr/share/nginx/html \
-v /dockerData/nginx/logs:/var/log/nginx nginx
```

* `-p 443:443` 监听 443 端口
* `-v /dockerData/nginx/ssl:/ssl/` 挂载 ssl 证书目录

访问查看，正常访问

> 访问不到的话，可能是配置文件错了，仔细核对， `docker logs nginx` 查看日志， `docker ps` 查看是否运行。

# 将 solo 通过 nginx 方向代理实现 https 访问

让 solo 还是跑在 8080 端口上，通过 nginx 代理到 443 端口即可，由于我们上面启动 solo 时添加了 `--rm` 参数，只需要 `docker stop solo` 即可自动删除 solo 容器，然后我们重新启动一个 solo 容器

```shell
docker run --detach --name solo --network=host \
--env RUNTIME_DB="MYSQL" \
--env JDBC_USERNAME="root" \
--env JDBC_PASSWORD="123456" \
--env JDBC_DRIVER="com.mysql.cj.jdbc.Driver" \
--env JDBC_URL="jdbc:mysql://127.0.0.1:3306/solo?useUnicode=yes&characterEncoding=UTF-8&useSSL=false&serverTimezone=UTC" \
b3log/solo --listen_port=8080 --server_scheme=https --server_host=www.rainsheep.top --server_port=
```

* `--server_scheme=http` 换成`--server_scheme=https` 即可
* `--server_port` ：最终访问端口，使用浏览器默认的 80 或者 443 的话值留空即可

然后我们去配置 nginx 配置文件，实现 nginx 反向代理

```shell
cd /dockerData/nginx/conf/conf.d
vim default.conf
location / { 
	proxy_pass http://backend$request_uri;
	proxy_set_header  Host $http_host;
	proxy_set_header  X-Real-IP  $remote_addr;
	client_max_body_size  10m;
} 
# 替换上面部分即可
# 按esc，然后输入:wq保持退出
```

重启 nginx， `docker restart nginx`
访问成功。
此处附上我最后的配置文件
[default.zip](https://img.hacpai.com/file/2020/03/default-4fa44c34.zip)

# 启用 Lute

* 获取最新镜像`docker pull b3log/lute-http`
* 启动容器`docker run --detach --rm --network=host --name="lute" b3log/lute-http`
* 停止 solo,`docker stop solo`
* 删除 solo，`docker rm solo`
* 运行下列命令，重启 solo，注意最后添加`--lute_http=http://127.0.0.1:8249`

```shell
docker run --detach --name solo --network=host \
--env RUNTIME_DB="MYSQL" \
--env JDBC_USERNAME="root" \
--env JDBC_PASSWORD="123456" \
--env JDBC_DRIVER="com.mysql.cj.jdbc.Driver" \
--env JDBC_URL="jdbc:mysql://127.0.0.1:3306/solo?useUnicode=yes&characterEncoding=UTF-8&useSSL=false&serverTimezone=UTC" \
b3log/solo --listen_port=8080 --server_scheme=https --server_host=www.rainsheep.top --server_port= --lute_http=http://127.0.0.1:8249
```

* 容器启动成功后再启动 Solo、Pipe、Sym 即可，如果成功的话 Solo 等的启动日志中`docker logs solo` 会输出`luteAvailable=true`

测试代码是否高亮。
教程结束。

# 启用 jsDelivr CDN 加速

```shell
docker run --detach --name solo --network=host \
--env RUNTIME_DB="MYSQL" \
--env JDBC_USERNAME="root" \
--env JDBC_PASSWORD="123456" \
--env JDBC_DRIVER="com.mysql.cj.jdbc.Driver" \
--env JDBC_URL="jdbc:mysql://127.0.0.1:3306/solo?useUnicode=yes&characterEncoding=UTF-8&useSSL=false&serverTimezone=UTC" \
b3log/solo --listen_port=8080 --server_scheme=https --server_host=www.rainsheep.top --server_port= --lute_http=http://127.0.0.1:8249 \
--static_server_scheme=https \
--static_server_host=cdn.jsdelivr.net \
--static_server_port= \
--static_path=/gh/88250/solo/src/main/resources
```

查看方法：打开开发者工具，查看 NetWork 中的请求链接地址。

> 仅支持内置皮肤

# solo 自动更新脚本

> 利用 crontab 运行脚本自动更新，脚本名 docker-solo-update.sh

```shell
#!/bin/bash
echo -e "\n"
echo `date "+%Y-%m-%d %H:%M:%S"`
isUpdate=$(docker pull b3log/solo|grep "Downloaded")
if [ -z  $isUpdate ]
then
    echo This is the latest version
else
    docker stop solo
    docker rm solo
    docker run --detach --name solo --network=host \
    --env RUNTIME_DB="MYSQL" \
    --env JDBC_USERNAME="root" \
    --env JDBC_PASSWORD="123456" \
    --env JDBC_DRIVER="com.mysql.cj.jdbc.Driver" \
    --env JDBC_URL="jdbc:mysql://127.0.0.1:3306/solo?useUnicode=yes&characterEncoding=UTF-8&useSSL=false&serverTimezone=UTC" \
    b3log/solo --listen_port=8080 --server_scheme=https --server_host=www.rainsheep.top --server_port= --lute_http=http://127.0.0.1:8249 \
    --static_server_scheme=https \
    --static_server_host=cdn.jsdelivr.net \
    --static_server_port= \
    --static_path=/gh/88250/solo/src/main/resources
    echo Success!
fi
```

使用方法：
`chmod 777 docker-solo-update.sh`
`crontab -e`
写入
`0 3 * * * bash /root/docker-solo-update.sh`
需要打印日志信息的话
`0 3 * * * bash /root/docker-solo-update.sh >> /root/sololog.log 2>&1`
运行
`crontab -l`
查看是否插入成功

# Lute 自动更新脚本

> 利用 crontab 运行脚本自动更新，脚本名 docker-lute-update.sh

```shell
#!/bin/bash
echo -e "\n"
echo `date "+%Y-%m-%d %H:%M:%S"`
isUpdate=$(docker pull b3log/lute-http|grep "Downloaded")
if [ -z  $isUpdate ]
then
    echo This is the latest version
else
    docker stop lute
    docker run --detach --rm --network=host --name="lute" b3log/lute-http
    echo Success!
fi

```

使用方法：
`chmod 777 docker-lute-update.sh`
`crontab -e`
写入
`0 4 * * * bash /root/docker-lute-update.sh`
需要打印日志信息的话
`0 4 * * * bash /root/docker-lute-update.sh >> /root/lutelog.log 2>&1`
运行
`crontab -l`
查看是否插入成功

# 导入 \.md 文件

参考链接：
[Solo 支持 Hexo/Jekyll 数据导入](https://hacpai.com/article/1498490209748)

`--volume 待导入目录/:/opt/solo/markdowns/ ` 这样应该就可以了，其中 待导入目录 是你寄主机上的绝对路径。

例如：

```shell
docker stop solo
docker rm solo
docker run --detach --volume /root/solo-markdown/:/opt/solo/markdowns/ --name solo --network=host \
--env RUNTIME_DB="MYSQL" \
--env JDBC_USERNAME="root" \
--env JDBC_PASSWORD="123456" \
--env JDBC_DRIVER="com.mysql.cj.jdbc.Driver" \
--env JDBC_URL="jdbc:mysql://127.0.0.1:3306/solo?useUnicode=yes&characterEncoding=UTF-8&useSSL=false&serverTimezone=UTC" \
b3log/solo --listen_port=8080 --server_scheme=https --server_host=www.rainsheep.top --server_port= --lute_http=http://127.0.0.1:8249
```

---

> 过程中需要用到的 docker 命令
> docker ps	查看运行的容器
> docker ps -a 	查看所有容器
> docker stop id||name	停止容器
> docker rm id||name	移除容器
> docker logs 容器名	查看容器日志

# MySQL 的内存优化

输入命令 `top` 可以查看内存使用情况。

优化 MySQL 所占内存：

创建文件夹

```shell
cd /dockerDate
mkdir mysql
```

从容器中复制配置文件到服务器
`docker cp mysql:/etc/mysql/mysql.conf.d/mysqld.cnf  /dockerData/mysql`

编辑配置文件
`vim mysqld.cnf`

末尾添加

```
performance_schema_max_table_instances=400
table_definition_cache=400
table_open_cache=256
```

从服务器复制到容器
`docker cp /dockerData/mysql/mysqld.cnf mysql:/etc/mysql/mysql.conf.d/mysqld.cnf`

改完之后记得重启 MySQL
`docker restart mysql`
