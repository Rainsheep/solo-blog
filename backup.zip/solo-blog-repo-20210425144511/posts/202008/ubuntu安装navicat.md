title: ubuntu 安装 navicat
date: '2020-08-15 13:24:58'
updated: '2020-08-15 18:48:35'
tags: [Linux, 软件教程]
permalink: /articles/2020/08/15/1597469098346.html
---
参考：

[Ubuntu18.04中安装Navicat并添加快捷方式](https://blog.csdn.net/King_key/article/details/88365251)

[ubuntu18.04安装navicat （破解版）以及创建快捷方式](https://blog.csdn.net/gymaisyl/article/details/86575352)

[Ubuntu 19.10 下 Navicat 15 premium 无限期试用（亲测有效）](https://blog.csdn.net/u014585456/article/details/104464269)

[关于Ubuntu中Navicat连接不上MySQL的问题（mysql.sock相关）](https://blog.csdn.net/zadaya/article/details/105401978)

> ubuntu 16.04 版本破解 Navicat15 总是报错，在ubuntu 18.04 版本上破解 Navicat15 成功

### 1. Navicat12 破解版

ubuntu 16.04 可用

下载地址：链接：[https://pan.baidu.com/s/10vTUBbHD1oj6IP4DSxWREQ]() 提取码：zzsu

解压后，进入到解压后的文件夹中执行命令：`./start_navicat` 安装即可。

### 2.Navicat15 破解教程

ubuntu 18.04 破解成功，16.04 破解出错

#### 相关工具下载

**navicat15-premium-cs.AppImage**：Navicat 15 premium 官方简体中文试用版
**navicat-patcher**：补丁
**navicat-keygen** ：注册机
**appimagetool-x86_64.AppImage**：Linux 独立运行软件打包工具

下载地址：链接：[https://pan.baidu.com/s/1ufFM28JAGcTCKH2OEZkWQw]() 提取码：2ahs

#### 系统环境配置

**安装 capstone**

```
sudo apt-get install libcapstone-dev
```

**安装 keystone**

```
sudo apt-get install cmake
git clone https://github.com/keystone-engine/keystone.git
cd keystone
mkdir build
cd build
../make-share.sh
sudo make install
sudo ldconfig
```

> 需要先安装 gcc 和 g++ 才能正常编译

**安装 rapidjson**

```
sudo apt-get install rapidjson-dev
```

#### 破解步骤

**赋予执行权限**

```
chmod +x appimagetool-x86_64.AppImage
chmod +x navicat-patcher
chmod +x navicat-keygen
```

**解包官方软件**

```
mkdir navicat15
mount -o loop navicat15-premium-cs.AppImage navicat15
cp -r navicat15 navicat15-patched
unmount navicat15
```

**运行补丁**

```
./navicat-patcher navicat15-patched
```

生成RegPrivateKey.pem文件

```
**********************************************************
*       Navicat Patcher (Linux) by @DoubleLabyrinth      *
*                  Version: 1.0                          *
**********************************************************
[*] New RSA-2048 private key has been saved to
    ./RegPrivateKey.pem
*******************************************************
*           PATCH HAS BEEN DONE SUCCESSFULLY!         *
*                  HAVE FUN AND ENJOY~                *
*******************************************************
```

**打包成独立运行软件**

```
./appimagetool-x86_64.AppImage navicat15-patched navicat15-premium-cs-pathed.AppImage
```

**运行补丁后的软件包**

```
chmod +x navicat15-premium-cs-pathed.AppImage
./navicat15-premium-cs-pathed.AppImage
```

然后断网

**运行注册机**

```
./navicat-keygen --text ./RegPrivateKey.pem
```

**选择产品类型：** *1 Premium*

```
**********************************************************
*       Navicat Keygen (Linux) by @DoubleLabyrinth       *
*                   Version: 1.0                         *
**********************************************************
[*] Select Navicat product:
 0. DataModeler
 1. Premium
 2. MySQL
 3. PostgreSQL
 4. Oracle
 5. SQLServer
 6. SQLite
 7. MariaDB
 8. MongoDB
 9. ReportViewer

(Input index)> 1
```

**选择语言：** *1 Simplified Chinese*

```
[*] Select product language:
 0. English
 1. Simplified Chinese
 2. Traditional Chinese
 3. Japanese
 4. Polish
 5. Spanish
 6. French
 7. German
 8. Korean
 9. Russian
 10. Portuguese

(Input index)> 1
```

**选择版本：** *15*

```
[*] Input major version number:
(range: 0 ~ 15, default: 12)> 15
```

**生成序列号：** *填写至**软件注册页面**，并在断网后选择手工激活，会出现一个注册码*

```
[*] Serial number:
NAVC-PJWW-BKN4-C4YW
```

**填写个人信息：**

```
[*] Your name: zenghaiming
[*] Your organization: hh
```

**输入注册码：** *复制软件激活页面注册码并粘贴此处*

```
[*] Input request code in Base64: (Double press ENTER to end)
nqKkI0BtJR5Nq***==
```

**生成激活码：** *复制Activation Code内容粘贴至软件激活页面*

```
[*] Request Info:
{"K":"NAVCPJWWBKN4C4YW", "DI":"B0A1C7E8FA226577356B", "P":"linux"}

[*] Response Info:
{"K":"NAVCPJWWBKN4C4YW","DI":"B0A1C7E8FA226577356B","N":"zenghaiming","O":"hh","T":1582448573}

[*] Activation Code:
CKrwYGzMf0OZgZCE***==
```

### 3.  Navicat15 链接不上

```
2002 - Can’t connect to local MySQL server through socket ‘/var/lib/mysql/mysql.sock’ (13 “权限不够”)
或
2002 - Can’t connect to local MySQL server through socket ‘/var/lib/mysql/mysql.sock’ (2 “没有那个文件或目录”)
```

寻找 mysqld.sock，在高级→使用名称管道、套接字中输入路径 `/var/run/mysqld/mysqld.sock`设置如下

![20200409075602481.png](https://b3logfile.com/file/2020/08/20200409075602481-6cfca14b.png)
