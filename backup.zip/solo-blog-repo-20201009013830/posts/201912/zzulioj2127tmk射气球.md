title: zzulioj 2127 tmk射气球
date: '2019-12-03 12:00:58'
updated: '2019-12-03 12:00:58'
tags: [acm, 数学问题]
permalink: /articles/2019/12/03/1575345658197.html
---
## Description

有一天TMK在做一个飞艇环游世界，突然他发现有一个气球匀速沿直线飘过，tmk想起了他飞艇上有一把弓，他打算拿弓去射气球，为了提高射击的准确性，他首先在飞艇上找到一个离气球最近的一个点，然后射击（即使气球在飞船的正上方），现在求某些时刻飞艇上的点和气球的距离最小是多少（这个最小距离我们简称为飞艇到气球的距离）。

 

## Input

第一行一个整数T(T<=20)，表示有T组测试数据

每组测试数据，有两行。

第一行有5个整数，h,x1,y1,x2,y2，其中h表示飞船的高度，飞船可抽象为一个线段，(x1,y1)(x2,y2)分别是这个线段的端点（有可能会有(x1,y1)(x2,y2)重合的情况）

第二行有6个整数，x,y,z,X,Y,Z分别表示气球的在第0秒的时候的横坐标，纵坐标，高度，一秒时间气球横坐标的变化量，一秒时间气球纵坐标的变化量，一秒时间气球高度的变化量(如果现在气球在(x0,y0,z0)下一秒坐标就为(x0+X,y0+Y,z0+Z))

第三行1个整数n，表示询问组数

接下来的n行，每行一个整数，表示询问的秒数t

题目涉及的整数除了T以外，范围均为[0,1000]

 

## Output

每组询问输出n行，每行输出一个数，表示在t秒的时候飞艇与气球的距离最小是多少，保留两位小数

 

## Sample Input

1 1 1 1 2 2 0 0 0 4 4 4 2 0 3

## Sample Output

1.73 17.92

## 代码
```C++
#include<iostream>
#include<cmath>
using namespace std;
int main()
{
    double t,x1,y1,z1,x2,y2,z2,x0,y0,z0,x,y,z,h,i,j,xt,yt,zt,T,n;//为了方便，全部定义为了double 
    double d,mid,x3,y3,z3;
    cin>>T;;
    while(T--)
    {
        cin>>h>>x1>>y1>>x2>>y2;//飞船的坐标 
        cin>>x0>>y0>>z0>>xt>>yt>>zt;//气球起始坐标与移动速度 
        cin>>n;
        while(n--)
        {
            cin>>t;
            x=x0+xt*t;//t秒时坐标 
            y=y0+yt*t;
            z=z0+zt*t;
            if(x1==x2&&y1==y2)//飞船为一个点 
            {
                d=sqrt((x-x1)*(x-x1)+(y-y1)*(y-y1)+(z-h)*(z-h));
                printf("%.2f\n",d);
                continue;
            }
            else
            {
            mid=((x-x1)*(x2-x1)+(y-y1)*(y2-y1))/((x1-x2)*(x1-x2)+(y2-y1)*(y2-y1));//用向量写，判断（x0,y0）点与飞船所在线段的相对位置，mid=|a|cos<a,b>/|b| 
            x3=x1+mid*(x2-x1);//垂足坐标 
            y3=y1+mid*(y2-y1);
            z3=h;
                if(mid>=0&&mid<=1)
            {
                d=sqrt((x3-x)*(x3-x)+(y3-y)*(y3-y)+(h-z)*(h-z));
                printf("%.2f\n",d);
            }
            else if(mid>1)
            {
             
                    d=sqrt((x2-x)*(x2-x)+(y2-y)*(y2-y)+(z3-z)*(z3-z));
                printf("%.2f\n",d);
            }
             else if(mid<0)
            {
                d=sqrt((x1-x)*(x1-x)+(y1-y)*(y1-y)+(h-z)*(h-z));
                printf("%.2f\n",d);
            }  
            }
        }
    }
    return 0;
}
```
