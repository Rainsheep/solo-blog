title: docker进入容器
date: '2020-01-26 23:32:24'
updated: '2020-01-26 23:32:24'
tags: [Java]
permalink: /articles/2020/01/26/1580052744560.html
---
参考链接：
[docker exec 的使用-it操作](https://blog.csdn.net/qq_40081976/article/details/84590119)
[docker exec提示错误oci runtime error: exec failed: container_linux.go](https://blog.csdn.net/a19891024/article/details/80666353)

命令：`docker exec -it container /bin/sh`
>container可以根据`docker ps`查看

docker exec ：在运行的容器中执行命令
-i :即使没有附加也保持STDIN 打开
-t :分配一个伪终端
-it : 目前的理解为等容器内的命令执行完毕才会出来到当前操作; 没有-it的加 就相当于在容器内执行一下命令,不等容器内部是否执行完毕直接出来,而我们看见的他在上面是因为容器内的执行快,(行动派可以试试在里面写个循环制造时间验证)。

-it 会等容器内的操作执行完毕,而bash 是打开容器内的一个终端近程,又因为it的等待，所以就会一直以终端连接的方式停留在容器内部,下面展示效果:
![](https://raw.githubusercontent.com/Rainsheep/pic-bed/master/img/2020-01-26+23:30:52+p_20200126113050.png)


