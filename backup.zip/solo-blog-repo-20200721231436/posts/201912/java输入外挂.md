title: java输入外挂
date: '2019-12-03 21:12:17'
updated: '2019-12-03 21:12:17'
tags: [java, 知识点总结]
permalink: /articles/2019/12/03/1575378737377.html
---
```java
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.StringTokenizer;
 
public class Main {
	public static void main(String[] args) {
		InputReader in = new InputReader(System.in);
		PrintWriter out = new PrintWriter(System.out);// 输出挂
		while (in.hasNext()) {
			String s = in.next();
			out.println(s);
			// out.write(s);//无换行
		}
		out.close();// 必须加，运行完此句一起输出
	}
 
	static class InputReader {
		public BufferedReader reader;
		public StringTokenizer tokenizer;
 
		public InputReader(InputStream stream) {
			reader = new BufferedReader(new InputStreamReader(stream), 32768);
			tokenizer = null;
		}
 
		public boolean hasNext() {
			while (tokenizer == null || !tokenizer.hasMoreTokens()) {
				try {
					tokenizer = new StringTokenizer(reader.readLine());
				} catch (Exception e) {
					return false;
				}
			}
			return true;
		}
 
		public String next() {
			if (hasNext())
				return tokenizer.nextToken();
			return null;
		}
 
		public String nextLine() {
			if (hasNext())
				return tokenizer.nextToken("");
			else
				return null;
		}
 
		public int nextInt() {
			return Integer.parseInt(next());
		}
 
		public long nextLong() {
			return Long.parseLong(next());
		}
 
		public double nextDouble() {
			return Double.parseDouble(next());
		}
 
		public BigInteger nextBigInteger() {
			return new BigInteger(next());
		}
 
		public BigDecimal nextBigDecimal() {
			return new BigDecimal(next());
		}
	}
 
}

```
