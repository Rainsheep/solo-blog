title: 'miniconda3 '
date: '2020-09-14 11:09:38'
updated: '2020-09-14 11:09:38'
tags: [conda, python]
permalink: /articles/2020/09/14/1600052978187.html
---
参考链接：

[官网文档](https://conda.io/projects/conda/en/latest/user-guide/install/macos.html#install-macos-silent)

[清华镜像](https://mirrors.tuna.tsinghua.edu.cn/help/anaconda/)

[conda使用教程——分类总结](https://www.cnblogs.com/novnex/p/11629046.html)

> 系统版本：Ubuntu 16.04

### 安装 miniconda3

* [官网下载](https://docs.conda.io/en/latest/miniconda.html#linux-installers) Pyhon3.8 ，64位版本，下载 Py3 也能够安装 py2 的
* ```
  bash Miniconda3-latest-Linux-x86_64.sh
  ```
* Do you wish the installer to initialize Miniconda3 by running conda init?

  * 选择 yes 进行初始化
* ```
  conda --version  // 验证安装是否成功
  ```
* 每次启动终端前面会出现 (base) 字样，即每次自动激活了 base 环境，取消方法如下

  ```
  vim ~/.condarc
  追加 auto_activate_base: false
  ```

### 更换镜像

```
vim ~/.condarc
追加
channels:
  - defaults
show_channel_urls: true
channel_alias: https://mirrors.tuna.tsinghua.edu.cn/anaconda
default_channels:
  - https://mirrors.tuna.tsinghua.edu.cn/anaconda/pkgs/main
  - https://mirrors.tuna.tsinghua.edu.cn/anaconda/pkgs/free
  - https://mirrors.tuna.tsinghua.edu.cn/anaconda/pkgs/r
  - https://mirrors.tuna.tsinghua.edu.cn/anaconda/pkgs/pro
  - https://mirrors.tuna.tsinghua.edu.cn/anaconda/pkgs/msys2
custom_channels:
  conda-forge: https://mirrors.tuna.tsinghua.edu.cn/anaconda/cloud
  msys2: https://mirrors.tuna.tsinghua.edu.cn/anaconda/cloud
  bioconda: https://mirrors.tuna.tsinghua.edu.cn/anaconda/cloud
  menpo: https://mirrors.tuna.tsinghua.edu.cn/anaconda/cloud
  pytorch: https://mirrors.tuna.tsinghua.edu.cn/anaconda/cloud
  simpleitk: https://mirrors.tuna.tsinghua.edu.cn/anaconda/cloud
```

即可添加 Anaconda Python 免费仓库。

运行 `conda clean -i` 清除索引缓存，保证用的是镜像站提供的索引。

查看已配置的 channels

```
conda config --get channels
```

### 使用 conda

* conda 更新

  ```
  conda update conda
  ```
* 查看环境列表

  ```
  conda env list
  ```
* 创建环境

  ```
  // 创建指定名字的环境
  conda create -n env_name
  // 创建制定python版本的环境
  conda create -n env_name python=3.5
  ```
* 激活环境

  ```
  conda activate env_name
  ```
* 删除环境

  ```
  conda env remove -n env_name 
  ```
* 搜索包

  ```
  conda search package_name
  conda search package_name=version
  ```
* 查看包列表

  ```
  // 列出当前环境下所有安装包
  conda list  
  // 列出 my_env环境中所有的安装包
  conda list -n my_env 
  ```
* 安装包

  ```
  conda install package_name
  conda install package_name=version
  ```
* 卸载包

  ```
  // 卸载当前环境的包
  conda uninstall package_name
  // 卸载指定环境的包
  conda uninstall -n env package_name
  ```
* 更新包

  ```
  conda update package_name
  ```
* 导出包

  ```
  // 把当前环境中的所有包导出list，以备后续使用
  conda list --export > package-list.txt
  // 对导出的包list重新安装到 my_env 环境中
  conda create -n my_env --file package-list.txt
  ```

### 卸载 miniconda3

* ```
  rm -rf ~/miniconda
  ```
* `vim ~/.bash_profile` 删除对应的环境变量
* ```
  rm -rf ~/.condarc ~/.conda ~/.continuum
  ```
