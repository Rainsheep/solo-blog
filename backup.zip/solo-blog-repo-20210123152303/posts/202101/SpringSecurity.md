title: Spring Security
date: '2021-01-22 14:06:21'
updated: '2021-01-22 14:06:21'
tags: [java, spring]
permalink: /articles/2021/01/22/1611295581301.html
---
参考文献：[Spring Security在Spring Boot环境下的学习](https://blog.csdn.net/qq_38490457/article/details/112811102)
示例代码：[SpringSecurity.zip](https://b3logfile.com/file/2021/01/SpringSecurity-68f36867.zip)



