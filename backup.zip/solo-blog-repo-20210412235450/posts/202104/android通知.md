title: android 通知
date: '2021-04-12 19:46:10'
updated: '2021-04-12 19:46:10'
tags: [android]
permalink: /articles/2021/04/12/1618227970339.html
---
## 1. 通知的基本用法

通知的创建

```java
NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
Notification notification = new NotificationCompat.Builder(context).build();
```

上述只是创建了一个空的 Notification 对象，并没有什么实际作用。

创建一个丰富的 Notification 对象

```java
Notification notification = new NotificationCompat.Builder(this)
        .setContentTitle("This is content title") // 定义标题
        .setContentText("This is content text")  // 定义正文内容
        .setWhen(System.currentTimeMillis())  // 定义通知时间
        .setSmallIcon(R.mipmap.ic_launcher)  // 定义小图标
        .setLargeIcon(BitmapFactory.decodeResource(getResources(), R.mipmap.ic_launcher))  // 定义大图标
        .build();
// 第一个参数为通知的 id, 每个通知的 id 都是不同的
manager.notify(1, notification);
```

如果想让通知可以被点击，我们需要使用 PendingIntent，可以简单理解为延迟的 Intent。

PendingIntent 提供了几个静态方法获取 PendingIntent 实例。

```java
// 第二个参数一般用不到，通常传 0 
// 第三个参数是一个 Intent 对象， 我们通过这个对象构建出 PendingIntent 的意图
// 第四个参数用于确定 PendingIntent 的行为，一般传 0
PendingIntent.getActivity(Context, int, Intent, int);    // 跳转到一个activity组件
PendingIntent.getBroadcast(Context, int, Intent, int);   // 打开一个广播组件
PendingIntent.getService(Context, int, Intent, int);     // 打开一个服务组件
```

我们写一个可以点击的通知

```java
@Override
public void onClick(View v) {
    switch (v.getId()) {
        case R.id.send_notice:
            Intent intent = new Intent(this, NotificationActivity.class);
            PendingIntent pi = PendingIntent.getActivity(this, 0, intent, 0);
            NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            Notification notification = new NotificationCompat.Builder(this)
                    .setContentTitle("This is content title")
                    .setContentText("This is content text")
                    .setWhen(System.currentTimeMillis())
                    .setSmallIcon(R.mipmap.ic_launcher)
                    .setLargeIcon(BitmapFactory.decodeResource(getResources(), R.mipmap.ic_launcher))
                    .setContentIntent(pi)
                    .build();
            manager.notify(1, notification);
            break;
        default:
            break;
    }
}
```

点击通知以后并没有消失，让通知消失有两种方法

```java
// 方法一
Notification notification = new NotificationCompat.Builder(this)
        .setAutoCancel(true)
        .build();
// 方法二， 在新的 Activity 中
NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
manager.cancel(id);
```

## 2. 通知的进阶技巧

