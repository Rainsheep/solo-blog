title: android AsyncTask
date: '2021-06-22 11:21:18'
updated: '2021-06-22 14:09:26'
tags: [android]
permalink: /articles/2021/06/22/1624332078360.html
---
## 1. 基本使用

我们需要创建一个类来继承 AsyncTask，AsyncTask 有三个泛型

* Params，执行 AsyncTask 需要传入的参数，可用于在后台任务中使用。
* Progress，后台任务执行时，若需在界面显示进度，这个泛型为进度的单位。
* Result，任务执行完毕后，若需对结果进行返回，此泛型为返回值类型。

```java
/**
  * 步骤1：创建 AsyncTask 子类
  * 注： 
  *   a. 继承 AsyncTask 类
  *   b. 为3个泛型参数指定类型；若不使用，可用java.lang.Void类型代替
  *   c. 根据需求，在 AsyncTask 子类内实现核心方法
  */
private class MyTask extends AsyncTask<Params, Progress, Result> {
    // 方法1：onPreExecute（）
    // 作用：执行 线程任务前的操作
    // 注：根据需求复写
    @Override
    protected void onPreExecute() {
    }

    // 方法2：doInBackground（）
    // 作用：接收输入参数、执行任务中的耗时操作、返回 线程任务执行的结果
    // 注：必须复写，从而自定义线程任务,此方法中不能更新 UI
    @Override
    protected String doInBackground(String... params) {
        // 自定义的线程任务
        // 可调用publishProgress（）显示进度, 之后将执行onProgressUpdate（）
            publishProgress(count);
    }

    // 方法3：onProgressUpdate（）
    // 作用：在主线程,显示线程任务执行的进度,更新 UI
    // 注：根据需求复写
    @Override
    protected void onProgressUpdate(Integer... progresses) {
    }

    // 方法4：onPostExecute（）
    // 作用：接收线程任务执行结果、将执行结果显示到 UI 组件
    // 注：必须复写，从而自定义 UI 操作
    @Override
    protected void onPostExecute(String result) {
        // UI操作
    }

    // 方法5：onCancelled()
    // 作用：将异步任务设置为：取消状态
    @Override
    protected void onCancelled() {
    }
}

/**
* 步骤2：创建AsyncTask子类的实例对象（即 任务实例）
* 注：AsyncTask子类的实例必须在UI线程中创建
*/
MyTask mTask = new MyTask();

/**
* 步骤3：手动调用execute(Params... params) 从而执行异步线程任务
* 注：
*    a. 必须在UI线程中调用
*    b. 同一个AsyncTask实例对象只能执行1次，若执行第2次将会抛出异常
*    c. 执行任务中，系统会自动调用AsyncTask的一系列方法：onPreExecute() 、doInBackground()、onProgressUpdate() 、onPostExecute() 
*    d. 不能手动调用上述方法
*/
mTask.execute()；
```

* AsyncTask 的类必须在主线程加载
* AsyncTask 对象必须在主线程创建
* execute() 方法必须在主线程调用
* 不要再程序中直接调用 onPreExecute()、onPostExecute()、doInBackground()、onProgressUpdate()
  一个 AsyncTask 对象只能调用一次 execute()
* 3.0 开始串行执行，但可以使用 executeOnExecutor() 变为并行。
  

