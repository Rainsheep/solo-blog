title: yml 语法
date: '2021-01-24 23:20:04'
updated: '2021-01-24 23:20:04'
tags: [yml]
permalink: /articles/2021/01/24/1611501604296.html
---
yml 或者 yaml 结尾的文件

## 1. 配置普通数据

* 语法：`key: value`
* 实例代码
  
  ```
  name: zhangsan
  ```
  
  > value 之前必须有一个空格

## 2. 配置对象数据

* 用缩进代表分级
* key 前面的空格个数不限定，在 yml 语法中，相同缩进代表同一个级别
* 实例代码
  
  ```yaml
  person: 
    name: haohao 
    age: 31 
    addr: beijing
  
  #或者（不常用）
  person: {name: haohao,age: 31,addr: beijing}
  ```

## 3. 配置 Map 数据

```yaml
map:
  key1: value1
  key2: value2
```

## 4. 配置数组数据 (List、Set)

* `- ` 代表一个数组元素
* value 与 `-` 之间有一个空格

```yaml
city:
  - beijing
  - tianjin
  - chongqing
  - shanghai
  
# 或者（不常用）
city: [beijing,tianjin,chongqing,shanghai]
```

当数组元素是对象的时候

```yaml
student:
  - name: tom
    age: 18
    addr: beijing
  - name: lucy
    age: 17
    addr: tianjin
    
# 或者（不常用）
student: [{name: tom,age: 18,addr: beijing},{name: lucy,age: 17,addr: tianjin}]
```



