title: Spring Security
date: '2021-01-22 14:06:21'
updated: '2021-01-24 18:59:15'
tags: [java, spring]
permalink: /articles/2021/01/22/1611295581301.html
---
参考文献：[Spring Security在Spring Boot环境下的学习](https://blog.csdn.net/qq_38490457/article/details/112811102)
示例代码：[SpringSecurity.zip](https://b3logfile.com/file/2021/01/SpringSecurity-68f36867.zip)

# 一、SSM 集成 Spring Security

## 1. 基础配置

pom.xml

```xml
<dependencies>
    <dependency>
        <groupId>org.springframework.security</groupId>
        <artifactId>spring-security-web</artifactId>
        <version>5.0.1.RELEASE</version>
    </dependency>
    <dependency>
        <groupId>org.springframework.security</groupId>
        <artifactId>spring-security-config</artifactId>
        <version>5.0.1.RELEASE</version>
    </dependency>
</dependencies>
```

Web.xml

```xml
<!-- 配置加载类路径的配置文件 -->
<context-param>
    <param-name>contextConfigLocation</param-name>
    <param-value>classpath:applicationContext.xml,classpath:spring-security.xml</param-value>
</context-param>
<filter>
    <filter-name>springSecurityFilterChain</filter-name>
    <filter-class>org.springframework.web.filter.DelegatingFilterProxy</filter-class>
</filter>
<filter-mapping>
    <filter-name>springSecurityFilterChain</filter-name>
    <url-pattern>/*</url-pattern>
</filter-mapping>
```

## 2. Spring-security

**认证授权由 spring-security 来控制 controller 层，我们写 service 和 dao 层就好**

如果我们不自己 写登录界面，可以使用框架默认给我们提供的登录界面

```xml
<?xml version="1.0" encoding="UTF-8"?>
<beans xmlns="http://www.springframework.org/schema/beans"
       xmlns:security="http://www.springframework.org/schema/security"
       xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
       xsi:schemaLocation="http://www.springframework.org/schema/beans
    http://www.springframework.org/schema/beans/spring-beans.xsd
    http://www.springframework.org/schema/security
    http://www.springframework.org/schema/security/spring-security.xsd">

    <!-- 开启方法级权限控制注解使用，稍后讲解 -->
    <security:global-method-security pre-post-annotations="enabled" jsr250-annotations="enabled"
                                     secured-annotations="enabled"/>

    <!-- 配置不拦截的资源 -->
    <security:http pattern="/login.jsp" security="none"/>
    <security:http pattern="/failer.jsp" security="none"/>
    <security:http pattern="/css/**" security="none"/>
    <security:http pattern="/img/**" security="none"/>
    <security:http pattern="/plugins/**" security="none"/>

    <!--
        配置具体的规则
        auto-config="true"	不用自己编写登录的页面，框架提供默认登录页面
        use-expressions="false"	是否使用SPEL表达式
    -->
    <security:http auto-config="true" use-expressions="true">
        <!-- 配置具体的拦截的规则 pattern="请求路径的规则" access="访问系统的人，必须有ROLE_USER的角色" -->
        <security:intercept-url pattern="/**" access="hasAnyRole('ROLE_USER','ROLE_ADMIN')"/>

        <!-- 定义跳转的具体的页面 
            登录界面
            登录url
            默认主页
            登录失败界面
            登录成功界面
        -->
        <security:form-login
                login-page="/login.jsp"
                login-processing-url="/login.do"
                default-target-url="/pages/main.jsp"
                authentication-failure-url="/failer.jsp"
                authentication-success-forward-url="/pages/main.jsp"
        />

        <!-- 关闭跨域请求 -->
        <security:csrf disabled="true"/>
        <!-- 退出 -->
        <security:logout invalidate-session="true" logout-url="/logout.do" logout-success-url="/login.jsp"/>

    </security:http>

    <!-- 配置加密类 -->
    <bean id="passwordEncoder" class="org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder"/>

    <!-- 切换成数据库中的用户名和密码 -->
    <security:authentication-manager>
        <!--   user-service-ref 为实现用户登录的类  -->
        <security:authentication-provider user-service-ref="userService">
            <!-- 配置加密的方式-->
            <security:password-encoder ref="passwordEncoder"/>
        </security:authentication-provider>
    </security:authentication-manager>
    
    <!-- <bean id="webexpressionHandler" class="org.springframework.security.web.access.expression.DefaultWebSecurityExpressionHandler" />-->
    <!-- 提供了入门的方式，在内存中存入用户名和密码
    <security:authentication-manager>
    	<security:authentication-provider>
    		<security:user-service>
    			<security:user name="admin" password="{noop}admin" authorities="ROLE_USER"/>
    		</security:user-service>
    	</security:authentication-provider>
    </security:authentication-manager>
    -->

</beans>
```

## 3. 使用数据库认证

在 Spring Security 中如果想要使用数据进行认证操作，有很多种操作方式，这里我们介绍使用UserDetails、UserDetailsService来完成操作。

UserDetails

```java
public interface UserDetails extends Serializable {
  Collection<? extends GrantedAuthority> getAuthorities();
  String getPassword();
  String getUsername();
  boolean isAccountNonExpired();
  boolean isAccountNonLocked();
  boolean isCredentialsNonExpired();
  boolean isEnabled();
}
```

UserDetails 是一个接口，我们可以认为 UserDetails 作用是于封装当前进行认证的用户信息，但由于其是一个接口，所以我们可以对其进行实现，也可以使用 Spring Security 提供的一个 UserDetails 的实现类 User 来完成，以下是 User 类的部分代码

```java
public class User implements UserDetails, CredentialsContainer { 
    private String password; 
    private final String username; 
    private final Set<GrantedAuthority> authorities; // 用户所拥有的权限
    private final boolean accountNonExpired; //帐户是否过期 
    private final boolean accountNonLocked; //帐户是否锁定 
    private final boolean credentialsNonExpired; //认证是否过期 
    private final boolean enabled; //帐户是否可用
｝
```

UserDetailsService

```java
public interface UserDetailsService { 
    UserDetails loadUserByUsername(String username) throws UsernameNotFoundException; 
}
```

我们需要定义一个 service 来实现 UserDetilsService，这个 service 的 loadUserByUsername 返回 UserDetails 的实现类对象 User

看一个例子

```java
public interface IUserService extends UserDetailsService {}
```

```java
@Service("userService")
@Transactional
public class UserServiceImpl implements IUserService {

    @Autowired
    private IUserDao userDao;

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        UserInfo userInfo = null;
        userInfo = userDao.findByUsername(username);
        //处理自己的用户对象封装成UserDetails
        User user = new User(userInfo.getUsername(), userInfo.getPassword(), userInfo.getStatus() != 0, true, true, true, getAuthority(userInfo.getRoles()));
        return user;
    }

    //作用就是返回一个List集合，集合中装入的是角色描述
    public List<SimpleGrantedAuthority> getAuthority(List<Role> roles) {
        List<SimpleGrantedAuthority> list = new ArrayList<>();
        for (Role role : roles) {
            list.add(new SimpleGrantedAuthority("ROLE_" + role.getRoleName()));
        }
        return list;
    }
}
```

## 4. 服务器端方法级权限控制

在服务器端我们可以通过 Spring security 提供的注解对方法来进行权限控制。Spring Security 在方法的权限控制上

支持三种类型的注解，JSR-250 注解、@Secured 注解和支持表达式的注解。

### 4.1 开启注解使用

这三种注解默认都是没有启用的，需要单独通过 global-method-security 元素的对应属性进行启用

**配置文件开启**

```xml
<security:global-method-security pre-post-annotations="enabled" jsr250-annotations="enabled"
                                 secured-annotations="enabled"/>
```

**注解开启**

注解开启

@EnableGlobalMethodSecurity ：Spring Security 默认是禁用注解的，要想开启注解，需要在继承 WebSecurityConfifigurerAdapter的类上加 @EnableGlobalMethodSecurity 注解，并在该类中将 AuthenticationManager 定义为 Bean。

### 4.2 JSP-250 注解

* @RolesAllowed 表示访问对应方法时所应该具有的角色，例如 `@RolesAllowed({"USER", "ADMIN"}) `
* @PermitAll 表示允许所有的角色进行访问，也就是说不进行权限控制
* @DenyAll 是和 PermitAll 相反的，表示无论什么角色都不能访问

### 4.3 支持表达式注解

* @PreAuthorize 在方法调用之前,基于表达式的计算结果来限制对方法的访问
  
  ```java
  @PreAuthorize("#userId == authentication.principal.userId or hasAuthority(‘ADMIN’)")
  void changePassword(@Param("userId") long userId ){ } 
  // 这里表示在 changePassword 方法执行之前，判断方法参数 userId 的值是否等于 principal 中保存的当前用户的 userId
  // 或者当前用户是否具有 ROLE_ADMIN 权限，两种符合其一，就可以访问该方法。
  ```
* @PostAuthorize 允许方法调用,但是如果表达式计算结果为 false ,将抛出一个安全性异常
  
  ```java
  @PostAuthorize 
  User getUser("returnObject.userId == authentication.principal.userId or hasPermission(returnObject, 'ADMIN')");
  ```
* @PostFilter 允许方法调用,但必须按照表达式来过滤方法的结果
* @PreFilter 允许方法调用,但必须在进入方法之前过滤输入值

### 4.4  Secured 注解

@Secured 注解标注的方法进行权限控制的支持，其值默认为 disabled。

```java
@Secured("IS_AUTHENTICATED_ANONYMOUSLY") 
public Account readAccount(Long id); 
@Secured("ROLE_TELLER")
```

## 5. 页面标签权限控制

在 jsp 页面中我们可以使用 spring security 提供的权限标签来进行权限控制

### 5.1 导入

maven 导入

```xml
<dependency>
    <groupId>org.springframework.security</groupId>
    <artifactId>spring-security-taglibs</artifactId>
    <version>version</version>
</dependency>
```

页面导入

````jsp
<%@taglib uri="http://www.springframework.org/security/tags" prefix="security"%>
````

### 5.2 常用标签

**authentication 标签**

```html
<security:authentication property="" htmlEscape="" scope="" var=""/>
```

* property： 只允许指定 Authentication 所拥有的属性，可以进行属性的级联获取，如“principle.username”，不允许直接通过方法进行调用
* htmlEscape：表示是否需要将 html 进行转义。默认为 true。
* scope：与 var 属性一起使用，用于指定存放获取的结果的属性名的作用范围，默认我 pageContext。Jsp 中拥有的作用范围都进行进行指定
* var： 用于指定一个属性名，这样当获取到了 authentication 的相关信息后会将其以 var 指定的属性名进行存放，默认是存放在 pageConext 中

**authorize 标签**

authorize 是用来判断普通权限的，通过判断用户是否具有对应的权限而控制其所包含内容的显示

```html
<security:authorize access="" method="" url="" var=""></security:authorize>
```

* access： 需要使用表达式来判断权限，当表达式的返回结果为 true 时表示拥有对应的权限
* method：method 属性是配合 url 属性一起使用的，表示用户应当具有指定 url 指定 method 访问的权限，method 的默认值为GET，可选值为 http 请求的7种方法
* url：url 表示如果用户拥有访问指定 url 的权限即表示可以显示 authorize 标签包含的内容
* var：用于指定将权限鉴定的结果存放在 pageContext 的哪个属性中

**accesscontrollist**

accesscontrollist 标签是用于鉴定 ACL 权限的。其一共定义了三个属性：hasPermission、domainObject 和 var，其中前两个是必须指定的。

```html
<security:accesscontrollist hasPermission="" domainObject="" var=""></security:accesscontrollist>
```

* hasPermission：hasPermission 属性用于指定以逗号分隔的权限列表
* domainObject：domainObject 用于指定对应的域对象
* var：var则是用以将鉴定的结果以指定的属性名存入pageContext中，以供同一页面的其它地方使用

# 二、spring-boot 集成 spring-security

待更新。。。

