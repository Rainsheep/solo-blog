title: office2019安装级激活教程
date: '2019-12-02 22:46:36'
updated: '2019-12-02 22:46:36'
tags: [windows, 软件教程]
permalink: /articles/2019/12/02/1575297996107.html
---
# 系统信息

时间：2019/11/10
系统：windows10 1903 版本
软件：office tool plus v7.2
链接：[https://pan.baidu.com/s/1-lnLWdEpwb_IPRgzND5Icw](https://pan.baidu.com/s/1-lnLWdEpwb_IPRgzND5Icw)
提取码：ee4m

[视频教程](https://www.bilibili.com/video/av70735331/)
[文字教程](https://coolhub.top/archives/15)

# 我的教程

首先使用卸载工具卸载电脑上的 office 和 wps,然后进软件，点工具箱
![null](https://img-blog.csdnimg.cn/2019111000585760.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3kyMDE2MTk4MTk=,size_16,color_FFFFFF,t_70)

以防万一，箭头所指全都清除一遍，我电脑原来 2016 版本
![null](https://img-blog.csdnimg.cn/20191110010003567.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3kyMDE2MTk4MTk=,size_16,color_FFFFFF,t_70)

回去点部署，如下配置(自己选择所需)，语言包不需要选择
![null](https://img-blog.csdnimg.cn/20191110010137230.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3kyMDE2MTk4MTk=,size_16,color_FFFFFF,t_70)

点开始 部署即可。

激活参考：[http://www.pig66.com/2019/145_0321/17865316.html](http://www.pig66.com/2019/145_0321/17865316.html)

先安装许可证
![null](https://img-blog.csdnimg.cn/2019111001034523.png)

安装完成后，右上角说明寻找对应许可证，
![null](https://img-blog.csdnimg.cn/20191110010419586.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3kyMDE2MTk4MTk=,size_16,color_FFFFFF,t_70)

填入点击安装密钥
![null](https://img-blog.csdnimg.cn/20191110010457194.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3kyMDE2MTk4MTk=,size_16,color_FFFFFF,t_70)

填写 kms 服务器地址，自己找，我提供一个图
![null](https://imgconvert.csdnimg.cn/aHR0cDovL3VwbG9hZC5waWc2Ni5jb20vdG91dGlhby8xOTUyMDM1LWZkMGFmNTk4ODM4NzU2MjUyNjc2NjA1OThmMzUyODU1?x-oss-process=image/format,png)

点击设定服务器地址
![null](https://img-blog.csdnimg.cn/2019111001073590.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3kyMDE2MTk4MTk=,size_16,color_FFFFFF,t_70)
点激活即可
