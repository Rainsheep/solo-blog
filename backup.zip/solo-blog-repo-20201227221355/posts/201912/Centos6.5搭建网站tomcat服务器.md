title: Centos6.5搭建网站（tomcat服务器）
date: '2019-12-02 22:12:12'
updated: '2019-12-02 22:12:12'
tags: [centos]
permalink: /articles/2019/12/02/1575295932463.html
---
# Web 服务器的选择

考虑到这学期所学课程 Java Web 和 JSP，考虑到 Tomcat 部署简单、安全管理、易操作、集成方便等优点，决定搭建 Tomcat 服务器，小巧轻便，主要用来运行 HTML、CSS、js、JSP、Servlet 等组成的项目。

# 将域名解析至服务器 IP

域名为阿里云域名，服务器为海外服务器，将域名解析至 IP 即可实现用域名访问 IP，绑定完成以后使用 ping 命令验证域名能否访问 IP。

# 安装 jdk，配置 jdk 环境

进 [JDK链接](https://www.oracle.com/technetwork/java/javase/downloads/jdk8-downloads-2133151.html)，下载 Linux 环境的 jdk 压缩包，通过 FileZilla 工具上传到服务器的/root 目录下。
使用命令`tar zxvf jdk-8u211-linux-x64.tar.gz`解压文件,并使用命令 rm jdk-8u211-linux-x64.tar.gz 删除压缩包。
输入命令`vim /etc/profile`打开配置文件，在尾部增添环境变量：

```shell
JAVA_HOME=/root/jdk1.8.0_211/
CLASSPATH=.:$JAVA_HOME/jre/lib/rt.jar:$JAVA_HOME/lib/dt.jar:$JAVA_HOME/lib/tools.jar
PATH=$PATH:$JAVA_HOME/bin
```

按 ESC 进入末行模式，输入:wq 保存并退出。
输入`source  /etc/profile`加载配置文件，输入命令 Java -version 验证是否安装成功。

# 安装 Tomcat 服务器

在 Tomcat 官网下载 Tomcat 安装包。
利用工具 FileZilla 将压缩包上传至服务器 root 目录下。
运行命令`tar -zxvf apache-tomcat-8.5.40.tar.gz`进行压缩包解压，运行`rm apache-tomcat-8.5.40.tar.gz`进行压缩包的删除。
进入 Tomcat 目录下，运行 Tomcat 启动脚本。
Tomcat 启动成功，此时通过 173.82.151.40:8080 发现访问不进入。
发现是因为防火墙原因导致 Tomcat 访问不了，需要打开防火墙的 8080 端口，命令如下：
`/sbin/iptables -I INPUT -p tcp --dport 8080 -j ACCEPT`
添加后保存：
`/etc/rc.d/init.d/iptables save`
查看打开的端口：
`/etc/init.d/iptables status`
此时浏览器再次访问 173.82.151.40:8080。
访问成功，Tomcat 已经可以访问。

# 配置 Tomcat，部署项目，实现域名访问网站

进入/root/tomcat/conf 目录下，用 VIM 打开 server.xml 文件，进入编辑模式，修改其端口号为 80
设置 HOST，使域名解析应用，并设置域名访问的虚拟路径。
保存，退出编辑模式。
开放防火墙的 80 端口。
上传项目到/root/tomcat/webapps 目录下。
使用命令`tar zxvf rainsheep.tar.gz`解压项目。
使用`rm rainsheep.tar.gz`删除压缩包。
进入 bin 目录，运行 Tomcat 脚本，重启 Tomcat 服务。
此时，打开浏览器，访问域名[http://www.rainsheep.top](http://www.rainsheep.top/)，已经可以登录网站。

# 搭建 Web 服务器的时候遇到的一些问题

> 整个实验中，遇到问题较多，本处说两个遇到的与 CentOS 系统相关的问题。

## 问题一：服务器重新装完系统以后，发现 yum 无法使用。

解决方案：本以为是网络问题，自己设置了服务器的网络配置以后，配置完了 DNS，ping 网络发现能 ping 通，yum 依旧报错

错误提示为：Loading mirror speeds from cached hostfile Error: Cannot retrieve metalink f…

通过进入 yum 的配置文件：`vim /etc/yum.repos.d/epel.repo`，修改 htps 为 http 以后解决

## 问题二：Linux 上课时所用系统是 Centos7,防火墙操作与 Centos6 差距较大，开放端口的方式不同，CentOS7 用的是 firewall 命令，Centos6 用的为 iptables 命令，我尝试安装 firewall 失败，firewall 命令无法使用。

解决方案：使用了 Centos6 默认防火墙 iptables，使用/sbin/iptables -I INPUT -p tcp --dport 80 -j ACCEPT 更改配置文件开放防火墙端口成功
