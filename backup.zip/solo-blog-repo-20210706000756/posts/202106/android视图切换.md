title: android 视图切换
date: '2021-06-28 00:06:49'
updated: '2021-06-28 00:06:49'
tags: [android]
permalink: /articles/2021/06/28/1624810008996.html
---
参考文献：

[Android ViewSwitcher控件](https://blog.csdn.net/chennai1101/article/details/87074074)
[Android ViewFlipper类](https://blog.csdn.net/chennai1101/article/details/87075602)
[ViewAnimator教程](https://blog.csdn.net/zhanhong39/article/details/78956553)

# 1. ViewSwitcher

## 1.1 xml 使用

ViewSwitcher 继承 ViewAnimator，主要用于两个视图的切换。
ViewSwitcher 重写了 addView(View, int, ViewGroup.LayoutParams) 方法，**使其子控件不超过2个**。

通过配置属性指定切换动画

- android:inAnimation 指定进入时动画
- android:outAnimation 指定退出时动画

```xml
<ViewSwitcher
    android:id="@+id/view_switcher"
    android:layout_width="match_parent"
    android:layout_height="200dp"
    android:inAnimation="@anim/anim_enter_from_bottom"
    android:outAnimation="@anim/anim_exit_to_top">
    <ImageView
        android:layout_width="match_parent"
        android:layout_height="match_parent"
        android:src="@drawable/switcher1"
        android:scaleType="fitXY"/>
    <ImageView
        android:layout_width="match_parent"
        android:layout_height="match_parent"
        android:src="@drawable/switcher2"
        android:scaleType="fitXY"/>
</ViewSwitcher>
```

使用

```java
ImageView imageView = viewSwitcher.getNextView();
imageView.setBackgroundResource(R.drawable.a);
viewSwitcher.showNext();
```

## 1.2 setFactory 设置视图

```xml
<ViewSwitcher
    android:id="@+id/view_switcher"
    android:layout_width="match_parent"
    android:layout_height="200dp" />
```

```java
viewSwitcher.setFactory(() -> new ImageView(this));
viewSwitcher.setInAnimation(this, R.anim.anim_enter_from_top);
viewSwitcher.setOutAnimation(this, R.anim.anim_exit_to_bottom);

button.setOnClickListener(v -> {
    View view = viewSwitcher.getNextView();
    view.setBackgroundResource(R.drawable.a);
    viewSwitcher.showNext();
});
```

使用 setFactory 设置视图的时候，会先从工厂中获取两个视图，然后可以调用 `getNextView()/showNext()` 来获取和显示下一个视图。

# 2. ViewFipper

ViewSwitcher 只能用于两个视图切换，ViewFipper 可以用于多个视图切换。

ViewFlipper 继承 ViewAnimator，用于视图的轮播。

* `android:flipInterval` 指定轮播间隔时间
* `android:autoStart` 是否自动开始轮播
* `android:inAnimation` 指定进入时动画
* `android:outAnimation` 指定退出时动画

用法与上类似

* startFlipping() 用于手动开始轮播
* stopFlipping() 则停止轮播
* showNext() 和 showPrevious() 显示视图的切换。

# 3. ViewAnimator

以上两个的父类。

## 3.1 介绍

在 Android 中，ViewAnimator 是 FrameLayout 的一个子类，用来做 Views 之间的切换。它是一个变换控件的元素，帮助我们在Views之间（如 TextView,  ImageView 或者其他 layout ）添加变换。它有助于在屏幕 view 添加动画。ViewAnimator 可以在两个及以上 Views 上平滑的切换，通过合适动画，提供从一个 View 到另外一个 View 变换的方式。

```xml
<ViewAnimator
    android:id="@+id/simpleViewAnimator"
    android:layout_width="match_parent"
    android:layout_height="wrap_content">

    <!--   Add View’s Here -->

</ViewAnimator>
```

## 3.2 使用方法

**showNext()**

`showNext()` 这个方法用于展示 ViewAnimator 的下一个 view。正如我们前面讨论过的，viewanimator 可以有两个或者更多的子视图，一次只显示一个子视图，所以这个方法用于展示下一个视图。下面我们在按钮上执行点击事件并调用 showNext() 方法来显示 viewanimator 中的下一个视图。

```java
ViewAnimator simpleViewAnimator = (ViewAnimator) findViewById(R.id.simpleViewAnimator); //get the reference of ViewAnimator

Button btnNext=(Button) findViewById(R.id.buttonNext); //get the reference of Button
// set Click event on next button
btnNext.setOnClickListener(new View.OnClickListener() {

public void onClick(View v) {
// TODO Auto-generated method stub
// show the next view of ViewAnimator
simpleViewAnimator.showNext();
}
});
```

**showPrevious()**

`showPrevious()` 这个方法用于展示 ViewAnimator 的上一个 view。正如我们前面讨论过的，viewanimator 可以有两个或者更多的子视图，一次只显示一个子视图，所以这个方法用于展示上一个视图。下面我们在按钮上执行点击事件并调用 showPrevious() 方法来显示 viewanimator 中的上一个视图。

```java
ViewAnimator simpleViewAnimator = (ViewAnimator) findViewById(R.id.simpleViewAnimator); // get the reference of ViewAnimator

Button btnPrevious=(Button) findViewById(R.id.buttonPrevious); // get the reference of Button
// set Click event on next button
btnPrevious.setOnClickListener(new View.OnClickListener() {

public void onClick(View v) {
// TODO Auto-generated method stub
// show the next view of ViewFlipper
simpleViewAnimator.showPrevious();
}
});
```

**load-Animation()**

`loadAnimation(Context context, int id)` 这个方法用于定义一个动画对象，通过调 AnimationUtils 类的静态方法 loadanimation。下面我们创建一个动画对象并且使用 AnimationUtils 类加载一个动画。

```java
// Load Animation using AnimationUtils class
Animation in = AnimationUtils.loadAnimation(this, android.R.anim.slide_in_left);
Animation out = AnimationUtils.loadAnimation(this, android.R.anim.slide_out_right);
```

**setInAnimation()**

`setInAnimation(in)` 这个方法用于设置对象进入屏幕的动画。下面我们创建一个动画对象，并且使用 AnimationUtils 加载一个动画，然后设置这个动画在 ViewAnimator。

```java
ViewAnimator simpleViewAnimator = (ViewAnimator)findViewById(R.id.simpleViewAnimator); // initiate a ViewAnimator
Animation in = AnimationUtils.loadAnimation(this,android.R.anim.slide_in_left); // load an animation
simpleViewAnimator.setInAnimation(in); // set in Animation for ViewAnimator
```

**setOutAnimation()**

`setOutAnimation(out)` 这个方法和 `setInAnimation(in)` 相反。当我们显示下一个 view 时，它首先使用 `setOutAnimation()` 设置的动画移除旧的 view, 然后使用 `setInAnimation()` 设置的动画放置新的 view。

```java
ViewAnimator simpleViewAnimator = (ViewAnimator)findViewById(R.id. simpleViewAnimator); // get reference of ViewAnimator
Animation out = AnimationUtils.loadAnimation(this,android.R.anim.slide_out_right); // load an animation
simpleViewAnimator.setOutAnimation(out); // set out Animation for ViewAnimator
```

**addView()**

`addView(View child)` 这个方法用于运行时在 ViewAnimator 添加 view。下面我们创建一个 TextView，然后添加到我们的 ViewAnimator。

```java
ViewAnimator simpleViewAnimator = (ViewAnimator)findViewById(R.id.simpleViewAnimator); // get reference of ViewAnimator

TextView textView = new TextView(this); // create a TextView
textView.setText("View Animator TextView"); // set text in TextView
simpleViewAnimator.addView(textView); // add the TextView in ViewAnimator
```

**getCurrentView()**

`getCurrentView()` 这个用于获取 ViewAnimator 当前显示的子 view。下面我们获取 ViewAnimator 显示的子 view。

```java
ViewAnimator simpleViewAnimator = (ViewAnimator) findViewById(R.id.simpleViewAnimator); // get the reference of ViewAnimator
View view = simpleViewAnimator.getCurrentView(); // get current displayed child view of ViewAnimator
```

**getDisplayedChild()**

`getDisplayedChild()` 这个方法用于获取 ViewAnimator 当前显示的子 View 的 id，返回一个 int 值。下面是示例。

```java
ViewAnimator simpleViewAnimator = (ViewAnimator) findViewById(R.id.simpleViewAnimator); // get the reference of ViewAnimator
int  displayedChildIndex = simpleViewAnimator.getDisplayedChild(); // get index for current displayed child view of ViewAnimator
```

**getInAnimation()**

`getInAnimation() `此方法用于获取当前用于进入屏幕的 View 动画。这个方法返回我们通过 `setInAnimation()` 设置的进入动画。下面我们首先设置进入动画，然后获取当前进入屏幕的 View 动画。

```java
ViewAnimator simpleViewAnimator = (ViewAnimator)findViewById(R.id.simpleViewAnimator); // initiate a ViewAnimator
Animation in = AnimationUtils.loadAnimation(this,android.R.anim.slide_in_left); // load an animation
simpleViewAnimator.setInAnimation(in); // set in Animation for ViewAnimator
Animation currentInAnimation = simpleViewAnimator.getInAnimation(); // get current animation that is used to animate a View that enters the screen.
```

**getOutAnimation()**

`getOutAnimation()` 此方法用于获取当前用于退出屏幕的 View 动画。这个方法返回我们通过 `setOutAnimation()` 设置的进入动画。下面我们首先设置退出动画，然后获取当前退出屏幕的 View 动画。

```java
ViewAnimator simpleViewAnimator = (ViewAnimator)findViewById(R.id. simpleViewAnimator); // get reference of ViewAnimator
Animation out = AnimationUtils.loadAnimation(this,android.R.anim.slide_out_right); // load an animation
simpleViewAnimator.setOutAnimation(out); // set out Animation for ViewAnimator

Animation currentOutAnimation = simpleViewAnimator.getOutAnimation(); // get current animation that is used to animate a View that exits the screen.
```

**removeAllViews()**

`removeAllViews()` 这个方法用于从 ViewGroup 移除所有的子 view。下面是示例。

```java
ViewAnimator simpleViewAnimator=(ViewAnimator)findViewById(R.id. simpleViewAnimator); // get reference of ViewAnimator
simpleViewAnimator.removeAllViews(); // remove all the child views of ViewAnimator
```

**removeView()**

`removeView(View view)` 这个方法用于移除 ViewAnimator 的子 View。在这个方法，我们传递了想要移除的子 view 对象。下面我们首先获取当前 ViewAnimator 显示的子 view，然后从 viewAnimator 移除这个子 view。

```java
ViewAnimator simpleViewAnimator = (ViewAnimator) findViewById(R.id.simpleViewAnimator); // get the reference of ViewAnimator
View view=simpleViewAnimator.getCurrentView(); // get current displayed child view of ViewAnimator
simpleViewAnimator.removeView(view); // remove the current displayed child view of ViewAnimator
```

**removeViewAt()**

`removeViewAt(int index)` 这个用于移除在布局里特定位置的 view。在这个方法，我们传递想要移除的子 view 的 id。下面我们首先获取 ViewAnimator 当前显示的子 View 的 id，然后从 ViewAnimator 移除这个子 view。

```java
ViewAnimator simpleViewAnimator = (ViewAnimator) findViewById(R.id.simpleViewAnimator); // get the reference of ViewAnimator
int  displayedChildIndex = simpleViewAnimator.getDisplayedChild(); // get index for current displayed child view of ViewAnimator
simpleViewAnimator.removeViewAt(displayedChildIndex); // remove the current displayed child view of ViewAnimator
```

**setDisplayedChild()**

`setDisplayedChild(int whichChild)` 这个方法用于设置在 ViewAnimator 显示的子 View。在这个方法里，我们设值将要显示的子 View 的 id。

```java
ViewAnimator simpleViewAnimator = (ViewAnimator) findViewById(R.id.simpleViewAnimator); // get the reference of ViewAnimator
simpleViewAnimator.setDisplayedChild(1); // set the indez of current displayed child view of ViewAnimator
```

**setAnimateFirstView()**

`setAnimateFirstView(boolean animate)` 这个方法用于设置当前视图是否应在第一次显示 ViewAnimator 时进行动画。在这个方法里，我们设置 true 或者 false。下面是示例。

```java
ViewAnimator simpleViewAnimator = (ViewAnimator) findViewById(R.id.simpleViewAnimator); // get the reference of ViewAnimator
simpleViewAnimator.setAnimateFirstView(true); // set true value for setAnimateFirstView
```

使用上面的示例将看到 ViewAnimator 的首个 view 进行动画，如果你设置为 false，那么首次显示不会进行动画。

**getAnimateFirstView()**

`getAnimateFirstView() `这个方法检查当前 view 是否在第一次 viewanimator 显示时进行动画。下面我们首先在 setAnimateFirstView 设置 ture 值，然后检查当前 view 是否在第一次显示 ViewAnimator 时进行动画。

```java
ViewAnimator simpleViewAnimator = (ViewAnimator) findViewById(R.id.simpleViewAnimator); // get the reference of ViewAnimator
simpleViewAnimator.setAnimateFirstView(true); // set true value for setAnimateFirstView
Boolean isAnimateFirstTime=simpleViewAnimator.getAnimateFirstView(); // checks whether the view should animate first time or not.
```



