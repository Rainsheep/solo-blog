title: java 日志框架对比
date: '2020-11-01 00:18:42'
updated: '2020-11-01 00:39:06'
tags: [java]
permalink: /articles/2020/11/01/1604161122197.html
---
参考文献：

[Java 常用日志框架对比](https://www.jianshu.com/p/bbbdcb30bba8)

## 总述

![image](https://b3logfile.com/file/2020/10/image-6fea06ed.png)

日志接口有：commons-logging、slf4j 等

实现日志的框架有：log4j、logging(JDK 自带)、logback、log4j2 等

## 日志级别

`log4j` 定义了8个级别的log（除去 OFF 和 ALL，可以说分为6个级别），
优先级从高到低依次为：OFF、FATAL、ERROR、WARN、INFO、DEBUG、TRACE、 ALL

`ALL` 最低等级的，用于打开所有日志记录。
`TRACE` 很低的日志级别，一般不会使用。
`DEBUG` 指出细粒度信息事件对调试应用程序是非常有帮助的，主要用于开发过程中打印一些运行信息。
`INFO` 消息在粗粒度级别上突出强调应用程序的运行过程，这个可以用于生产环境中输出程序运行的一些重要信息。
`WARN` 表明会出现潜在错误的情形，有些信息不是错误信息，但是也要给开发者的一些提示。
`ERROR` 指出发生错误的信息，可能会导致系统出错或是宕机等，必须要避免
`FATAL` 指出每个严重的错误事件将会导致应用程序的退出。这个级别比较高了。重大错误，这种级别你可以直接停止程序了。
`OFF` 最高等级，用于关闭所有日志记录。

## commons-logging

Apache Commons Logging

官方地址: https://commons.apache.org/proper/commons-logging/

commons-logging 能够选择使用 log4j  还是 JDK logging。如果项目的 classpath 中包含了 log4j 的类库，就会使用 log4j，否则就使用 JDK logging。使用 commons-logging 能够灵活的选择使用那些日志方式，而且不需要修改源代码。不过现在 Apache Commons Logging 也不更新了

依赖

```xml
<dependency>
    <groupId>commons-logging</groupId>
    <artifactId>commons-logging</artifactId>
    <version>1.2</version>
</dependency>
```

使用方法

```java
public class Test {
    public static Log LOG= LogFactory.getLog(Test.class);
    public static void main(String[] args) {
        LOG.debug("debug()...");
        LOG.info("info()...");
        LOG.error("error()...");
    }
}
```

## slf4j

官网地址：https://www.slf4j.org/

SLF4J（Simple Logging Facade for Java）用作各种日志框架（java.util.logging，logback，log4j）的抽象，允许最终用户在部署时插入所需的日志框架。

依赖

```xml
<dependency>
    <groupId>org.slf4j</groupId>
    <artifactId>slf4j-log4j12</artifactId>
    <version>1.7.30</version>
    <scope>test</scope>
</dependency>
<dependency>
    <groupId>org.slf4j</groupId>
    <artifactId>slf4j-api</artifactId>
    <version>1.7.30</version>
</dependency>
```

> Springboot 项目不需要引入任何依赖都可以使用

使用方法：

```java
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
public class Test{
    private static final Logger logger = LoggerFactory.getLogger(Test.class);
    public static void main(String[] args) {
        logger.info("Current Time: " + System.currentTimeMillis());
        logger.info("Current Time: {}", System.currentTimeMillis());
        logger.trace("trace log");
        logger.warn("warn log");
        logger.debug("debug log");
        logger.error("error log");
    }
}
```

通常输出日志开销非常大，`SLF4J` 通过 `{}` 作为占位符的方式输出字符串，相比字符串拼接的方式，效率有显著的提升。

打印信息：

```
INFO pers.rainsheep.Test - Current Time: 1531731149036
INFO pers.rainsheep.Test - Current Time: 1531731149040

WARN pers.rainsheep.Test - warn log
DEBUG pers.rainsheep.Test - debug log
ERROR pers.rainsheep.Test - error log
```

## log4j

> 已过时，不深究

官网地址：https://logging.apache.org/log4j/1.2/

依赖

```xml
<dependency>
    <groupId>log4j</groupId>
    <artifactId>log4j</artifactId>
    <version>1.2.17</version>
</dependency>
```

## log4j2

官网地址：https://logging.apache.org/log4j/2.x/

Log4j 的升级版，重构 log4j 做了很多优化，提供了 logback 中可用的许多改进，同时修复了 logback 架构中的一些固有问题。

依赖

```xml
<dependency>
    <groupId>org.apache.logging.log4j</groupId>
    <artifactId>log4j-core</artifactId>
    <version>2.12.1</version>
</dependency>
<dependency>
    <groupId>org.apache.logging.log4j</groupId>
    <artifactId>log4j-api</artifactId>
    <version>2.12.1</version>
</dependency>
```

Spring boot 中自带 log4j2 依赖

```xml
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-log4j2</artifactId>
    <version>2.3.4.RELEASE</version>
</dependency>
```

## logback

官网地址：https://logback.qos.ch/

logback 和 log4j 是同一个作者创作，它是 log4j 的升级版

依赖

```xml
<dependency>
    <groupId>ch.qos.logback</groupId>
    <artifactId>logback-classic</artifactId>
    <version>1.2.3</version>
</dependency>
<dependency>
    <groupId>ch.qos.logback</groupId>
    <artifactId>logback-core</artifactId>
    <version>1.2.3</version>
</dependency>
<dependency>
    <groupId>ch.qos.logback</groupId>
    <artifactId>logback-access</artifactId>
    <version>1.2.3</version>
</dependency>
```

springboot 不需要引入，引入

```xml
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-logging</artifactId>
</dependency>
```

配置简介

如果没有配置文件，那么 logback 默认地会调用 BasicConfigurator ，创建一个最小化配置。最小化配置由一个关联到根 logger 的 ConsoleAppender 组成。输出用模式为 `%d{HH:mm:ss.SSS} [%thread] %-5level %logger{36} - %msg%n` 的 PatternLayoutEncoder 进行格式化。

官方推荐使用的 xml 名字的格式为：`logback-spring.xml` 而不是 `logback.xml`，因为带 `spring` 后缀的可以使用 `<springProfile>` 这个标签。

## 选择使用

logback 是 Spring Boot 默认的日志系统，假如对日志没有特殊要求，可以完全零配置(当然也可以自定义 logback-spring.xml 使用  SLF4J 的 logback 来输出日志)。

本人使用slf4j + log4j2
