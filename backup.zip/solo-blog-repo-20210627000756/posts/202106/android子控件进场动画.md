title: android 子控件进场动画
date: '2021-06-25 14:43:53'
updated: '2021-06-25 14:43:53'
tags: [android]
permalink: /articles/2021/06/25/1624603433858.html
---
参考文献：[View 动画几种特殊使用场景](https://github.com/OCNYang/Android-Animation-Set/blob/master/view-animation/ViewAnimationUseTips.md)

## 1. 引入

LayoutAnimation 是作用于 ViewGroup 的，用来指定 ViewGroup 的子控件出现的动画

先做一个子控件出现的动画, 从之前随便选个 `activity_in.xml`：

```xml
<set xmlns:android="http://schemas.android.com/apk/res/android">
    <translate
        android:fromXDelta="0"
        android:toXDelta="0"
        android:fromYDelta="100%"
        android:toYDelta="0"
        android:duration="2000" />
    <alpha
        android:fromAlpha="0"
        android:toAlpha="1"
        android:duration="2000" />
</set>
```

准备好了动画，接下来有两种方法，也是 xml 和 java

## 2. 通过 XML

然后新建一个动画文件, 这里叫 anim_layout.xml, 这里有三个属性：

| 属性                   | 作用                                                         |
| ---------------------- | ------------------------------------------------------------ |
| android:delay          | 可以取值为数值，百分数，或百分数 p。表示两个子控件执行出场动画的间隔时间，为 0 时，所有控件的动画没有延迟全部开始执行；为 1 时表示等上一个控件动画执行完毕才开始执行下一个；为 0.5 时表示等上一个控件动画执行一半开始执行下一个。可以大于 1。。。当这个值为百分数时，如 50%，表示这个延迟时间是当前动画执行时间的 50%。。。当这个值是百分数 p 的时候，如 50%p, 表示这个延迟时间是父 View 的动画时间的 50%。 |
| android:animationOrder | 有三个值：：normal 表示按正常顺序出现。random 表示乱序出现。reverse 表示反序出现。 |
| android:animation      | 指定出现时要执行的动画                                       |

`anim_layout.xml` 文件代码, 设置上一个动画执行五分之一时开始下一个动画，倒序执行：

```xml
<layoutAnimation xmlns:android="http://schemas.android.com/apk/res/android"
    android:delay="0.2"
    android:animationOrder="reverse"
    android:animation="@anim/activity_in">
</layoutAnimation>
```

然后在 Activity 的布局文件中，将一个 LinearLayout 通过 `android:layoutAnimation` 加上了这个动画：

```xml
<LinearLayout
    android:id="@+id/ll"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:layout_below="@+id/btn_back"
    android:layoutAnimation="@anim/anim_layout"
    android:orientation="vertical">
    <Button
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:text="哈哈" />
    ...
</LinearLayout>
```

然后进入这个 Activity 时就会看到这个效果：

![s](https://raw.githubusercontent.com/OCNYang/Android-Animation-Set/master/README_Res/layout_animation1.gif)

## 3. 通过 java

这里不需要建新的文件了。觉得比上面的方便许多，效果跟上图是一样的。

```java
ll = (LinearLayout) findViewById(R.id.ll);
Animation animation = AnimationUtils.loadAnimation(this,R.anim.activity_in);
LayoutAnimationController controller = new LayoutAnimationController(animation);
controller.setDelay(0.2f);
controller.setOrder(LayoutAnimationController.ORDER_REVERSE);
ll.setLayoutAnimation(controller);
```

## 4. 更多

LayoutAnimation 适用于所有的 ViewGroup ，自然也包含 ListView、RecyclerView 等控件。上面说过 LayoutAnimation 提供的是进场动画 效果，所以只在 ViewGroup 第一次加载子 View 时显示一次，所以列表控件的 item 加载动画我们一般不使用它，我们会使用 列表 专门的 Item 加载动画， 比如 `recyclerView.setItemAnimator()` 等方式。



