title: 添加普通用户到 sudo 组
date: '2020-07-20 18:32:29'
updated: '2020-07-20 18:32:29'
tags: [Linux]
permalink: /articles/2020/07/20/1595241149790.html
---
`usermod -a -G sudo username`
