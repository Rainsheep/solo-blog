title: android 网络
date: '2021-04-13 19:38:37'
updated: '2021-04-13 19:38:37'
tags: [android]
permalink: /articles/2021/04/13/1618313917570.html
---
## 1. HttpURLConnection

```java
public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    TextView responseText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button sendRequest = (Button) findViewById(R.id.send_request);
        responseText = (TextView) findViewById(R.id.response_text);
        sendRequest.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.send_request) {
            // 使用 HttpURLConnection 发送请求
             sendRequestWithHttpURLConnection();
        }
    }

    private void sendRequestWithHttpURLConnection() {
        // 开启线程来发起网络请求
        new Thread(new Runnable() {
            @Override
            public void run() {
                HttpURLConnection connection = null;
                BufferedReader reader = null;
                try {
                    URL url = new URL("http://www.baidu.com");
                    connection = (HttpURLConnection) url.openConnection();
                    connection.setRequestMethod("GET");
                    connection.setConnectTimeout(8000);
                    connection.setReadTimeout(8000);
                    // post 携带数据
                    // connection.setRequestMethod("POST");
                    // DataOutputStream out = new DataOutputStream(connection.getOutputStream());
                    // out.writeBytes("username=admin&password=123456");
                    InputStream in = connection.getInputStream();
                    // 下面对获取到的输入流进行读取
                    reader = new BufferedReader(new InputStreamReader(in));
                    StringBuilder response = new StringBuilder();
                    String line;
                    while ((line = reader.readLine()) != null) {
                        response.append(line);
                    }
                    showResponse(response.toString());
                } catch (Exception e) {
                    e.printStackTrace();
                } finally {
                    if (reader != null) {
                        try {
                            reader.close();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                    if (connection != null) {
                        connection.disconnect();
                    }
                }
            }
        }).start();
    }

    private void showResponse(final String response) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                // 在这里进行UI操作，将结果显示到界面上
                responseText.setText(response);
            }
        });
    }

}
```

## 2. OkHttp

```java
private void sendRequestWithOkHttp() {
    new Thread(new Runnable() {
        @Override
        public void run() {
            try {
                OkHttpClient client = new OkHttpClient();

                // post 请求，需先构建出一个 RequestBody 对象来存放待提交的参数
                RequestBody requestBody = new FormBody.Builder()
                        .add("username", "admin")
                        .add("password", "123456")
                        .build();

                // request 对象可以连缀很多其他方法来丰富这个对象
                Request request = new Request.Builder()
                        // 指定访问的服务器地址是电脑本机
                        .url("http://10.0.2.2/get_data.json")
                        // .post(requestBody)
                        .build();

                // newCall() 方法创建一个新的 Call 对象，调用 execute() 获取服务器返回数据 
                Response response = client.newCall(request).execute();
                String responseData = response.body().string();
                parseJSONWithGSON(responseData);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }).start();
}
```



