title: PageHelper 使用方法
date: '2020-03-31 03:19:35'
updated: '2020-03-31 03:19:35'
tags: [Java]
permalink: /articles/2020/03/31/1585595975549.html
---
### 1. 导入坐标

```xml
<dependency>
    <groupId>com.github.pagehelper</groupId>
    <artifactId>pagehelper</artifactId>
    <version>5.1.2</version> 
</dependency>
```

### 2. 配置插件

> 配置到 spring 和 mybait 整合的配置文件中

```xml
<!--创建sqlSessionFactory-->
<bean id="sqlSessionFactory" class="org.mybatis.spring.SqlSessionFactoryBean">
<property name="dataSource" ref="dataSource"></property>
<!--配置mybatis 插件-->
<property name="plugins">
    <set>
        <!--配置pageHelper 分页插件-->
        <bean class="com.github.pagehelper.PageInterceptor">
            <property name="properties">
                <props>
                    <!--方言：-->
                    <prop key="helperDialect">mysql</prop>
                </props>
            </property>
        </bean>
    </set>
</property>
</bean>
```

### 3. 使用例子

使用 PageHelper.startPage 静态方法调用 startPage ：
特点：

1. 静态方法，传递两个参数（当前页码，每页查询条数）
2. 使用pageHelper 分页的时候，不再关注分页语句，查询全部的语句
3. 自动的对 PageHelper.startPage 方法下的第一个 sql 查询进行分页
   ```java
   PageHelper.startPage(1,5);
   //紧跟着的第一个select 方法会被分页
   List<Country> list = countryMapper.findAll();
   ```

* 也就是说再 Service 层 `PageHelper.startPage(1,5);` 语句后一定是紧跟查询语句。

Service 层示例代码：

```java
public PageInfo findPage(int page,int pageSize){
    PageHelper.startPage(page,pageSize);
    List<Company> List=companyDao.selectAll();
    PageInfo<Company> pageInfo = new PageInfo<>(list);
    return pageInfo;
}
```

返回的信息是 **pageInfo** 对象，该类是插件里的类。

### 4. PageInfo 中属性

```java
//当前页
private int pageNum;
//每页的数量
private int pageSize;
//当前页的数量
private int size;
//由于 startRow 和 endRow 不常用，这里说个具体的用法
//可以在页面中"显示 startRow 到 endRow 共 size 条数据"
//当前页面第一个元素在数据库中的行号
private int startRow;
//当前页面最后一个元素在数据库中的行号
private int endRow;
//总记录数
private long total;
//总页数
private int pages;
//结果集
private List<T> list;
//前一页
private int prePage;
//下一页
private int nextPage;
//是否为第一页
private boolean isFirstPage = false;
//是否为最后一页
private boolean isLastPage = false;
//是否有前一页
private boolean hasPreviousPage = false;
//是否有下一页
private boolean hasNextPage = false;
//导航页码数
private int navigatePages;
//所有导航页号
private int[] navigatepageNums;
//导航条上的第一页
private int navigateFirstPage;
//导航条上的最后一页
private int navigateLastPage;
```
