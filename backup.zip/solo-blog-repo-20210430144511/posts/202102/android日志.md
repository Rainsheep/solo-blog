title: android 日志
date: '2021-02-23 19:17:05'
updated: '2021-02-23 19:17:05'
tags: [android]
permalink: /articles/2021/02/23/1614079025572.html
---
## 1 日志等级

从低到高如下：

* `Log.wtf(String, String)` (永远不会发生的)
* `Log.e(String, String)`（错误）
* `Log.w(String, String)`（警告）
* `Log.i(String, String)`（信息）
* `Log.d(String, String)`（调试）
* `Log.v(String, String)`（详细）

## 2 日志使用

我们一般会将日志进行封装，进行统一管理控制(如 统一管理是否打印)。

这里我建议使用第三方 LogUtils : [https://github.com/pengwei1024/LogUtils](https://github.com/pengwei1024/LogUtils)

