title: __int64 与long long 的区别与十六进制的输入输出
date: '2019-12-03 12:26:57'
updated: '2019-12-03 12:26:57'
tags: [acm, 知识点总结]
permalink: /articles/2019/12/03/1575347217268.html
---
64位整型的定义方式有long long和__int64两种，而输出到标准输出方式有printf(“%lld”,a)，printf(“%I64d”,a)（大写的i），和cout << a三种方式。  %x有符号输入16进制无符号输出16进制

```c++
#include <stdio.h>  
int main()  
{   
    __int64 a,b; //或者long long a,b; 
    //%X代表大写十六进制输出，%x代表小写十六进制输出 
    while(scanf("%I64X%I64X",&a,&b)!=EOF)//%llx或者%I64x或者%Ix 
    {
    	if(a+b<0)printf("-%I64X\n",-a-b);//%x无符号输出16进制数 
    	else printf("%I64X\n",a+b);
    }   
    return 0;  
} 

```
