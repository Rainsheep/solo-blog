title: 个人vscode设置以及指令
date: '2019-12-04 15:01:36'
updated: '2019-12-04 15:01:36'
tags: [软件教程]
permalink: /articles/2019/12/04/1575442896111.html
---
显示所有命令：`ctrl+shift+p`

背景图插件：`background-cover`

本插件通过修改 vscode 的 CSS 文件运行，会显示 code-insiders 损坏，选择不再提醒，顶部会显示不受支持。

解决办法：

运行`ext install lehni.vscode-fix-checksums`安装插件，运行下列第一个命令然后重启即可。

`Fix Checksums: Apply` // Checks core files for changes and applies new checksums.
`Fix Checksums: Restore` // Restores original state of VSCode checkums.

配置语言：`Configure Display Language`

格式化代码：shift+alt+f

目前 json:

```
{
    //#编程字体设置
    //字体样式
    "editor.fontFamily": "Source Code Pro, Consolas, 'Courier New', monospace",
    //字体大小
    "editor.fontSize": 16,
 
    //#插件background-cover
    //图片路径
    "backgroundCover.imagePath": "c:\\Users\\10766\\Pictures\\ideaBackground\\23.jpg",
    //透明度
    "backgroundCover.opacity": 0.6,
 
    //#保存文件
    //文件自动保存
    "files.autoSave": "onFocusChange",
    //键入一行时自动格式化该行
    "editor.formatOnType": true,
 
    //#beautify插件格式化代码
    //设置html的默认格式化方式
    "[html]": {
        "editor.defaultFormatter": "HookyQR.beautify"
    },
    //格式风格
    "brace_style": "none,preserve-inline",
}

```
