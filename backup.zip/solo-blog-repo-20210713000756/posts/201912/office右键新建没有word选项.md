title: office右键新建没有word选项
date: '2019-12-04 15:06:13'
updated: '2019-12-04 15:06:13'
tags: [windows, 软件教程]
permalink: /articles/2019/12/04/1575443173749.html
---
系统：windows10 1903

office 版本：2019
1、按 “win+R” 键，打开运行，输入&quot;regedit&quot;，打开注册表编辑器

![aHR0cHM6Ly9hdHRhY2guNTJwb2ppZS5jbi9mb3J1bS8yMDE5MTAvMTUvMjIxMjUzeWVicHA4YjNycjNxcWIwMy5wbmc.png](https://img.hacpai.com/file/2019/12/aHR0cHM6Ly9hdHRhY2guNTJwb2ppZS5jbi9mb3J1bS8yMDE5MTAvMTUvMjIxMjUzeWVicHA4YjNycjNxcWIwMy5wbmc-3a34eff2.png)

2、打开 &quot;HKEY_CLASSES_ROOT&quot; ，按 Ctrl+F，搜索 “docx”。

![aHR0cHM6Ly9hdHRhY2guNTJwb2ppZS5jbi9mb3J1bS8yMDE5MTAvMTUvMjIxMzA2aHVyeW10cnVyYXVkdGFuNS5wbmc.png](https://img.hacpai.com/file/2019/12/aHR0cHM6Ly9hdHRhY2guNTJwb2ppZS5jbi9mb3J1bS8yMDE5MTAvMTUvMjIxMzA2aHVyeW10cnVyYXVkdGFuNS5wbmc-685c9678.png)

3、在结果 .doxc 上点击，不要展开，双击右侧“默认”修改为“Word.Document.12”

![aHR0cHM6Ly9hdHRhY2guNTJwb2ppZS5jbi9mb3J1bS8yMDE5MTAvMTUvMjIxMzI0YTV2anpzdjBwMHB6NWZsdS5wbmc.png](https://img.hacpai.com/file/2019/12/aHR0cHM6Ly9hdHRhY2guNTJwb2ppZS5jbi9mb3J1bS8yMDE5MTAvMTUvMjIxMzI0YTV2anpzdjBwMHB6NWZsdS5wbmc-d7659d24.png)

4、展开 docx 目录，新建项 ShellNew(会出现文件夹)，并在该目录下新建字符串值，名称为 FileName

![aHR0cHM6Ly9hdHRhY2guNTJwb2ppZS5jbi9mb3J1bS8yMDE5MTAvMTUvMjIxMzQwbzd6cGtsdHBlczZzN2V5bC5wbmc.png](https://img.hacpai.com/file/2019/12/aHR0cHM6Ly9hdHRhY2guNTJwb2ppZS5jbi9mb3J1bS8yMDE5MTAvMTUvMjIxMzQwbzd6cGtsdHBlczZzN2V5bC5wbmc-953f13c2.png)

5、回到桌面，注册，然后可以看到效果，添加了 word 的新建

![aHR0cHM6Ly9hdHRhY2guNTJwb2ppZS5jbi9mb3J1bS8yMDE5MTAvMTUvMjIxMzU4eHc2NTY0NXI0cTVxNTVnYy5wbmc.png](https://img.hacpai.com/file/2019/12/aHR0cHM6Ly9hdHRhY2guNTJwb2ppZS5jbi9mb3J1bS8yMDE5MTAvMTUvMjIxMzU4eHc2NTY0NXI0cTVxNTVnYy5wbmc-06b946ef.png)

Excel 和 ppt 的步骤和上面一样，区别的是 第 2 步搜索关键字和第 3 步的值。
Excel：文件夹 xlsx，值 Excel.Sheet.12
PPT：文件夹 pptx，值 PowerPoint.Show.12
