title: android 日志
date: '2021-02-23 19:17:05'
updated: '2021-06-26 10:32:27'
tags: [android]
permalink: /articles/2021/02/23/1614079025572.html
---
## 1 日志等级

从低到高如下：

* `Log.wtf(String, String)` (永远不会发生的)
* `Log.e(String, String)`（错误）
* `Log.w(String, String)`（警告）
* `Log.i(String, String)`（信息）
* `Log.d(String, String)`（调试）
* `Log.v(String, String)`（详细）

## 2 日志使用

我们一般会将日志进行封装，进行统一管理控制(如 统一管理是否打印)。

这里我建议使用第三方

logger: https://github.com/orhanobut/logger , 配置如下

```java
FormatStrategy formatStrategy = PrettyFormatStrategy.newBuilder()
        .showThreadInfo(true)  // (Optional) Whether to show thread info or not. Default true
        .methodCount(3)         // (Optional) 方法调用显示几行(调用栈信息). Default 2
        .methodOffset(0)        // (Optional) Hides internal method calls up to offset. Default 5，表示跳过几次最近调用信息，比如 test()方法打印的此行日志，值为 1 的话，就代表不打印 test()方法的调用信息，只打印更上面的调用方法
        .tag("MYTEST")   // Optional) Global tag for every log. Default PRETTY_LOGGER
        .build();

Logger.addLogAdapter(new AndroidLogAdapter(formatStrategy));
```

LogUtils : [https://github.com/pengwei1024/LogUtils](https://github.com/pengwei1024/LogUtils)



