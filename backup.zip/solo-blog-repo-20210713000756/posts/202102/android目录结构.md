title: android 目录结构
date: '2021-02-23 19:07:29'
updated: '2021-02-23 19:07:29'
tags: [android]
permalink: /articles/2021/02/23/1614078449721.html
---
**SDK 目录介绍**

`platform-tools` 包含 adb

`source` sdk 源码

`platforms` 包含 android.jar

**项目目录介绍**

参考：[Android项目目录结构模板以及简单说明【简单版】](https://www.cnblogs.com/whycxb/p/9739148.html)

![1.png](https://b3logfile.com/file/2021/01/1-bad9286a.png)
![2.png](https://b3logfile.com/file/2021/01/2-b899bff0.png)
![3.png](https://b3logfile.com/file/2021/01/3-96ae7647.png)
![4.png](https://b3logfile.com/file/2021/01/4-3cd6acbd.png)
![5.png](https://b3logfile.com/file/2021/01/5-662c2816.png)

`app/src/main/assets` ：静态资源，里面的代码不会被编译，而且不会在 R.java 文件下生成资源 id，需要使用 AssetsManager 类进行访问。

`app/src/main/java/包名/activity`：BaseActivity 和与项目业务无关的 activity（比如WelcomeActivity）放到包的根目录下，其他与项目业务相关的 activity 放到新建的以业务名称命名的子包目录下，如果项目比较简单，那么就统一放到 normal 包下即可。

`app/src/main/java/包名/adapter`：适配器类集合

`app/src/main/java/包名/bean`：实体类集合

`app/src/main/java/包名/dialog`：BaseDialogFragment 放到包的根目录下，其他与项目业务相关的 dialog 放到新建的以业务名称命名的子包目录下，如果项目比较简单，那么就统一放到 normal 目录下即可。

`app/src/main/java/包名/enumtype`：枚举类集合

`app/src/main/java/包名/fragment`：BaseFragment 放到包的根目录下，其他与项目业务相关的 fragment 放到新建的以业务名称命名的子包目录下，如果项目比较简单，那么就统一放到 normal 目录下即可。

`app/src/main/java/包名/listener`：监听器类集合

`app/src/main/java/包名/mvp`：mvp 模式的根目录

`app/src/main/java/包名/mvp/iview`：mvp 模式中的 V

`app/src/main/java/包名/mvp/model`：mvp 模式中的 M

`app/src/main/java/包名/presenter`：mvp 模式中的 P

`app/src/main/java/包名/utils`：常用工具类集合（注意，区别 base 中的 utils 目录，这里是仅在 app 中用到的工具类，不是通用工具类集合，通用工具类集合在 `base/utils` 目录中）

`app/src/main/java/包名/views`：自定义 view 集合（注意，区别 base 中的 views 目录，这里是仅在 app 中用到的自定义 view，不是通用自定义 view 集合，通用自定义 view 集合在 base/views 目录中）

`app/src/main/java/包名/MyApplication.java`：项目声明的自定义 Application 类（注意：项目中所有需要在自定义 Application 中声明的方法，比如引入第三方平台时一些配置，都需要写在这里，而不是 base 中的 BaseApplication 或者 thirdlib 中的 ThirdApplication 中）

`app/src/main/res`：存放资源的，需要注意，drawable-hdpi、mdpi、xhdpi、xxhdpi、xxxhdpi 目录需要自己创建，新建项目后没有的目录或者文件。

`app/src/main/res/drawable`：图片

`app/src/main/res/layout`：布局文件

`app/src/main/res/values`：包含使用 XML 格式的参数的描述文件，如 string.xml 字符串，color.xml 颜色，style.xml 风格样式等

`app/src/main/res/values/dimens.xml`：尺寸声明

`app/src/main/res/values/string.xml`：项目中用到的字符串

`app/src/main/res/values/styles.xml`：项目用到的主题和样式

`app/src/main/res/AndroidManifest.xml`：系统的控制文件，用于告诉 Android 系统 App 所包含的一些基本信息，比如组件，资源，以及需要的权限，以及兼容的最低版本的 SDK 等

`app/src/build.gradle`：gradle 构建脚本

`app/src/proguad-rules.pro`：代码混淆配置。注意：项目中所有的代码混淆配置都写在这里，不要分开在 base 或者 thirdlib 中写。

`base`：其他module都可以引用base这个module

`base/src/main/java/包名/dialog`：通用对话框集合（比如确认取消对话框等）

`base/src/main/java/包名/utils`：通用工具类集合

`base/src/main/java/包名/views`：通用自定义 view 集合

`base/src/main/java/包名/dialog`：Application 基类，主要用于不同 module 中应用 ApplicationContext 对象。

`thirdlib`：第三方平台sdk集合

`thirdlib/libs`：第三方平台 sdk 中 jar、arr 文件集合

`thirdlib/src/main/java/包名/ThirdApplication.java`：没有什么用，主要是为了以后新建子包方便。

**R.java 介绍**

此类在新版本中已经取消，找不到其位置，不过很重要。

res 目录下保存的文件大多数都会被编译，并且都会被赋予资源ID，这些资源ID被保存在 R.java 文件中。这样我们就可以在程序中通过 ID 来访问 res 类的资源。

R 类默认有 attr、drawable、layout、string 等四个静态内部类，每个静态内部类分别对应着一种资源，如layout静态内部类对应layout中的界面文件，其中每个静态内部类中的静态常量分别定义一条资源标识符，如 `public static final int main=0x7f030000;` 对应的是 layout 目录下的 `main.xml` 文件。

即当开发者在 res 目录中任何一个子目录中添加相应类型的文件之后，ADT 会在 R.java 文件中相应的内部类中 自动生成一条静态int类型的常量，对添加的文件进行索引。如果在 layout 目录下再添加一个新的界面，那么在 `public static final class layout` 中也会添加相应的静态 int 常量。相反当我们在 res 目录下删除任何一个文件，其在 R.java 中对应的记录会被 ADT 自动删除。

R.java 文件按除了有自动标示资源的索引功能之外，还有另外一个主要的功能，如果 res 目录中的某个资源在应用中没有被使用到，在该应用被编译的时候系统就不会把对应的资源编译到该应用的 APK 包中，这样可以节省 Android 手机的资源。

在 java 程序中引用R类资源：`R.resource_type.resource_name`

在 XML 文件中引用 R 资源 ID：`@[package:]type/name`

在 XML 文件中向 R 类添加资源 ID：`@+id/string_name`

