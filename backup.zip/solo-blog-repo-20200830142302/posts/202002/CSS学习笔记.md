title: CSS 学习笔记
date: '2020-02-22 23:49:24'
updated: '2020-08-28 17:03:07'
tags: [前端, 学习笔记]
permalink: /articles/2020/02/22/1582386564521.html
---
### 基本知识

* CSS 也可以通过`<style> @import "path"; </style>` 的方式导入。
* CSS 每一对属性需要用`;` 隔开，最后一对可以不加。

### CSS 选择器

* 并集选择器：`,`
  ```html
  p,span{
      color:red;
  }
  ```
* 交集选择器：`.`
  ```html
  <style>
      span.p1{
          color:red;
      }
  </style>
  <html>
      <body>
          <span>xxxx</span>
          <span class="p1">xxxx</span>
      </body>
  </html>
  ```
* 后代选择器：` `
  ```html
  #d1 span{}
  <div id="d1">
      <span></span>
  </div>
  <div>
      <span></span>
  </div>
  ```
* 子元素选择器：`>`
* 父元素选择器：`<`
* 相邻兄弟选择器：`+`
* 属性选择器：`a[href="zhi"]`，选择具有某种属性和某种值(可省略)的元素
* 伪类选择器：
  * `div:empty`，选择没有子元素的 div 元素
  * `p:not(.big, .medium)`：选择除了 class="big"，class="medium" 的 p 元素
* `<a>` 标签的伪类选择器：link、hover、active、visited
* 其他子元素选择器
  * `:first-child`：选择所有的第一个子元素
  * `p:first-child`：选择所有 p 为父元素第一个子元素的 p 元素
  * `div > p:first-child`：选择所有 p 是 div 的第一个子元素的 p 元素
  * `:last-child`：类似于 first-child
  * `:only-child`：选择父元素只有一个子元素的元素
  * `span:only-child`：选择父元素只有一个 span 的父元素的 span 元素
  * `ul > li:only-child`：选择 li 是 ul 唯一的子元素的 li 元素
  * `:nth-child(x)`：选择所有的第 x 个子元素，当 x="even" 时，表示偶数，odd 表示奇数
  * `:nth-last-child(x)`
* 选择器的优先级：内联(1000)>id 选择器(100)> 类和伪类选择器(10)> 元素选择器(1)> 通配*(0)> 继承的样式(没有)，当选择器包含多种选择器的时候，优先级相加，比如 p#p2 的优先级为 101，比#p2 高，但是不会超过他的最大数量级。
* 可在样式的最后添加！ important，则此时优先级最高。
  ```css
  .p1{
      background-color:greenyellow !important;
  }
  ```

### CSS 属性

* 字体、文本
  * `font-size`：字体大小
  * `color`：文本颜色
  * `text-align`：对其方式
  * `line-height`：行高
* 背景：`background`
  * `background: url("img/logo.jpg") no-repeat center;`
* 边框：`border`，`border-radius` 边框弧度
* 尺寸：`width`、`height`
* `vertical-align:middle`：垂直居中
* `line-height`：可用于控制块元素中文字的垂直居中。
* 内边距 padding 默认情况下会影响盒子自身的大小。使用`box-sizing: border-box;` 可以解决此问题，让 width 和 height 就是最终盒子的大小。
* CSS 样式的继承：子元素会继承祖先元素的样式，但是背景相关的样式，边框相关的样式，定位相关的样式都不会被继承。

### CSS 元素分类

* 块标签：div、p、h1-h6、hr、ul、ol、li、dl、dd、dt、form
  * 支持宽高，自上而下排列
  * 不受空格影响
  * 一般用于其他标签的容器
  * 默认宽度为 100%（独占一行）。
* 行内标签：**span**、i、**a**、b、strong、em、sub、sup、u、label、br、font
  * **不支持宽高**（宽高根据内容大小自动撑开），自左向右排列
  * 受空格影响
  * 不独占一行
  * 上下内外边距无效
* 行内块标签：img、textarea、input
  * **支持宽高**，自左向右排列
  * 受空格影响
  * 不独占一行
* 标签之间的转换
  * display：inline（转为行内元素）
  * inline-block（转为行内块元素）
  * block（转为块元素）
  * none（隐藏 不显示）

  > 注意：当元素浮动（float）时会转化成行内块元素特点。
  >

### CSS 背景

| 属性 | 作用 | 值 |
| :- | :- | :- |
| background-color | 背景颜色 | 预定义的颜色值/十六进制/RGB代码 |
| background-image | 背景图片 | url(图片路径) |
| background-repeat | 是否平铺 | repeat/no-repeat/repeat-x/repeat-y |
| background-position | 背景位置 | length/position分别是x和y坐标 |
| background-attachment | 背景附着 | scroll（背景滚动）/fixed（背景固定） |
| 背景简写 | 书写更简单 | 背景颜色 背景图片地址 背景平铺 背景滚动 背景位置 |
| 背景色半透明 | 背景颜色半透明 | background:rgba(0,0,0,0.3); 后面必须是4个值 |

### 盒子模型

* border 和 padding 都会影响盒子的真实大小
* 不设置宽度的时候，使用 padding-left 和 padding-right 不会影响盒子大小
* 外边距可以让**块级盒子**水平居中
  * 盒子必须制定了宽度
  * 盒子的左右外边距都设置为 auto，例如: margin:0 auto;
* 行内元素或者行内块元素的水平居中通过给其父元素设置 text-align:center; 实现
* 相邻块元素垂直外边距的合并
  * 上下相邻的两个块元素，他们之间的间距不是 margin-bottom 和 margin-top 之和，而是两个之间的最大值
  * 解决办法：只给一个元素设置 margin
* 嵌套块元素垂直外边距的塌陷
  * 父子元素之间的垂直外边距相邻了，子元素的外边距设置值会传给父元素
  * 解决办法1：为父元素定义上边框
  * 解决办法2：为父元素定义上内边距
  * 解决办法3：为父元素添加 overflow:hidden
* 行内元素为了兼容性，尽量只设置左右内外边距，不要设置上下内外边距

### 盒子阴影

`box-shadow:h-shadow v-shadow blur spread color inset;`

| 值 | 描述 |
| - | - |
| h-shadow | 必须，水平阴影的位置，允许负值 |
| v-shadow | 必须，垂直阴影的位置，允许负值 |
| blur | 可选，模糊距离 |
| spread | 可选，阴影的尺寸 |
| color | 可选，阴影的颜色 |
| inset | 可选，将外部阴影改为内部阴影 |

> 默认是外阴影，但是不可以设置为这个单词，否则导致阴影失效
>
> 盒子阴影不占用空间，不会影响其他盒子的排列

### 文字阴影

`text-shadow:h-shadow v-shadow blur color;`

| 值 | 描述 |
| - | - |
| h-shadow | 必须，水平阴影的位置，允许负值 |
| v-shadow | 必须，垂直阴影的位置，允许负值 |
| blur | 可选，模糊的距离 |
| color | 可选，阴影的颜色 |

### 浮动

* 浮动的元素具有行内块元素的特性
  * 如果块级盒子没有设置宽度，默认宽度和父级一样宽，但是添加浮动后，它的大小根据内容来决定
  * 浮动的元素可以设置宽高
* 一般使用标准流来进行上下布局，浮动来进行左右布局，标准流可以作为浮动的父元素来对浮动就行约束
* 一般来说，一个元素浮动了，其余的兄弟元素也要浮动
* 浮动的盒子只会影响浮动盒子后面的标准流不会影响前面的标准流
* 浮动的盒子没有**外边距合并和塌陷问题**
* 为什么要清除浮动？
  * 由于父级盒子很多情况下，不方便给高度，但是子盒子浮动又不占有位置，最后父级盒子高度为0时，就会影响下面的标准流盒子。
* 清除浮动的方法
  * 额外标签法：在浮动元素的最后加上一个空标签，赋予样式：clear:both;
  * 父元素添加 overflow:hidden，缺点：无法显示溢出的部分
  * after 伪元素法：
    ```
    .clearfix:after{
        content: "";
        display: block;
        height: 0;
        clear: both;
        visibility: hidden;
    }
    .clearfix{ /* IE6,7专有 */
        *zoom: 1;
    }
    ```
  * 双伪元素清除浮动：
    ```
    .clearfix::before,
    .clearfix:after {
        content: "";
        display: table;
    }
    .clearfix:after {
        clear: both;
    }

    .clearfix {
        /* IE6,7专有 */
        *zoom: 1;
    }
    ```

### 定位

* 定位默认在标准流和浮动的上方
* position：定位方式
* static：静态定位（默认定位）
* relative：相对定位
  * 内容元素相对于默认位置进行偏移，偏移后**原来的位置依旧会被占用**，后面的盒子仍然以标准流的方式对待它（不脱标，继续保留原来的位置）
* absolute：绝对定位
  * 相对祖先元素来移动
  * 如果没有祖先元素或者祖先元素没有定位，则以浏览器为准定位
  * 如果祖先元素有定位（相对、绝对、固定定位），则以最近一级的有定位祖先元素为参考点移动位置
  * 绝对定位不再占有原先的位置。（脱标）
* fixed：固定定位
  * 以浏览器的**可视窗口**为参照点移动元素
  * 不随着滚动条的滚动而滚动
  * 固定定位不占有原先的位置，是脱标的
* 粘性定位：sticky
  * 以浏览器的可视窗口为参照点移动元素（固定定位特点）
  * 粘性定位占有原先的位置（相对定位特点）
  * 必须添加top、left、 right、 bottom其中一个才有效
* | 定位模式 | 是否脱标 | 移动位置 | 是否常用 |
  | - | - | - | - |
  | static静态定位 | 否 | 不能使用边偏移 | 很少 |
  | relative相对定位 | 否（占有位置） | 相对于自身位置移动 | 常用 |
  | absolute绝对定位 | 是（不占有位置） | 带有定位的父级 | 常用 |
  | fixed固定定位 | 是（不占有位置） | 浏览器可视区 | 常用 |
  | sticky粘性定位 | 否（占有位置） | 浏览器可视区 | 很少 |
* 定位的特殊性
  * 绝对定位和固定定位也和浮动类似
  * 行内元素添加绝对或者固定定位，可以接设置高度和宽度
  * 块级元素添加绝对或者固定定位，如果不给宽度或者高度，默认大小是内容的大小
  * 浮动元素、绝对定位、固定定位元素的都不会触发外边距合并的问题
* 定位拓展
  * 浮动元素，只会压住它下面标准流的盒子，但是不会压住下面标准流盒子里面的文字和图片
  * 绝对定位、固定定位会压住下面标准流所有的内容

### z-index 堆叠

参考：[z-index详解](https://www.jianshu.com/p/c2145034f7da)

* z-index 堆叠上下文只有在 postion:relative/absolute/fixed 时才生效，static 时无效。
* 当父元素有 z-index 属性时，子元素的 z-index 再大也不会盖住 z-index 比父元素大的大元素。元素的 z-index 只是相对于兄弟元素而言的。

  ![1630118a08217ee973b0636.webp](https://b3logfile.com/file/2020/08/1630118a08217ee973b0636-355e646f.webp)

  如图所示，div a 的z-index值为最大，却依然会被比它小的值盖住。原因在于：**div a不会和div B比，只有它的父元素 div A 才能和div B比，div a只能和它的兄弟元素比z-index值**，所以即使div a的z-index值很大也没用，因为此时它继承了父元素的优先级。理解这一点很重要。
* z-index如果不设置就是默认值auto，那么它就**不处于堆叠上下文中**，上面的情况就会有所变化。![163011892e1b9d3202b2373.webp](https://b3logfile.com/file/2020/08/163011892e1b9d3202b2373-e00aac36.webp)

  因为div A的z-index值没有设置，默认就是auto，不会处于堆叠上下文中，所以就不会对子元素div a构成约束，div a才无需从父元素继承优先级，可以随意地和其它元素比z-index值了。

  如果z-index的值设置为0的话，该元素依然会处于堆叠上下文中，它会处于z-index为正数的元素后面，负数的前面。
* z-index为负值时不仅会处于z-index为0和正值元素的后面，还会处于非堆叠元素的后面。
* 当父元素和子元素都有定位并且父元素z-index不为auto(即父元素处于堆叠上下文中)，无论子元素的z-index为多少，肯定在父元素上方

### 显示和隐藏

* display 属性

  * display:none 隐藏对象
  * display:block 除了转换为块级元素之外，同时还有显示元素的意思
* visibility 可见性

  * visibility: visible 元素可视
  * visibility: hidden 元素隐藏，visibility 隐藏元素后，继续占用原来的位置
* overflow 溢出

  | 属性值 | 描述 |
  | - | - |
  | visible | 不剪切内容也不添加滚动条 |
  | hidden | 不显示超过对象尺寸的内容，超出的部分隐藏掉 |
  | scroll | 不管内容是否超出，总是显示滚动条 |
  | auto | 超出自动显示滚动条，不超出不显示滚动条 |

### CSS 高级样式

#### 鼠标样式

`{cursor:pointer;}`

| 属性值 | 描述 |
| - | - |
| default | 小白 默认 |
| pointer | 小手 |
| move | 移动 |
| text | 文本 |
| not-allowed | 禁止 |

#### 表单轮廓线

给表单 input 添加 outline:0; 或者 outline:none; 样式之后，就可以去掉默认的蓝色边框。

#### 防止拖拽文本域

`textarea {resize:none}` 使右下角不可以拖拽

#### vertical-align 属性应用

经常用于设置图片或者表单（行内块元素）和文字垂直对齐。

官方解释：用于设置一个元素的垂直对齐方式，但是它只针对于行内元素或者行内块元素有效。

```
vertical-align : baseline | top | middle | bottom
```

| 值 | 描述 |
| - | - |
| baseline | 默认。元素放置在父元素的基线上。 |
| top | 把元素的顶端与行中最高元素的顶端对齐 |
| middle | 把此元素放置在父元素的中部。 |
| bottom | 把元素的顶端与行中最低的元素的顶端对齐。 |

图片底部默认空白缝隙问题（img默认无法撑满父div）就是因为行内块元素会和文字的基线对齐。

#### 溢出文本省略号显示

单行：

```
/* 规定段落中的文本不进行换行 */
white-space: nowrap;
/* 超出部分隐藏 */
overflow: hidden;
/* 溢出的文字显示为省略号 */
text-overflow: ellipsis;
```

多行：

```
overflow: hidden;
text-overflow: ellipsis;
/* 弹性伸缩盒子模型显示 */
display: -webkit-box;
/* 限制在一个块元素显示的文本的行数 */
-webkit-line-clamp: 2;
/* 设置或检索伸缩盒对象的子元素的排列方式 */
-webkit-box-orient: vertical;
```

### HTML5 新特性

* 新增语义化标签
  * \<header> ：头部标签
  * \<nav>：导航标签
  * \<article>：内容标签
  * \<section>：定义文档某个区域
  * \<aside>：侧边栏标签
  * \<footer>：尾部标签
* 新增多媒体标签
  * \<audio>：音频
  * \<video>：视频

### CSS3 新特性

* 伪元素选择器：伪元素选择器可以帮助我们利用CSS创建新标签元素，而不需要HTML标签，从而简化HTML结构。

  | 选择器 | 简介 |
  | - | - |
  | ::before | 在元素内部的前面插入内容 |
  | ::after | 在元素内部的后面插入内容 |


  * before 和 after 创建一个元素，但是属于行内元素
  * before 和 after 必须有 content 属性
  * 伪元素选择器和标签选择器一样，权重为1
* box-sizing：

  * content-box：默认计算方式，盒子最终大小为width+border+padding
  * border-box：盒子最终大小为width
* 滤镜 filter：

  ```
  filter:blur(5px); blur模糊处理，数值越大越模糊
  ```
* transition 过渡：通常和伪类hover一起用，加在需要过渡的元素上，而不是hover上

  ```
  transition: 要过渡的属性  花费时间  运动曲线  何时开始
  ```


  * 属性：想要变化的css属性，宽度高度、背景颜色、内外边距都可以。如果想要所有的属性都
    变化过渡，写一个all就可以。
  * 花费时间：单位是秒（必须写单位），比如0.5s
  * 运动曲线：默认是ease（可以省略）
  * 何时开始：单位是秒（必须写单位）可以设置延迟触发时间，默认是0s（可以省略）

### 补充

* div 或 td 中内容过长，怎么以省略号显示

  ```css
  /* table添加style="table-layout: fixed" */
  /* td 或 div 添加 */
  .oneline {
      width: 100px;
      /* 规定段落中的文本不进行换行 */
      white-space: nowrap;
      /* 溢出的文字显示为省略号 */
      text-overflow: ellipsis;
      -o-text-overflow: ellipsis;
      /* 关闭滚动条 */
      overflow: hidden;
  }
  ```

  * 为 td 添加 title 属性可以做到鼠标覆盖显示全部
