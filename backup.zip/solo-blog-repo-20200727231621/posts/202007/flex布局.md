title: flex布局
date: '2020-07-26 10:39:30'
updated: '2020-07-27 23:15:49'
tags: [前端]
permalink: /articles/2020/07/26/1595731170747.html
---
参考：![](https://raw.githubusercontent.com/Rainsheep/pic-bed/master/img/2020-07-20+22:59:52+p_2020072022223122SS.gif)
[30 分钟学会 Flex 布局](https://zhuanlan.zhihu.com/p/25303493)
[flex布局](https://developers.weixin.qq.com/ebook?action=get_post_info&docid=00080e799303986b0086e605f5680a)

## 1. flex布局

在传统网页开发，我们用的是盒模型，通过display:inline | block | inline-block、 position、float来实现布局，缺乏灵活性且有些适配效果难以实现。比如像下面这种常见的信息列表，要求内容高度不确定下保持垂直居中：
![](https://b3logfile.com/file/2020/07/solofetchupload7863025995553459418-c598cd3e.png)<center><font size="2">常见的信息列表排版方式</font></center>

这种情况下，我们更建议用flex布局。

在开始介绍flex之前，为了表述方便，我们约定以下术语：采用flex布局的元素，简称为“容器”，在代码示例中以container表示容器的类名。容器内的元素简称为“项目”，在代码示例中以item表示项目的类名。

![](https://b3logfile.com/file/2020/07/solofetchupload8130638488392750406-7c993883.png)

<center><font size="2">container容器和item项目</font></center>

## 2. 基本概念

flex的目的是提供一种更灵活的布局模型，使容器能通过改变里面项目的高宽、顺序，来对可用空间实现最佳的填充，方便适配不同大小的内容区域。

在不固定高度信息的例子中，我们只需要在容器中设置以下两个属性即可实现内容不确定下的垂直居中。

```css
.container {
    display: flex;
    flex-direction: column;
    justify-content: center;
}
```

flex不单是一个属性，它包含了一套新的属性集。属性集包括用于设置容器，和用于设置项目两部分。

设置容器的属性有：

```
display:flex;

flex-direction:row（默认值） | row-reverse | column |column-reverse

flex-wrap:nowrap（默认值） | wrap | wrap-reverse

justify-content:flex-start（默认值） | flex-end | center |space-between | space-around | space-evenly

align-items:stretch（默认值） | center  | flex-end | baseline | flex-start

align-content:stretch（默认值） | flex-start | center |flex-end | space-between | space-around | space-evenly
```

设置项目的属性有：

```
order:0（默认值） | <integer>

flex-shrink:1（默认值） | <number>

flex-grow:0（默认值） | <number>

flex-basis:auto（默认值） | <length>

flex:none | auto | @flex-grow @flex-shrink @flex-basis

align-self:auto（默认值） | flex-start | flex-end |center | baseline| stretch
```

在开始介绍各个属性之前，我们需要先明确一个坐标轴。默认的情况下，水平方向的是主轴（main axis），垂直方向的是交叉轴（cross axis）。

![](https://b3logfile.com/file/2020/07/solofetchupload5486467052911464492-3d24f30c.png)

<center><font size="2">默认情况下的主轴与交叉轴</font></center>

项目是在主轴上排列，排满后在交叉轴方向换行。需要注意的是，交叉轴垂直于主轴，它的方向取决于主轴方向。

![](https://b3logfile.com/file/2020/07/solofetchupload4157632065980306180-8e9b8561.png)

<center><font size="2">项目是在主轴上排列，排满后在交叉轴方向换行</font></center>

接下来的例子如无特殊声明，我们都以默认情况下的坐标轴为例。

## 3. 容器属性

设置容器，用于统一管理容器内项目布局，也就是管理项目的排列方式和对齐方式。

### flex-direction 属性

通过设置坐标轴，来设置项目排列方向。

```
.container{
flex-direction: row（默认值） | row-reverse | column | column-reverse
}
```

row（默认值）：主轴横向，方向为从左指向右。项目沿主轴排列，从左到右排列。

row-reverse：row的反方向。主轴横向，方向为从右指向左。项目沿主轴排列，从右到左排列。

column：主轴纵向，方向从上指向下。项目沿主轴排列，从上到下排列。

column-reverse：column的反方向。主轴纵向，方向从下指向上。项目沿主轴排列，从下到上排列。

![](https://b3logfile.com/file/2020/07/solofetchupload8779266234578860006-aeb1aab4.png)
