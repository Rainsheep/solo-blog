title: Ubuntu中sudo和su免密码设置
date: '2020-07-20 15:02:44'
updated: '2020-07-20 15:28:35'
tags: [Linux]
permalink: /articles/2020/07/20/1595228564416.html
---
参考：[免密码使用sudo和su](https://www.jianshu.com/p/5d02428f313d)

### 1.sudo免密码

`vim /etc/sudoers`

在 `%sudo   ALL=(ALL:ALL) ALL` 下面加上 `username ALL=(ALL) NOPASSWD: ALL` 保存退出即可

![这里写图片描述](https://b3logfile.com/file/2020/07/solofetchupload5923675914101788336-4e1e23b8.png)

### 2.su免密码

* 切换到root权限；
* 创建group为wheel，命令为groupadd wheel；
* 将用户加入wheel group中，命令为usermod -G wheel `your_user_name`；
* 修改su的配置文件/etc/pam.d/su,增加下列项：
  ```
   auth       required   pam_wheel.so group=wheel 
  # Uncomment this if you want wheel members to be able to
  # su without a password.
   auth       sufficient pam_wheel.so trust use_uid
  ```
