title: 关闭Windows Defender教程
date: '2019-12-04 15:04:19'
updated: '2019-12-04 15:04:19'
tags: [windows]
permalink: /articles/2019/12/04/1575443059255.html
---
时间：2019/11/10

系统：windows10 1903 版本

软件：一键开启关闭 Windows Defender

链接：[https://pan.baidu.com/s/1TQ-oZMczDRh4PC8Oxy4xUQ](https://pan.baidu.com/s/1TQ-oZMczDRh4PC8Oxy4xUQ)
提取码：zg9s
教程：管理员打开软件，点击一键关闭

![20191110005137245.png](https://img.hacpai.com/file/2019/12/20191110005137245-3bf28b25.png)

效果：

![20191110005216935.png](https://img.hacpai.com/file/2019/12/20191110005216935-6702f68d.png)
