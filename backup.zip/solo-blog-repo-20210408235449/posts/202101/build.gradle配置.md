title: build.gradle 配置
date: '2021-01-22 13:55:38'
updated: '2021-01-22 13:55:38'
tags: [android]
permalink: /articles/2021/01/22/1611294937984.html
---
# 一、build.gradle 配置

## 1.1 简介

Gradle 是 Android Studio 开发工具自带的一个依赖插件，也可以进行项目、lib 和本地 jar 包的依赖，它是一个基于 Apache Ant 和 Apache Maven 概念的项目自动化建构工具。它使用一种基于 Groovy 的特定领域语言 (DSL) 来声明项目设置，抛弃了基于 XML 的各种繁琐配置，语法上更为简单。
  Android Studio下有两种 `build.gradle` 文件，一种为 project 下的，另一种为 module 下的，顾名思义前者是定义于适用于整个工程的配置文件，后者则是模块下的配置文件。

## 1.2 project 下的 build.gradle

```
buildscript {
    repositories {
        google()
        jcenter()
    }
    dependencies {
        classpath 'com.android.tools.build:gradle:3.1.2'
    }
}
allprojects {
    repositories {
        google()
        jcenter()
    }
}
task clean(type: Delete) {
    delete rootProject.buildDir
}
```

* buildscript：配置存储库和 Gradle 本身的依赖，一般此处无需我们修改。
  * repositories：配置 Gradle 的存储库，一般有 jcenter(), maven()
  * dependencies：配置了Gradle 需要使用的依赖
  * classpath：buildscript 所需的插件和依赖
* allprojects：配置存储库和项目中所有模块 (如第三方插件) 使用的依赖项或库
* task：执行的工作单元，此处是项目 clean 的时候删除 buildDir 文件夹

## 1.3 module 下的 build.gradle

```
apply plugin: 'com.android.application'    
android {
    compileSdkVersion 27
    defaultConfig {
        applicationId "com.excellence.test"
        minSdkVersion 19
        targetSdkVersion 27
        versionCode 1
        versionName "1.0"
        testInstrumentationRunner "android.support.test.runner.AndroidJUnitRunner"
    }
    buildTypes {
        release {
            minifyEnabled false
            proguardFiles getDefaultProguardFile('proguard-android.txt'), 'proguard-rules.pro'
        }
    }
}

dependencies {
    implementation fileTree(dir: 'libs', include: ['*.jar'])
    implementation 'com.android.support:recyclerview-v7:27.1.1'
    implementation 'com.android.support:appcompat-v7:27.1.1'
    implementation 'com.android.support.constraint:constraint-layout:1.1.2'
    implementation 'com.jakewharton:butterknife:5.1.1'
    testImplementation 'junit:junit:4.12'
    androidTestImplementation 'com.android.support.test:runner:1.0.2'
    androidTestImplementation 'com.android.support.test.espresso:espresso-core:3.0.2'
}
```

* apply：标明此 module 的类型。
  
  * `com.android.application`  app应用程序
  * `com.android.library`  库
  * `config.gradle` 用于给本地文件系统提供路径或到远程位置的 URL 的脚本插件
  
  > 例：项目 XXX 下有 app、common两个模块。
  > 在 app 模块下打包则 app 下的 build.gradle 头部应为：apply plugin: ‘com.android.application’
  > common 作为依赖的库，其下的 build.gradle 的头部应为：apply plugin: ‘com.android.library’
* android：android的配置；
* compileSdkVersion：编译应用使用的 sdk 版本；
* apllicationId：包名；
* minSdkVersion：支持的最小 SDK 版本，即在小于此版本的系统上不可使用；
* targertSdkVersion：目标版本；应用已兼容从 minSdkVersion 至 tartgetSdkVersion 之间所有 api 的变化；
* versionCode：版本号，只能为整型；
* versionName：版本名，字符串类型；
* testInstrumentationRunner：测试框架；
* buildType：指定生成安装文件的相关配置;
* release：发布版本配置;
* minifyEnabled：混淆设置 ture 为加混淆，false 为不加，使用混淆是为了软件的安全，在反编译下不易被读。
* proguardFiles：混淆的规则文件，表示混淆文件在 app 目录下的位置。
* dependencies：依赖的包、模块等，项目需要使用的库、包都要在此处进行关联；
* implementation：远程依赖的库；
* testImplementation：测试依赖的库；
* androidTestImplementation：测试用例库；

signingConfigs：

```
signingConfigs { //签名配置
    release { //发布版
        try {
            storeFile file(".\\platform.keystore") //签名文件在app目录下的位置，使用绝对路径也可，如：E:\1.jks
            storePassword "android" //签名证书的密码
            keyAlias "user" //签名文件中的别名
            keyPassword "pwd" //签名文件中的密码
            v1SigningEnabled true //仅验证未解压的文件内容
            v2SigningEnabled true //验证压缩文件的所有字节
        } catch (ex) {}
    }
    debug { //测试版
        try {
            storeFile file(".\\platform.keystore")
            storePassword "pwd"
            keyAlias "user"
            keyPassword "pwd"
            v1SigningEnabled true
            v2SigningEnabled true
        } catch (ex) {}
    }
}
```

# 二、 AS 3.0 上下依赖的区别

dependencies的主要用途为：

- 声明对模块的依赖关系
- 声明一个文件的依赖
- 声明一个项目依赖关系
- 从模块依赖关系中解析特定工件
- Gradle 特定依赖关系

Android Studio 3.0以下 gradle 的使用 dependencies 的方式一般为 compile，3.0以上新增了关键字 implementation 和 api，而 compile 提示已过时。

关键字 api 与 compile 功能一致，但 3.0 以上却提倡使用 Implementation，因为 Implementation 对于使用了该命令编译的依赖，对该项目有依赖的项目将无法访问到使用该命令编译的依赖中的任何程序，也就是将该依赖隐藏在内部，而不对外部公开。

通俗来讲就是假设 A 使用的是 implementation 依赖某库，B 工程依赖了 A，但 B 无法使用某库的方法，就是 implementation 依赖。反之，如果 A 使用的是compile 或者 api 依赖的某库，B 依赖了 A，那么 B 也相当于依赖了这个库。

Implementation 隐藏了不必要对外的接口，对于大型项目来说还加快了编译的速度。假设模块 B 依赖了模块 A,模块 C 依赖了模块 B，这个时候修改了模块 A 的代码，如果是使用的是 compile（API）依赖，因为 C 也能访问到 A 的接口，那么 A、B、C 都需要编译，但如果使用的是 Implementation，C 访问不到 A 的接口，那么可以只对 A 和 B 进行编译，加快了编译的速度。

# 三、依赖关键字的区别

Android3.0 以下及以上除去新增关键字 Implementation，基本无太大区别。

| 3.0以下         | 3.0以上                | 用法                                                  |
| --------------- | ---------------------- | ----------------------------------------------------- |
| 无              | implementation         | 参与编译，会打包，但依赖不具有传递性                  |
| compile         | API                    | 参与编译，会打包到 debug/release apk 中               |
| Provided        | Compile only           | 只参与编译，不会打包到 debug/release apk 中           |
| APK             | Runtime only           | 不参与编译，只会打包到 debug/release apk 中           |
| Test compile    | Test implementation    | 只参与单元测试编译，不会打包到 debug/release apk 包中 |
| Debug compile   | Debug implementation   | 只参与 debug 编译，只会打包到 debug apk 中            |
| Release compile | Release implementation | 只参与 Release 编译，只会打包到 Release apk 中        |



