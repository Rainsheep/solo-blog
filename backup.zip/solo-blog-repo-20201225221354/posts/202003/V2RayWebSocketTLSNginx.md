title: V2Ray+WebSocket+TLS+Nginx
date: '2020-03-11 12:42:27'
updated: '2020-03-11 12:46:37'
tags: [Shadowsocks, ss]
permalink: /articles/2020/03/11/1583901747768.html
---
## 一键脚本安装V2Ray+WebSocket+TLS+Nginx救活被墙VPS

提前准备：

1. 1台VPS，如搬瓦工、谷歌云、Vultr等。
2. 1个域名，付费（推荐Namesilo）或免费申请Freenom，之后解析到你的VPS IP上。
   脚本适用于：Debian 9+ / Ubuntu 18.04+ / Centos7+

### 一、BBR一键安装：

1. 更换内核需要root权限，所以如果你是普通用户的话，需要root账号权限，如果你是root账号，那就忽略这个步骤：
   `sudo -i`
2. BBR一键安装代码：
   ```shell
   wget --no-check-certificate https://raw.githubusercontent.com/cx9208/Linux-NetSpeed/master/tcp.sh && chmod +x tcp.sh && ./tcp.sh
   ```

   > 若报错运行以下代码，不报错跳过：
   > `yum -y install wget`
   > `rm -f /var/run/yum.pid`
   >

   附上脚本：
   [tcp.zip](https://img.hacpai.com/file/2020/03/tcp-558216c2.zip)
3. 重新打开脚本，查看是否运行成功：
   `./tcp.sh`

### 二、一键脚本安装 V2Ray+WebSocket+TLS+Nginx

Vmess+websocket+TLS+Nginx+Website：

```shell
bash <(curl -L -s https://raw.githubusercontent.com/wulabing/V2Ray_ws-tls_bash_onekey/master/install.sh) | tee v2ray_ins.log
```

如果提示 `curl: command not found`，那是因为没装 Curl，
ubuntu/debian 系统安装 Curl 方法:
`apt-get update -y && apt-get install curl -y`
centos 系统安装 Curl 方法:
`yum update -y && yum install curl -y`
安装好 curl 之后就能安装脚本了

附上脚本：
[install.zip](https://img.hacpai.com/file/2020/03/install-6930b75e.zip)

### 三、脚本启动方式

启动 V2ray：`systemctl start v2ray`

停止 V2ray：`systemctl stop v2ray`

启动 Nginx：`systemctl start nginx`

停止 Nginx：`systemctl stop nginx`

四、脚本相关目录

Web 目录：`/home/wwwroot/levis`

V2ray 服务端配置：`/etc/v2ray/config.json`

V2ray 客户端配置: 执行安装时所在目录下的 `v2ray_info.txt`

Nginx 目录： `/etc/nginx`

证书目录: `/data/v2ray.key` 和 `/data/v2ray.crt`

### 四、客户端配置

最新版本下载地址：https://github.com/2dust/v2rayN/releases

百度云链接：
链接：https://pan.baidu.com/s/1jWgKzKFnsGk7AKXpFaJXAw 
提取码：luqo 

