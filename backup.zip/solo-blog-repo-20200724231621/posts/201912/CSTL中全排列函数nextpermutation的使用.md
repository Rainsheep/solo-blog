title: C++STL中全排列函数next_permutation的使用
date: '2019-12-03 20:48:29'
updated: '2019-12-04 15:41:06'
tags: [STL, 知识点总结]
permalink: /articles/2019/12/03/1575377309060.html
---
next_permutation 函数

组合数学中经常用到排列，这里介绍一个计算序列全排列的函数：next_permutation（start,end），和 prev_permutation（start,end）。这两个函数作用是一样的，区别就在于前者求的是当前排列的下一个排列，后一个求的是当前排列的上一个排列。至于这里的“前一个”和“后一个”，我们可以把它理解为序列的字典序的前后，严格来讲，就是对于当前序列 pn，他的下一个序列 pn+1 满足：不存在另外的序列 pm，使 pn&lt;pm&lt;pn+1.

对于 next_permutation 函数，其函数原型为：

```
 #include <algorithm>
 bool next_permutation(iterator start,iterator end)
```

当当前序列不存在下一个排列时，函数返回 false，否则返回 true

我们来看下面这个例子：

```cpp
#include <iostream>
#include <algorithm>
using namespace std;
int main()
{
    int num[3]={1,2,3};
    do
    {
        cout<<num[0]<<" "<<num[1]<<" "<<num[2]<<endl;
    }while(next_permutation(num,num+3));
    return 0;
}

```

输出结果为：
![20150427130510043.png](https://img.hacpai.com/file/2019/12/20150427130510043-f40ff41b.png)


当我们把 while(next_permutation(num,num+3))中的 3 改为 2 时，输出就变为了：
![20150427130713826.png](https://img.hacpai.com/file/2019/12/20150427130713826-352b82cf.png)


由此可以看出，next_permutation(num,num+n)函数是对数组 num 中的前 n 个元素进行全排列，同时并改变 num 数组的值。

另外，需要强调的是，next_permutation（）在使用前需要对欲排列数组按升序排序，否则只能找出该序列之后的全排列数。比如，如果数组 num 初始化为 2,3,1，那么输出就变为了：

![20150427131704330.png](https://img.hacpai.com/file/2019/12/20150427131704330-71c4db79.png)


此外，next_permutation（node,node+n,cmp）可以对结构体 num 按照自定义的排序方式 cmp 进行排序。
