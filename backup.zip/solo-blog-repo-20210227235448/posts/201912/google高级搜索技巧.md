title: ' google高级搜索技巧'
date: '2019-12-04 14:24:37'
updated: '2019-12-04 14:24:37'
tags: [软件教程]
permalink: /articles/2019/12/04/1575440677849.html
---
1、OR 和 AND

OR: 返回的结果是包含 OR 两边的任意关键词，比如: amazon OR ebay

AND: 返回的结果是包含 AND 两边的关键词，比如: amazon AND ebay

注意：OR, AND 必须是大写

2、使用&quot;&quot;完全匹配

使用方法：”关键字”，通过给关键字加双引号的方法，得到的搜索结果就是完全按照关键字的顺序来搜。 例如：Mac “microsoft office”，谷歌会返回包括词组 microsoft office 和 词 Mac 的链接

3、使用*模糊匹配

在 Google 中搜索 &quot;amazon * guide&quot;，其中的*号代表任何文字。

返回的结果就不仅包含 Amazon Quick Start Guide 还包括 Amazon PPC Guide

4、使用 - 排除关键字

使用方法：关键字 -排除关键字 ， Tip：- 前面有空格，但后面没有空格。

5、使用 site 指定网站

例如 site:csdn.net python

6、使用 filetype 指定文件类型

使用方法：filetype:file_type search_term。比如：filetype:pdf 现代操作系统

7、使用 intitle 和 allintitle 指定标题

intitle 指令返回的是页面 title 中包含关键词的页面，使用方法：intitle:search_term。比如：intitle:现代操作系统

allintitle 搜索返回的是页面标题中包含多组关键词的文件。例如 ：allintitle:SEO 搜索引擎优化，就相当于：intitle:SEO intitle:搜索引擎优化，返回的是标题中中既包含“SEO”，也包含“搜索引擎优化”的页面。

8、intext 和 allintext
