title: Intent
date: '2021-02-23 19:03:46'
updated: '2021-02-23 19:03:46'
tags: [android]
permalink: /articles/2021/02/23/1614078226696.html
---
参考链接：[Android Intent用法总结](https://www.jianshu.com/p/67d99a82509b)

## 1 简介

Android 中提供了 Intent 机制来协助应用间的交互与通讯，Intent 负责对应用中一次操作的动作、动作涉及数据、附加数据进行描述，Android 则根据此 Intent 的描述，负责找到对应的组件，将 Intent 传递给调用的组件，并完成组件的调用。Intent 不仅可用于应用程序之间，也可用于应用程序内部的 Activity / Service 之间的交互。因此，Intent 在起着一个媒体中介的作用，专门提供组件互相调用的相关信息，实现调用者与被调用者之间的解耦。

**Intent 作用**

Intent 是一个将要执行的动作的抽象的描述，一般来说是作为参数来使用，由 Intent 来协助完成 Android 各个组件之间的通讯。比如说调用 startActivity() 来启动一个 Activity，或者由 broadcaseIntent() 来传递给所有感兴趣的 BroadcaseReceiver，再或者由 startService() / bindservice() 来启动一个后台的 service。所以可以看出来，Intent 主要是用来启动其他的 activity 或者 service，所以可以将 intent 理解成 activity 之间的粘合剂。

Intent作用的表现形式为：

- 启动 Activity
  通过 `Context.startActvity() / Activity.startActivityForResult()` 启动一个 Activity
- 启动 Service
  通过 `Context.startService()` 启动一个服务，或者通过 `Context.bindService()` 和后台服务交互
- 发送 Broadcast
  通过广播方法 `Context.sendBroadcasts() / Context.sendOrderedBroadcast() / Context.sendStickyBroadcast()` 发给Broadcast Receivers

## 2 Intent 种类

### 2.1 显式 Intent

显式，即直接指定的 activity 对应的类。

显式 Intent 通 过Component 可以直接设置需要调用的 Activity 类，可以唯一确定一个 Activity，意图特别明确，所以是显式的。设置这个类的方式可以是 Class 对象（如 SecondActivity.class），也可以是包名加类名的字符串（如 com.example.app.SecondActivity）。

* 构造方法传入 Component，最常用的方式：
  
  ```java
  Intent intent = new Intent(this, SecondActivity.class);  
  startActivity(intent);
  ```
* setComponent方法
  
  ```java
  Intent intent=new Intent();  
  // 第一个参数是应用程序的包名, 第二个是这个应用程序的主 Activity 名  
  intent.setComponent(new ComponentName("com.example.app", "com.example.app.SecondActivity"));  
   startActivity(intent);
  ```
* setClass / setClassName方法
  
  ```java
  Intent intent = new Intent();    
  intent.setClass(this, SecondActivity.class);  
  //或者intent.setClassName(this, "com.example.app.SecondActivity");  
  //或者intent.setClassName(this.getPackageName(),"com.example.app.SecondActivity");            
  startActivity(intent);
  ```

### 2.2 隐式 Intent

隐式，不明确指定启动哪个 Activity，而是设置 Action、Data、Category，让系统来筛选出合适的 Activity。筛选是根据所有的 `<intent-filter>` 来筛选。

下面以 Action 为例：

AndroidManifest.xml 文件中，首先被调用的 Activity 要有一个带有 intent-filter 并且包含 action 的 Activity，设定它能处理的 Intent，并且 category 设为 android.intent.category.DEFAULT。action 的 name 是一个字符串，可以自定义(为了防止应用程序之间互相影响，一般命名方式是 包名+Action 名)，例如这里设成为 Intent.ACTION_DIAL(拨号)：

```xml
<activity android:name="com.example.app.SecondActivity">  
    <intent-filter>  
        <action android:name="Intent.ACTION_DIAL"/>  
        <category android:name="android.intent.category.DEFAULT"/>  
    </intent-filter>  
</activity>
```

然后，在 MainActivity，才可以通过这个 action name 找到上面的 Activity。下面两种方式分别通过 setAction 和构造方法方法设置 Action，两种方式效果相同。

* setAction方法：表明我们想要启动能够响应设置的这个 action 的活动，并在清单文件 AndroidManifest.xml 中设置 action 属性。如：(打开一个拨号界面)
  
  ```java
  Intent intent = new Intent();  
  intent.setAction("Intent.ACTION_DIAL");  
  startActivity(intent);
  ```
* 构造方法直接设置 Action
  
  ```java
  Intent intent = new Intent("Intent.ACTION_DIAL");  
  startActivity(intent);
  ```
* setData 方法：通常是 URI 格式定义的操作数据。（只要设置 setAction 就要在清单文件中设置 action 属性）
  
  ```java
  Intent intent = new Intent();
  intent.setAction(Intent.ACTION_DIAL);
  intent.setData(Uri.parse("tel:10086"));
  // Intent intent = new Intent(Intent.ACTION_DIAL,Uri.parse("tel:10086"));
  startActivity(intent);
  ```
* setType 方法：指定数据类型，选出适合的应用来
  
  ```java
  Intent intent = new Intent();
  intent.setAction(Intent.ACTION_SEND);
  intent.setType("text/plain");
  startActivity(intent);
  ```
* putExtra 方法：把要传递的数据暂存在 Intent 中，启动了另一个活动后，只需要把这些数据再从 Intent 中取出就可以了

## 3 Intent 属性

Intent对象大致包括7大属性：Action（动作）、Data（数据）、Category（类别）、Type（数据类型）、Component（组件）、Extra（扩展信息）、Flag（标志位）。其中最常用的是 Action 属性和 Data 属性。

### 3.1 Action

用来表现意图的行动
一个字符串变量，可以用来指定 Intent 要执行的动作类别。常见的 action 有：
Activity Actions：

| 类型              | 作用                                     |
| ----------------- | ---------------------------------------- |
| ACTION_MAIN       | 表示程序入口                             |
| ACTION_VIEW       | 自动以最合适的方式显示 Data              |
| ACTION_EDIT       | 提供可以编辑的                           |
| ACTION_PICK       | 选择一个一条 Data，并且返回它            |
| ACTION_DAIL       | 显示 Data 指向的号码在拨号界面 Dailer 上 |
| ACTION_CALL       | 拨打 Data 指向的号码                     |
| ACTION_SEND       | 发送 Data 到指定的地方                   |
| ACTION_SENDTO     | 发送多组 Data 到指定的地方               |
| ACTION_RUN        | 运行 Data，不管 Data 是什么              |
| ACTION_SEARCH     | 执行搜索                                 |
| ACTION_WEB_SEARCH | 执行网上搜索                             |
| ACTION_SYNC       | 执同步一个 Data                          |
| ACTION_INSERT     | 添加一个空的项到容器中                   |

Broadcast Actions：

| 类型                | 作用                                                         |
| ------------------- | ------------------------------------------------------------ |
| ACTION_TIME_TICK    | 当前时间改变，并即时发送时间，只能通过系统发送。调用格式 android.intent.action.TIME_TICK |
| ACTION_TIME_CHENGED | 设置时间。调用格式 android.intent.action.TIME_SET            |

### 3.2 Data

表示与动作要操纵的数据
一个 URI 对象是一个引用的 data 的表现形式，或是 data 的 MIME 类型；data 的类型由 Intent 的 action 决定。

### 3.3 Category

用来表现动作的类别
一个包含 Intent 额外信息的字符串，表示哪种类型的组件来处理这个 Intent。任何数量的 Category 描述都可以添加到 Intent 中，但是很多 intent 不需要 category，下面列举一些常用的 category：

| 类型                | 作用                                                         |
| ------------------- | ------------------------------------------------------------ |
| CATEGORY_DEFAULT    | 把一个组件 Component 设为可被 implicit 启动的                |
| CATEGORY_LAUNCHER   | 把一个 action 设置为在顶级执行。并且包含这个属性的 Activity 所定义的 icon 将取代 application 中定义的 icon |
| CATEGORY_BROWSABLE  | 当 Intent 指向网络相关时，必须要添加这个类别                 |
| CATEGORY_HOME       | 使 Intent 指向 Home 界面                                     |
| CATEGORY_PREFERENCE | 定义的 Activity 是一个偏好面板 Preference Panel              |

### 3.4 Type

指定数据类型
一般 Intent 的数据类型能够根据数据本身进行判定，但是通过设置这个属性，可以强制采用显式指定的类型而不再进行推导。

### 3.5 Component

目的组件
指定 Intent 的目标组件名称，当指定了这个属性后，系统将跳过匹配其他属性，而直接匹配这个属性来启动对应的组件。

### 3.6 Extra

扩展信息
Intent 可以携带的额外 key-value 数据，你可以通过调用 putExtra 方法设置数据，每一个 key 对应一个 value数据。你也可以通过创建 Bundle 对象来存储所有数据，然后通过调用 putExtras 方法来设置数据。

| 类型                | 作用                                       |
| ------------------- | ------------------------------------------ |
| EXTRA_BCC           | 存放邮件密送人地址的字符串数组             |
| EXTRA_CC            | 存放邮件抄送人地址的字符串数组             |
| EXTRA_EMAIL         | 存放邮件地址的字符串数组                   |
| EXTRA_SUBJECT       | 存放邮件主题字符串                         |
| EXTRA_TEXT          | 存放邮件内容                               |
| EXTRA_KEY_EVENT     | 以 KeyEvent 对象方式存放触发 Intent 的按键 |
| EXTRA_PHONE_ NUMBER | 存放调用 ACTION_CALL 时的电话号码          |

### 3.7 Flag

期望这个意图的运行模式
用来指示系统如何启动一个 Activity，可以通过 setFlags() 或者 addFlags() 可以把标签 flag 用在 Intent 中。

| 类型                      | 作用                                                 |
| ------------------------- | ---------------------------------------------------- |
| FLAG_ACTIVITY_CLEAR_TOP   | 相当于 SingleTask                                    |
| FLAGE_ACTIVITY_SINGLE_TOP | 相当于 SingleTop                                     |
| FLAG_ACTIVITY_NEW_TASK    | 类似于 SingleInstance                                |
| FLAG_ACTIVITY_NO_HISTORY  | 当离开该 Activity 后，该 Activity 将被从任务栈中移除 |

## 4 Intent 用法

### 4.1 startActivityForResult 用法

startActivityForResult 主要用来从 FirstActivity 跳转到 SecondActivity 然后返回 FirstActivity 并且获取从 SecondActivity 传回来的参数。

使用方法：如下从 ClockManagerActivity 跳转到 NewMapActivity 并且传 address 值。

ClockManagerActivity：

```java
Intent intent = new Intent(ClockManagerActivity.this,NewMapActivity.class);
intent.putExtra("address",position);
// 请求码自定义，用来区分来自哪个 Activity
startActivityForResult(intent,3);
```

```java
// 当请求码为 3 且结果码为 RESULT_OK 时，获取从 NewMapActivity 传过来的 position 值
@Override
protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
    super.onActivityResult(requestCode, resultCode, data);
    if (requestCode == 3 && resultCode == RESULT_OK) {
        String position = data.getStringExtra("position");
        mTvClockInAddress.setText(position);
    }
}
```

NewMapActivity：

```java
// 获取从 ClockManagerActivity 传过来的 address 值
String position = getIntent().getStringExtra("address");
// 设置 resultCode 码，传递 position 参数，关闭当前 Activity
Intent intent = getIntent();
String s = addressInfo.addressName + addressInfo.title;
intent.putExtra("position", s);
setResult(RESULT_OK,intent);
finish();
```

### 4.2 Intent 例子

**调用拨号程序**

```java
// 调用拨打电话，给10010拨打电话
Uri uri = Uri.parse("tel:10010");
Intent intent = new Intent(Intent.ACTION_DIAL, uri);
startActivity(intent);
```

```java
// 直接拨打电话，需要加上权限 <uses-permission id="android.permission.CALL_PHONE" /> 
Uri callUri = Uri.parse("tel:10010"); 
Intent intent = new Intent(Intent.ACTION_CALL, callUri);
```

**发送短信或者彩信**

```java
// 给10010发送内容为“Hello”的短信
Uri uri = Uri.parse("smsto:10010");
Intent intent = new Intent(Intent.ACTION_SENDTO, uri);
intent.putExtra("sms_body", "Hello");
startActivity(intent);
```

```java
// 发送彩信（相当于发送带附件的短信）
Intent intent = new Intent(Intent.ACTION_SEND);
intent.putExtra("sms_body", "Hello");
Uri uri = Uri.parse("content://media/external/images/media/23");
intent.putExtra(Intent.EXTRA_STREAM, uri);
intent.setType("image/png");
startActivity(intent);
```

**通过浏览器打开网页**

```java
// 打开百度主页
Uri uri = Uri.parse("https://www.baidu.com");
Intent intent = new Intent(Intent.ACTION_VIEW, uri);
startActivity(intent);
```

**发送电子邮件**

```java
// 给someone@domain.com发邮件
Uri uri = Uri.parse("mailto:someone@domain.com");
Intent intent = new Intent(Intent.ACTION_SENDTO, uri);
startActivity(intent);
```

```java
// 给someone@domain.com发邮件发送内容为“Hello”的邮件
Intent intent = new Intent(Intent.ACTION_SEND);
intent.putExtra(Intent.EXTRA_EMAIL, "someone@domain.com");
intent.putExtra(Intent.EXTRA_SUBJECT, "Subject");
intent.putExtra(Intent.EXTRA_TEXT, "Hello");
intent.setType("text/plain");
startActivity(intent);
```

```java
// 给多人发邮件
Intent intent=new Intent(Intent.ACTION_SEND);
String[] tos = {"1@abc.com", "2@abc.com"}; // 收件人
String[] ccs = {"3@abc.com", "4@abc.com"}; // 抄送
String[] bccs = {"5@abc.com", "6@abc.com"}; // 密送
intent.putExtra(Intent.EXTRA_EMAIL, tos);
intent.putExtra(Intent.EXTRA_CC, ccs);
intent.putExtra(Intent.EXTRA_BCC, bccs);
intent.putExtra(Intent.EXTRA_SUBJECT, "Subject");
intent.putExtra(Intent.EXTRA_TEXT, "Hello");
intent.setType("message/rfc822");
startActivity(intent);
```

**显示地图与路径规划**

```java
// 打开Google地图中国北京位置（北纬39.9，东经116.3）
Uri uri = Uri.parse("geo:39.9,116.3");
Intent intent = new Intent(Intent.ACTION_VIEW, uri);
startActivity(intent);
```

```java
// 路径规划：从北京某地（北纬39.9，东经116.3）到上海某地（北纬31.2，东经121.4）
Uri uri = Uri.parse("http://maps.google.com/maps?f=d&saddr=39.9 116.3&daddr=31.2 121.4");
Intent intent = new Intent(Intent.ACTION_VIEW, uri);
startActivity(intent);
```

**播放多媒体**

```java
Intent intent = new Intent(Intent.ACTION_VIEW);
Uri uri = Uri.parse("file:///sdcard/foo.mp3");
intent.setDataAndType(uri, "audio/mp3");
startActivity(intent);

Uri uri = Uri.withAppendedPath(MediaStore.Audio.Media.INTERNAL_CONTENT_URI, "1");
Intent intent = new Intent(Intent.ACTION_VIEW, uri);
startActivity(intent);
```

**选择图片**

```java
Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
intent.setType("image/*");
startActivityForResult(intent, 2);
```

**拍照**

```java
// 打开拍照程序
Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
startActivityForResult(intent, 1);
```

```java
// // 取出照片数据
@Override
protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
    super.onActivityResult(requestCode, resultCode, data);

    if (resultCode == Activity.RESULT_OK) {
        Bundle extras = data.getExtras();
        Bitmap bitmap = (Bitmap) extras.get("data");
        LogUtils.d(bitmap);
    }
}
```

**获取并剪切图片**

```java
// 获取并剪切图片
Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
intent.setType("image/*");
intent.putExtra("crop", "true"); // 开启剪切
intent.putExtra("aspectX", 1); // 剪切的宽高比为1：2
intent.putExtra("aspectY", 2);
intent.putExtra("outputX", 20); // 保存图片的宽和高
intent.putExtra("outputY", 40);
intent.putExtra("output", Uri.fromFile(new File("/mnt/sdcard/temp"))); // 保存路径
intent.putExtra("outputFormat", "JPEG");// 返回格式
startActivityForResult(intent, 0);
```

```java
// 剪切特定图片
Intent intent = new Intent("com.android.camera.action.CROP");
intent.setClassName("com.android.camera", "com.android.camera.CropImage");
intent.setData(Uri.fromFile(new File("/mnt/sdcard/temp")));
intent.putExtra("outputX", 1); // 剪切的宽高比为1：2
intent.putExtra("outputY", 2);
intent.putExtra("aspectX", 20); // 保存图片的宽和高
intent.putExtra("aspectY", 40);
intent.putExtra("scale", true);
intent.putExtra("noFaceDetection", true);
intent.putExtra("output", Uri.parse("file:///mnt/sdcard/temp"));
startActivityForResult(intent, 0);
```

**打开手机应用市场**

```java
// 打开手机应用市场，直接进入该程序的详细页面
Uri uri = Uri.parse("market://details?id=" + packageName);
Intent intent = new Intent(Intent.ACTION_VIEW, uri);
startActivity(intent);
```

**安装程序**

```java
String fileName = Environment.getExternalStorageDirectory() + "/myApp.apk";   
Intent intent = new Intent(Intent.ACTION_VIEW);   
intent.setDataAndType(Uri.fromFile(new File(fileName)), "application/vnd.android.package-archive");   
startActivity(intent);
```

**卸载程序**

```java
Uri uri = Uri.parse("package:" + packageName);   
Intent intent = new Intent(Intent.ACTION_DELETE, uri);
startActivity(intent);
```

**进入设置界面**

```java
// 进入系统设置界面
Intent intent = new Intent(android.provider.Settings.ACTION_SETTINGS);
startActivity(intent);
```



