title: SharedPreferences
date: '2021-02-25 01:27:26'
updated: '2021-02-25 01:27:26'
tags: [android]
permalink: /articles/2021/02/25/1614187646287.html
---
# 1. 概述

SharedPreferences 是一种轻量级的数据存储方式，采用键值对的存储方式。

SharedPreferences 只能存储少量数据，大量数据不能使用该方式存储，支持存储的数据类型有 booleans, floats, ints, longs, and strings。

SharedPreferences 存储到一个 XML 文件中的，路径在 `/data/data/packagename/shared_prefs/` 下。

存储轻量级的数据，比如设置，非常常用。

# 2. 基本用法

**获取 SharedPreferences 对象**

要创建存储文件或访问已有数据，首先要获取 SharedPreferences 才能进行操作。获取 SharedPreferences 对象有下面两个方式：

* `getSharedPreferences(String name, int mode)` ：通过 Context 调用该方法获得对象。
  
  * name 指定了 SharedPreferences 存储的文件的文件名
  * mode 指定了操作的模式。
  * 这种方式获取的对象创建的文件可以被整个应用所有组件使用，有指定的文件名。
* `getPreferences(int mode)`：通过 Activity 调用获得对象。它只有一个参数 mode 指定操作模式。
  
  * 这种方式获取的对象创建的文件属于 Activity,只能在该 Activity 中使用，且没有指定的文件名，文件名同 Activity 名字。

```java
mContextSp = this.getSharedPreferences( "testContextSp", Context.MODE_PRIVATE );
// 创建的文件名是，testContextSp.xml
mActivitySp = this.getPreferences( Context.MODE_PRIVATE );
// 创建的文件名是，MainActivity.xml（该Activity叫MainActivity）
```

**mode**

两个方式都有一个 mode 参数，mode 具体有4个值，最新的只能使用默认模式 Context.MODE_PRIVATE。

* Context.MODE_PRIVATE(0)：默认模式，创建的文件只能由调用的应用程序（或者共享相同用户 ID 的应用程序）访问。
* Context.MODE_WORLD_READABLE(1)：别的应用可读
* Context.MODE_WORLD_WRITEABLE(2)：别的应用可写
* Context.MODE_MULTI_PROCESS(4)：跨进程的，不使用

**数据更新**

SharedPreferences 添加或更新数据，通过 SharedPreferences 获取 SharedPreferences.Editor 操作文件数据，最后通过 commit() 或 apply() 提交修改。

```java
SharedPreferences mContextSp = this.getSharedPreferences("testContextSp", Context.MODE_PRIVATE );
SharedPreferences.Editor editor = mContextSp.edit();
editor.putInt("age", 28);
editor.putBoolean("isStudent", false);
editor.putString("job", "it");
editor.commit();
```

操作后，在对应应用路径下有创建testContextSp.xml。具体手机里的数据如下。

```xml
<?xml version='1.0' encoding='utf-8' ?>
<map>
    <string name="job">it</string>
    <int name="age" value="28" />
    <boolean name="isStudent" value="false" />
</map>
```

commit() 和 apply() 区别：

apply() 立即更改内存中的 SharedPreferences 对象，但异步地将更新写入磁盘。

commit() 同步地将数据写入磁盘。commit() 是同步的，在主线程调用它应该多注意，因为可能引起阻塞，引起 ANR。

commit() 有返回值，返回是否成功写入永久性存储种。apply() 没有返回值。

**数据获取**

通过 SharedPreferences 提供的 getInt(), getString() 等方法获取文件中的数据，如果数据不存在，则返回一个默认值。

```java
mContextSp = this.getSharedPreferences("testContextSp", Context.MODE_PRIVATE );
String name = mContextSp.getString("name", "bbb");
int age = mContextSp.getInt("age", 0);
boolean isStudent = mContextSp.getBoolean("isStudent", false);
```



