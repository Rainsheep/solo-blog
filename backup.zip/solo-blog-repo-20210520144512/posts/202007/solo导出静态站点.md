title: solo导出静态站点
date: '2020-07-29 21:52:13'
updated: '2020-07-29 21:52:13'
tags: [solo]
permalink: /articles/2020/07/29/1596030733146.html
---
`docker cp solo:/opt/solo/static-site ~/static-site`
