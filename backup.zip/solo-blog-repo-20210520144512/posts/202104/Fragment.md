title: Fragment
date: '2021-04-07 18:50:27'
updated: '2021-04-07 18:50:27'
tags: [android]
permalink: /articles/2021/04/07/1617792627577.html
---
## 1. 碎片的简单用法

left_fragment.xml

```xml
<?xml version="1.0" encoding="utf-8"?>
<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"
    android:orientation="vertical"
    android:layout_width="match_parent"
    android:layout_height="match_parent">

    <Button
        android:id="@+id/button"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:layout_gravity="center_horizontal"
        android:text="Button" />

</LinearLayout>
```

LeftFragment.java

```java
public class LeftFragment extends Fragment {

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.left_fragment, container, false);
        return view;
    }
}
```

1. 继承 Fragment
2. 重写 onCreateView
3. 加载 fragment 布局并返回

activity_main.xml

```xml
<?xml version="1.0" encoding="utf-8"?>
<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"
    android:orientation="horizontal"
    android:layout_width="match_parent"
    android:layout_height="match_parent" >

    <fragment
        android:id="@+id/left_fragment"
        android:name="com.example.fragmenttest.LeftFragment"
        android:layout_width="match_parent"
        android:layout_height="match_parent"/>

</LinearLayout>
```

* name 为 Fragment 类的全类名

## 2. 动态添加碎片

首先按照上面方式新建一个碎片布局，然后新建碎片类 (AnotherLestFragment) 加载布局，此处不再累述。

```java
public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        replaceFragment(new AnotherLestFragment());
    }

   private void replaceFragment(Fragment fragment) {
       FragmentManager fragmentManager = getSupportFragmentManager();
       FragmentTransaction transaction = fragmentManager.beginTransaction();
       transaction.replace(R.id.left_layout, fragment);
       transaction.commit();
   }

}
```

可见，动态添加碎片主要分为5步：

1. 创建待添加碎片的实例
2. 获取 FragmentManager 的对象，在活动中可以直接调用 getSupportFragmentManager() 方法得到。
3. 开启一个事务 (FragmentTransaction对象)，通过调用 FragmentManager 中的 beginTransaction() 方法得到 FragmentTransaction 对象。
4. 向容器中添加或替换碎片，一般使用 replace() 方法实现，需要传入容器的 id 和待添加的碎片实例，容器的 id 即是碎片要添加到的活动中的某个布局 id。
5. 提交事务，调用 FragmentTransaction 的 commit() 方法来完成。

## 3. 碎片中模拟返回栈

按照上面的步骤，程序启动(页面A) -> 按键添加碎片，这时候我们点击 back，会直接退出程序，因为碎片并不在返回栈中，如果我们想模拟返回栈的效果，按 back 返回上一个碎片，可以这样操作

```java
private void replaceFragment(Fragment fragment) {
    FragmentManager fragmentManager = getSupportFragmentManager();
    FragmentTransaction transaction = fragmentManager.beginTransaction();
    transaction.replace(R.id.right_layout, fragment);
    transaction.addToBackStack(null);
    transaction.commit();
}
```

* FragmentTransaction 的 addToBackStack 方法，可以接收一个名字用于描述返回栈的状态，一般传 null

## 4. 碎片与活动直接的通信

**从布局文件获取碎片**

```java
RightFragment rightFragment = getFragmentManager().findFragmentById(R.id.right_fragment);
```

**从碎片获取 activity**

```java
MainActivity activity = getActivity();
```

**碎片与碎片之间通信**

碎片 A -> 获取活动 -> 获取碎片 B

## 5. 碎片的生命周期

### 5.1 碎片的状态

* 运行状态：当一个碎片是可见的，并且它所关联的活动正处于运行状态时，该碎片也处于运行状态。
* 暂停状态：当一个活动进入暂停状态时(由于另一个未占满屏幕的活动被添加到了栈顶)，与它相关联的可见碎片就会进入到暂停状态。
* 停止状态：当一个活动进入停止状态时，与它相关联的碎片就会进入停止状态，或者通过调用FragmentTransaction 的 remove(), replace() 方法将碎片从活动中移除，但如果在事务提交之前调用 addToBackStack() 方法，这时的碎片也会进入到停止状态。总的来说，进入停止状态的碎片对用户来说是完全不可见的，有可能会被系统回收。
* 销毁状态：碎片总是依附于活动而存在的，因此当活动被销毁时，与它相关联的碎片就会进入到销毁状态。或者通过调用 FragmentTransaction 的 remove(), replace() 方法将碎片从活动中移除，但在事务提交之前并没有调用 addToBackStack() 方法，这时的碎片也会进入到销毁状态。

### 5.2 碎片的生命周期

![35328351224dfe6bb5a27e8.webp](https://b3logfile.com/file/2021/04/3532835-1224dfe6bb5a27e8-37d2674c.webp)

相比于活动 (Activity) 的回调方法，碎片 (Fragment) 还提供了附加的回调方法：

* onAttach() : 当碎片和活动建立关联的时候调用。
* onCreateView()：为碎片创建视图(加载布局)时调用。
* onActivityCreated(): 确保与碎片相关联的活动一定已经创建完毕的时候调用。
* onDestoryView(): 当与碎片关联的视图被移除的时候调用。
* onDetach(): 当碎片和活动解除关联的时候调用。



