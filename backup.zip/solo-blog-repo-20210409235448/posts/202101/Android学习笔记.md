title: Android 学习笔记
date: '2021-01-06 18:59:23'
updated: '2021-04-08 13:42:54'
tags: [android]
permalink: /articles/2021/01/06/1609930763440.html
---
# 1. 基础

## 1.1 Android 体系结构

分为四层：

* Linux kernal，linux 内核
* libraries，c/c++ 的开源库
* application framework，应用框架层，用 java 对 libraries 进行了封装
* application，应用层

![体系结构](https://b3logfile.com/file/2021/01/untitled-dc9da4cf.png)

## 1.2 安卓虚拟机

### 1.2.1 dalvik vm

安卓使用的：dalvik vm

jvm：`.java -> .class -> .jar`，基于栈的架构，栈在内存中

dalvik vm：`.java -> .class -> .dex -> .odex`，基于寄存器的架构，寄存器在 CPU 中

java 开发工具包为 jdk

android 开发工具包为 sdk

![image.png](https://b3logfile.com/file/2021/01/image-f8ce1045.png)

### 1.2.2 ART

art(android runtime)，从安卓 5.0 开始使用的虚拟机。为了解决流畅性问题。

art 在安装应用的时候，把字节码翻译成机器码，安装之后所占用空间变大(空间换时间)。

dalvik ：一般翻译一遍执行，运行慢。

## 1.3 目录结构

链接：[android 目录结构](https://www.rainsheep.cn/articles/2021/02/23/1614078449721.html)

## 1.4 Android 打包过程

![package](https://b3logfile.com/file/2021/01/image-b1bd9221.png)

* java -> class -> dex
* xml 相关的生成 resources.arsc
* 不能编译的文件
* androidManifest.xml 清单文件

App 的安装流程

![30239720.jpg](https://b3logfile.com/file/2021/01/30239720-1b4ff4ec.jpg)

标志一个 android 项目的唯一性

* 项目的包名
* 项目的签名

## 1.5 ADB

链接：[ADB](https://www.rainsheep.cn/articles/2021/02/23/1614078558105.html)

## 1.6 点击事件的写法

链接：[android 点击事件](https://www.rainsheep.cn/articles/2021/02/23/1614078664162.html)

## 1.7 布局

链接：[android 布局](https://www.rainsheep.cn/articles/2021/02/23/1614078827110.html)

## 1.8 测试的相关概念

从代码可见的角度分为：

* 黑盒测试  自动化测试
* 白盒测试

从测试的粒度：

* 单元测试
* 集成测试
* 系统测试

从暴力程度：

* 压力测试
  
  ```
  // adb 可以进行 monkey 测试
  adb shell 下运行monkey
  monkey +次数  
  monkey -p 包名 次数  // 点具体某一个应用
  ```
* 冒烟测试

单元测试流程：

1. 写一个类继承 androidtestcase
2. 写测试的代码
3. 运行测试代码之前 需要在清单文件中声明
   
   ```xml
   // instrumentation 声明在 application 节点外
   <instrumentation android:name="android.test.InstrumentationTestRunner" android:targetPackage="com.itheima.test"></instrumentation>
   // uses-library 声明在 application 节点里面
   <uses-library android:name="android.test.runner"/>
   ```
4. 在测试的方法上单击右键 选择 run as -> android junit test

# 2. 控件

## 2.1 普通控件

链接：[android 控件](https://www.rainsheep.cn/articles/2021/02/23/1614079177741.html)

## 2.2 Adapter

链接：[Adapter](https://www.rainsheep.cn/articles/2021/03/04/1614787552864.html)

## 2.3 9-patch

链接：[9-patch](https://www.rainsheep.cn/articles/2021/04/01/1617250240560.html)

# 3. 四大组件

## 3.1 Activity

链接：[Activity](https://www.rainsheep.cn/articles/2021/03/31/1617174515693.html)

## 3.2 广播

链接：[广播](https://www.rainsheep.cn/articles/2021/04/07/1617796517017.html)

# 4. Intent

链接：[Intent](https://www.rainsheep.cn/articles/2021/02/23/1614078226696.html)

# 5. 日志

链接：[android 日志](https://www.rainsheep.cn/articles/2021/02/23/1614079025572.html)

# 6. 数据和缓存路径

## 6.1 路径

链接：[android 系统路径](https://www.rainsheep.cn/articles/2021/02/24/1614146909052.html)

## 6.2 登录案例

链接：[android 简单登录案例](https://www.rainsheep.cn/articles/2021/02/25/1614186033356.html)

## 6.3 SharedPreferences

链接：[SharedPreferences](https://www.rainsheep.cn/articles/2021/02/25/1614187646287.html)

## 6.4 xml 序列化

链接：[android xml 序列化](https://www.rainsheep.cn/articles/2021/02/25/1614188458515.html)

## 6.5 sqlite

链接：[sqlite](https://www.rainsheep.cn/articles/2021/03/03/1614706405706.html)

# 7. 多媒体

## 7.1 播放多媒体文件

链接：[MediaPlayer](https://www.rainsheep.cn/articles/2021/03/23/1616481808245.html)

# 8. 网络通信

## 8.1 Retrofit

链接：[Retrofit](https://www.rainsheep.cn/articles/2021/03/08/1615173219101.html)

# 9. Fragment

链接：[Fragment](https://www.rainsheep.cn/articles/2021/04/07/1617792627577.html)

