title: vscode 记录
date: '2019-12-04 15:01:36'
updated: '2021-06-06 16:59:10'
tags: [软件教程]
permalink: /articles/2019/12/04/1575442896111.html
---
## 语言

配置语言： `Configure Display Language`

## 快捷键

显示所有命令： `ctrl+shift+p`
格式化代码： `shift+alt+f`

## background-cover

功能描述：设置背景图

本插件通过修改 vscode 的 CSS 文件运行，会显示 code-insiders 损坏，选择不再提醒，顶部会显示不受支持。

解决办法：

运行 `ext install lehni.vscode-fix-checksums` 安装插件，运行下列第一个命令然后重启即可。

`Fix Checksums: Apply` // Checks core files for changes and applies new checksums.
`Fix Checksums: Restore` // Restores original state of VSCode checkums.

插件配置：

```json
//#插件background-cover
//图片路径
"backgroundCover.imagePath": "c:\\Users\\10766\\Pictures\\ideaBackground\\23.jpg",
//透明度
"backgroundCover.opacity": 0.6,
```

Ubuntu 系统添加背景图：

关闭背景插件

```bash
sudo find / -name workbench.desktop.main.css
/usr/share/code/resources/app/out/vs/workbench/workbench.desktop.main.css
cd /usr/share/code/resources/app/out/vs/workbench
chmod 666 workbench.desktop.main.css
vim workbench.desktop.main.css
```

添加如下代码：

```css
body {
    background-size:cover;
    background-repeat: no-repeat;
    opacity:0.9;
    background-image:url('/home/congco/Pictures/wallhaven-5dy189.jpg');
}
```

## beautify

本插件可自定义格式化 html,js,css,json 文件。
[官方文档](https://github.com/HookyQR/VSCodeBeautify/blob/master/Settings.md)

插件配置：

```json
//#beautify插件格式化代码
//设置html的默认格式化方式
"[html]": {
	"editor.defaultFormatter": "HookyQR.beautify"
},
//格式风格
"brace_style": "none,preserve-inline",
"[javascript]": {
	"editor.defaultFormatter": "HookyQR.beautify"
},
```

## Bracket Pair Colorizer

功能描述：括号彩虹化

## Comment Translate

插件特征：

1. 悬停翻译注释
2. 支持用户字符串与变量翻译，支持驼峰拆分
3. 划线翻译
4. 翻译并替换选择内容
5. 合并多行注释（两行注释合并为一行翻译）

插件配置：

```json
//#Comment translate插件
//合并多行注释
 "commentTranslate.multiLineMerge": true,
```

## Diff

功能描述：比较文件的不同

用法：ctrl+shift+p -> diff 本文件与其他文件进行对比

## Partial Diff

功能描述：可以选择两部分代码进行对比，可以在同一个文件

用法：右键选择 Select Text for Compare 选择第一部分代码，Compare Text  with Previous Selection 来进行比较

## Easy less

功能描述：保存 less 文件后，自动生成 css 文件

## IntelliSense for CSS class names in HTML

功能描述：在 html 文件中，自动提示 css class 名字

## Java prettier formatter

功能描述：对 java 文件进行格式化

## Material Icon Theme

功能描述：修改 vscode 图标

## One Dark Pro

功能描述：vscode 的一款黑暗主题

## open in browser

功能描述：在右键添加在浏览器打开此文件

## Prettier - Code formatter

功能描述：用来格式化一下文件，如 JavaScript/TypeScript/Flow/JSX/JSON/CSS/SCSS/Less/HTML/Vue/Angular/GraphQL/Markdown/YAML

配置：

```json
{
  "editor.defaultFormatter": "esbenp.prettier-vscode",
  "[javascript]": {
    "editor.defaultFormatter": "esbenp.prettier-vscode"
  }
}
```

## XML Tools

功能描述：用来格式化 xml 文件

## Vetur

功能描述：vue 必装支持插件，语法高亮、错误检测等

## Vue 3 Snippets

功能描述：可以快速生成一些 vue 的语言模板

## C/C++

功能描述：支持 C/C++ 语言

## Code Runner

插件介绍：可以在 vscode 中快捷的运行代码

插件功能：

* 支持多种语言
* 支持文件运行
* 支持文件中部分代码运行

插件配置：

```json
//#Code Runner插件
//运行配置
"code-runner.executorMap": {
    "javascript": "node",
    "python": "set PYTHONIOENCODING=utf8 && py -3",
    //"go": "go run",
    "html": "\"C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe\"",
    "java": "cd $dir && javac $fileName && java $fileNameWithoutExt",
    "cpp": "cd $dir && g++ $fileName -o $fileNameWithoutExt && $dir$fileNameWithoutExt",
},
//运行前保存当前文件
"code-runner.saveFileBeforeRun": true,
//清除前面的输出
"code-runner.clearPreviousOutput": true,
//在终端执行命令
//"code-runner.runInTerminal": true,
```

## Auto Rename Tag

插件介绍：修改标签的时候，自动修改配对的标签。

> 弃用，vscode 已经支持

插件配置：可以用 `"*"` 代表所有语言

```json
"auto-rename-tag.activationOnLanguage": ["html", "xml", "php", "javascript"]
```

## ubuntu 下 alt 不可多行编辑

参考文献：

[Ubuntu 16.04关闭Alt+鼠标左键移动窗口（转）](cnblogs.com/EasonJim/p/7732931.html)

> 系统：ubuntu 16.04

突然发现vscode,alt +左键编辑多行不可用。

原因：ubuntu 默认alt 用来移动窗口，需要改变。

1. 打开终端，菜单-编辑-配置文件首选项-命令，勾上“以登录Shell方式运行命令”，重启终端。
2. 在终端输入
   
   ```bash
   # 查看“mouse-button-modifier”当前的值，应该是返回'<Alt>'
   gsettings get org.gnome.desktop.wm.preferences mouse-button-modifier
   ```
3. ```bash
   # '<Super><Alt>'为要更改的按键，意为Win+Alt，也可以改为想要的键。测试此值不能为空或禁用，否则出现默认按下Alt键的效果。
   gsettings set org.gnome.desktop.wm.preferences mouse-button-modifier '<Super><Alt>'
   ```
4. 完事记得取消“以登录Shell方式运行命令”。

## JSON 配置文件

```json
{
  // # vscode 设置
  // 在没有从上一会话中恢复出信息的情况下，新建未命名窗口
  "workbench.startupEditor": "newUntitledFile",
  // 控制资源管理器是否在把文件删除到废纸篓时进行确认。
  "explorer.confirmDelete": false,
  // 启用后，将不会显示扩展建议的通知。
  "extensions.ignoreRecommendations": true,
  // 控制树是否应呈现缩进参考线
  "workbench.tree.renderIndentGuides": "none",

  // # 同步忽略的设置
  "settingsSync.ignoredSettings": [],

  // # 编辑器设置
  // 控制活动代码段是否阻止快速建议
  "editor.suggest.snippetsPreventQuickSuggestions": false,
  // 启用/禁用字体连字
  "editor.fontLigatures": true,
  // 控制编辑器在空白字符上显示符号的方式
  "editor.renderWhitespace": "boundary",
  // 控制无标题提示应该是编辑器或浮动按钮中的内联文本，还是应该隐藏。
  "workbench.editor.untitled.hint": "hidden",
  // 键入一行时自动格式化该行
  "editor.formatOnType": true,
  // 控制编辑器是否已启用链接编辑，同步修改标签名
  "editor.linkedEditing": true,
  // 控制在建议列表中如何预先选择建议。
  "editor.suggestSelection": "first",

  // # 编程字体设置
  // 字体样式
  "editor.fontFamily": "JetBrains Mono Variable Italic, Consolas, 'Courier New', monospace",
  // 字体大小
  "editor.fontSize": 16,

  // # 文件管理
  // 文件资源管理器根据此设置决定要显示或隐藏的文件和文件夹
  "files.exclude": {
    "**/.classpath": true,
    "**/.project": true,
    "**/.settings": true,
    "**/.factorypath": true
  },

  // # 终端设置
  // 终端采用cmd
  // "terminal.integrated.shell.windows": "C:\\WINDOWS\\System32\\cmd.exe",
  // 文件自动保存
  // "files.autoSave": "onFocusChange",

  // # 自动更新设置
  // 禁止自动更新，只可手动更新
  "update.mode": "manual",

  // # 插件background-cover
  // 图片路径
  "backgroundCover.imagePath": "/Users/rainsheep/Pictures/壁纸/43.jpg",
  // 透明度
  "backgroundCover.opacity": 0.8,

  // ====== 格式化相关 ======
  // # 插件 prettier-code formatter 格式化
  // 设置为默认格式化插件，注意所有文件格式化配置在下面
  // "editor.defaultFormatter": "esbenp.prettier-vscode",
  "[jsonc]": {
    "editor.defaultFormatter": "esbenp.prettier-vscode"
  },

  // # beautify插件格式化代码
  // 设置html的默认格式化方式
  "[html]": {
    "editor.defaultFormatter": "HookyQR.beautify"
  },
  "[javascript]": {
    "editor.defaultFormatter": "HookyQR.beautify"
  },
  "[json]": {
    "editor.defaultFormatter": "HookyQR.beautify"
  },
  "[css]": {
    "editor.defaultFormatter": "HookyQR.beautify"
  },

  // # 插件 java prettier formatter 格式化 java 文件
  "[java]": {
    "editor.defaultFormatter": "mwpb.java-prettier-formatter"
  },

  // # 插件 XML Tools 格式化
  "[xml]": {
    "editor.defaultFormatter": "DotJoshJohnson.xml"
  },

  // # C/C++ 插件格式化代码
  "[c]": {
    "editor.defaultFormatter": "ms-vscode.cpptools"
  },
  "[cpp]": {
    "editor.defaultFormatter": "ms-vscode.cpptools"
  },
  // ====== 格式化结束 ======

  // # Comment translate插件
  // 合并多行注释
  "commentTranslate.multiLineMerge": true,

  // # Code Runner插件
  // 运行配置
  "code-runner.executorMap": {
    "javascript": "node",
    "python": "set PYTHONIOENCODING=utf8 && python3",
    "html": "\"/Applications/Google Chrome.app/Contents/MacOS/Google Chrome\"",
    "java": "cd $dir && javac -encoding UTF-8 $fileName && java $fileNameWithoutExt",
    "cpp": "cd $dir && g++ $fileName -o $fileNameWithoutExt && $dir$fileNameWithoutExt"
  },
  // 运行前保存当前文件
  "code-runner.saveFileBeforeRun": true,
  // 清除前面的输出
  "code-runner.clearPreviousOutput": true,
  // 在终端执行命令
  "code-runner.runInTerminal": true,

  // # emmet
  // 启用后，按下 TAB 键，将展开 Emmet 缩写。
  "emmet.triggerExpansionOnTab": true,
  // 写 emmet 时可以提示完成
  "html-css-class-completion.enableEmmetSupport": true,
  // 若为 `true`，Emmet 建议将显示为代码片段。可以在 `editor.snippetSuggestions` 设置中排列其顺序。
  "emmet.showSuggestionsAsSnippets": true,
  // 将语法展开提示在提示列表中置顶
  "editor.snippetSuggestions": "top",
  // emmet能识别缩写语法的场景
  "emmet.includeLanguages": {
    "javascript": "javascriptreact",
    "vue-html": "html",
    "plaintext": "jade"
  },

  // # on dark pro 主题
  "workbench.colorTheme": "One Dark Pro",
  // 色彩设置为 vivid
  "oneDarkPro.vivid": true,

  // # 图标主题， material icon theme 插件
  // 指定工作台中使用的文件图标主题
  "workbench.iconTheme": "material-icon-theme",

  // # Easy LESS 插件
  "less.compile": {
    "compress": false, // 是否压缩
    "sourceMap": false, // 生成 .css.map 文件
    "out": true // 输出 .css 文件
  }
}
```

