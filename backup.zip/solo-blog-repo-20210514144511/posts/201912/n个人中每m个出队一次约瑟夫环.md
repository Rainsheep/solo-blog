title: n个人中每m个出队一次(约瑟夫环)
date: '2019-12-03 20:37:56'
updated: '2019-12-03 20:37:56'
tags: [acm, 知识点总结]
permalink: /articles/2019/12/03/1575376676127.html
---
n 个人中每数到 m 出队一人，第 k 次出队人的编号

```cpp
//约瑟夫环//  
#include<stdio.h>  
//返回的是第K次出队的人的编号//    
int ysfh(int n, int m, int k)
{
	if (k == 1)
		return (n + m - 1) % n;//此处把n+去掉好像也行...
	else
		return (ysfh(n - 1, m, k - 1) + m) % n;//上次出队人编号加上m 再对当前n取模 即为此次出队人在此队列的编号
}
//n是总人数，m是隔多少个人出队,k是第几次//  
int main()
{
	int n, m, alive;
	scanf("%d %d %d", &n, &m, &alive);//alive 剩几个人
	//循环输出//   
	for (int i = 1; i <= n - alive; i++)
		printf("第%d个出队的人的的编号:%d\n", i, ysfh(n, m, i) + 1);
}

```

```cpp
#include<iostream>
#include<vector>
using namespace std;
int main()
{
	vector<int> s;
	vector<int>::iterator it;
	int n,k,m;
	while(cin>>n>>m)//n为总人数，m为每m的出队一次 
	{
		s.clear();
		cin>>k;//第k次出队人的序号 
		for(int i=1;i<=n;i++)//1~n排序 
	    s.push_back(i);
	    it=s.begin();
	    while(1)
	   {
		   for(int i=1;i<=m-1;i++)//开头从1开始，每删一个自动指向下一个，所以m-1次 
		   {
		       it++;
		       if(it==s.end())it=s.begin();
		   	
		   }
		   if(s.size()-1<=n-k)
		   {
		       cout<<*it<<endl;
		   	   break;
		   }
		   it=s.erase(it);//删除后使it指向下一个 vector会自动指向下一个 
		   if(it==s.end())it=s.begin();//此处必须判断，如果删除得是最后一个需要移动到开头 
	    }
	 } 
}

```
