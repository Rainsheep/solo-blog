title: Python库的安装方法
date: '2019-12-04 14:12:49'
updated: '2019-12-04 14:12:49'
tags: [python]
permalink: /articles/2019/12/04/1575439969507.html
---
# 方法一：单文件模块

直接把文件拷贝到 $python_dir/Lib

# 方法二：进入 cmd 用 pip 直接安装

`pip install PackageName`

解释：安装特定版本的 package:通过使用 ==, &gt;=, &lt;=, &gt;, &lt; 来指定一个版本号
例如 ：`pip install PackageName==2.0`
升级包  `pip install -U PackageName`
卸载包：`pip uninstall PackageName`
查询包：`pip search PackageName`

# 方法三：多文件模块，带 setup.py

下载模块包（压缩文件 zip 或 tar.gz），进行解压，CMD-&gt;cd 进入模块文件夹，执行：
`python setup.py install`

解释：也可以先运行
`python setup.py build`     #仅编译不安装
再运行
`python setup.py install `   #安装，直接运行这局安装的时候会自动编译

# 方法四：whl 文件的 pip 安装方式

下载对应模块.whl 文件，在 CMD-&gt;cd 命令下进入到.whl 文件所在目录，执行

`pip install PackageName.whl`

# 方法五：.exe 文件自定义安装

打开自动安装即可

# 方法六：easy_install 方式（表示没用过）

先下载 ez_setup.py,运行 python ez_setup 进行 easy_install 工具的安装，之后就可以使用 easy_install 进行安装 package（文件名称、资源的 URL、.egg 文件（python egg 文件）来下载安装文件）

`easy_install  packageName`
`easy_install  package.egg`
