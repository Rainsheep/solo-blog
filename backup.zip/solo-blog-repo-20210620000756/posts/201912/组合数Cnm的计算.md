title: 组合数C(n,m)的计算
date: '2019-12-03 21:28:36'
updated: '2019-12-03 21:28:36'
tags: [知识点总结, 数学问题, acm]
permalink: /articles/2019/12/03/1575379716365.html
---
C(n,m)的计算方式：

1.公式：C(n,m) = n!/((n-m)! * m!)，在算法上较难实现，阶乘很快会爆 long long

2.递推：C(n,m) = C(n-1,m-1) + C(n-1,m)

在算法上当然会采用第二种方式计算，而且因为 C(n,m)本身值很大，所以大多数碰见它的情况会取模

```cpp
#include<iostream>
#define MOD 1000000007
using namespace std;
 
const int N = 10005;
long long c[N][N];
long long C(int i, int j) {
	if (i == j) return c[i][j] = 1;
	if (j == 0) return c[i][j] = 1;
	if (j == 1) return c[i][j] = i;
	if (c[i][j]) return c[i][j];
	return c[i][j] = (C(i - 1, j - 1) % MOD + C(i - 1, j) % MOD) % MOD;//不需取模时把MOD去掉
}
 
int main()
{
	int m, n;
	cin >> n >> m;
	cout << C(n, m) << endl;//n>=m
}
```
