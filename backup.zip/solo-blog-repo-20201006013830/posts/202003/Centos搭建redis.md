title: Centos 搭建 redis
date: '2020-03-02 20:03:17'
updated: '2020-03-02 20:03:17'
tags: [Linux, 软件教程]
permalink: /articles/2020/03/02/1583150597818.html
---
1. 下载 Redis
2. 解压到目录下
3. 进入 Redis 目录
4. 执行编译命令 `make`
5. 编译完成之后，将 Redis 安装到指定目录 `make PREFIX=./redis install`
6. 安装完之后，生成 bin 文件夹
7. 至此安装完成
8. 修改配置文件，注释掉 bind 127.0.0.1
9. `protected-mod yes` 改为 `protected-mod no`
10. `mv redis.conf ./redis/bin` 复制配置文件到 bin 目录下
11. .`/redis-server ./redis.conf` 使用 Screen 启动 Redis
