title: hdu-2151 Worm
date: '2019-12-03 19:53:47'
updated: '2019-12-03 19:53:47'
tags: [DP, acm]
permalink: /articles/2019/12/03/1575374027915.html
---
题目链接：[hdu-2151](http://acm.hdu.edu.cn/showproblem.php?pid=2151)

思路：dp[i][j]表示 i 分钟时到达 j 树的方案数，此方案数等于上一层相邻的两个的方案数综合，dp 公式 dp[i][j] = dp[i - 1][j - 1] + dp[i - 1][j + 1];

```c++
#include<iostream>
using namespace std;
int main()
{
	int dp[105][105], i, j, k, l, m, n,p,t;//dp[i][j]表示i分钟时到达j树的方案数 
	while (cin >> n >> p >> m >> t)
	{
		for (i = 0; i <= m; i++)
			for (j = 0; j <= n+1; j++)
			{
				dp[i][j] = 0;//在最左边和最右边都多加一列，初始化为0，好利用公式，不需要在判断 
			}
		dp[0][p] = 1;//初始点的方案数初始化为1 
		for(i=1;i<=m;i++)
			for (j = 1; j <= n; j++)
			{
				dp[i][j] = dp[i - 1][j - 1] + dp[i - 1][j + 1];//到达此点的方案数等于上层相邻两点方案数的总和 
			}
		cout << dp[m][t] << endl;
	}
	return 0;
}

```
