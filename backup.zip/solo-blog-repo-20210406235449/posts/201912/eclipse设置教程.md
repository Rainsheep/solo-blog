title: eclipse设置教程
date: '2019-12-26 20:09:08'
updated: '2019-12-27 09:26:55'
tags: [软件教程]
permalink: /articles/2019/12/26/1577362148359.html
---
## 完全卸载

1. 完全删除安装目录
2. 完全删除工作目录
3. 删除 C:\Users\用户名\\.p2
4. 删除 C:\Users\用户名\\.eclipse

## eclipse 安装

eclipse 安装参考：[win10下JAVA环境的安装及eclipse安装与汉化](https://www.rainsheep.top/articles/2019/12/03/1575384194057.html)

## 关闭 welcome 欢迎界面

打开 eclipse，会看到欢迎界面，在界面右下方可以看到“Always show Welcome at start up”，去掉前面方框里面的勾。

![p20191226071003.png](https://img.hacpai.com/file/2019/12/p20191226071003-6b1f80d4.png)

当然，如果某一天你想要欢迎页面，你只需要点击 Help——Welcome,在出现的欢迎页右下方把“Always show Welcome at start up”重新勾选上就可以了。

## 设置字体及大小

Window→ Preferences→ General→ Appearance→ Colors and Fonts
![p20191226064733.png](https://img.hacpai.com/file/2019/12/p20191226064733-e02087b4.png)

右边 Basic→双击 Text Font→选择字体以及大小

![p20191226064858.png](https://img.hacpai.com/file/2019/12/p20191226064858-28ed035a.png)

## 配置 Tomcat

Window→ Preferences→ Server→ Runtime Environments→ Add
选择对应的版本
![p20191226070330.png](https://img.hacpai.com/file/2019/12/p20191226070330-54747de0.png)

选择位置
![p20191226070403.png](https://img.hacpai.com/file/2019/12/p20191226070403-6874fd7f.png)

点击 Finish

## 配置编码

* 设置工作空间编码格式
  在 Window→ Preferences→ General→ Workspace 下，面板 Text file encoding 选择 UTF-8 格式，如下图：
  ![2018022509225099.png](https://img.hacpai.com/file/2019/12/2018022509225099-7d196619.png)
* 设置 JSP 页面编码格式
  在 Window→ Preferences→ Web→ JSP Files 面板选择 ISO 10646/Unicode(UTF-8)格式编码，如下图：
  ![20180225092359780.png](https://img.hacpai.com/file/2019/12/20180225092359780-d860d841.png)
* 设置文档编码格式
  在 Window→ Preferences→ General → Content Type→ Text 的最下面设置为编码格式为 UTF-8，如下图：
  ![20180225092445639.png](https://img.hacpai.com/file/2019/12/20180225092445639-61a478fb.png)
  依次点开并选择 Text 下面的 Java Source File、XML、Java Properties File 等，在下面的 Default encoding 输入框中输入 UTF-8，并点 Update 生效

> properties 已经缺省指定为 ISO8859-1，所以这个必改。不然等写好了国际化配置，就乱码了…

* 设置项目的文档编码格式
  选择项目 →右键 → Properties → Resource 设置编码为 UTF-8 格式，如下图：
  ![20180225092505708.png](https://img.hacpai.com/file/2019/12/20180225092505708-86b4bae9.png)![20180225092518478.png](https://img.hacpai.com/file/2019/12/20180225092518478-757d2dca.png)

> 选择 Other 选择编码即可，如果选项里面没有则可以手动输入，比如输入 GBK

## 自动提示配置及优化自动提示

### 自动提示设置

* 代码自动提示
  打开 eclipse 依次点击 Window→ Perferences → Java → Editor → Content Assist
  我们需要在&quot;.&quot;之后加上&quot;abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789&quot;,即可实现自动提示。
  将 Auto activation delay(ms)为 100 节约电脑性能。
  ![p20191227090523.png](https://img.hacpai.com/file/2019/12/p20191227090523-cd42ee96.png)
* XML 自动补全
  Windows→ preferance→ XML→ XML Files→ Editor→ Content Assist
  面板最上端 Auto Activation 将 Prompt when these characters are inserted 后面的文本框中的“&lt;=:”替换成
  “&lt;=:abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789 ”（注意后面还有一个空格）
  Auto activation delay(ms)改为 100
* JS 等别的文件的自动提示方式与上类似，不再累述

### 优化自动提示

问题：输入变量名的时候，总是自动补全
解决办法：
window→ preference→ Java→ editor→ content assist，勾选上图选项，即只有按 enter 键时才触发自动补全功能。
![p20191227090810.png](https://img.hacpai.com/file/2019/12/p20191227090810-de03a9e9.png)

> 注：2019 新版本才可以，我的是 2019.06 版本

## Indent Guide 插件

缩进线（Indent Guide）插件

1. 下载 Indent Guide 缩进线插件：网址为[https://github.com/kiritsuku/IndentGuide](https://github.com/kiritsuku/IndentGuide)，下载完成后解压文件包。
2. 将解压得到的文件夹下的 pdt_tools.indentGuide.updateSite 文件夹复制到 Eclipse 安装目录下 dropins 文件夹中。
3. 重启 Eclipse，依次点击 Windows→ Preferences→ General→ Editors→ Text Editors→ Indent Guide（若安装不成功，不显示 Indent Guide），按照下图的步骤依次进行设置
   ![p20191227091700.png](https://img.hacpai.com/file/2019/12/p20191227091700-47d99635.png)

## 错误修复

Code Recommenders cannot download its model repository index 错误，参考[eclipse弹窗Code Recommenders cannot download its model repository index](https://www.rainsheep.top/articles/2019/12/26/1577347094403.html)

## ctrl+ 滚轮放大缩小代码

没找到方法，可能 eclipse 不能这样玩，找到了快捷键

* `ctrl+=`放大
* `ctrl+-`缩小

## 快捷键

Alt+/ 自动补全
Ctrl+1 快速修复
Ctrl+Shift+F 格式化代码
