title: CloudCone更换IP教程
date: '2020-01-24 23:40:12'
updated: '2020-01-24 23:40:12'
tags: [ss, Shadowsocks]
permalink: /articles/2020/01/24/1579880412473.html
---
参考链接：
https://cloudcone.cc/ban-ip-update.html
教程：
登录→Support→Support Tickets→Create new tickets→输入`Please deduct my $2 balance to help me replace an IP address that I can use in China. Thank you`→选择主机→提交→![](https://raw.githubusercontent.com/Rainsheep/pic-bed/master/img/2020-01-24+23:38:31+p_20200124113828.png)


或者点击[联系客服](https://app.cloudcone.com.cn/support/list)直接创建
