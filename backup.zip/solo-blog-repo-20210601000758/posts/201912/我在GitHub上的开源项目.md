title: 我在 GitHub 上的开源项目
date: '2019-12-05 03:00:31'
updated: '2019-12-05 03:00:31'
tags: [开源, GitHub]
permalink: /my-github-repos
---
<!-- 该页面会被定时任务自动覆盖，所以请勿手工更新 -->
<!-- 如果你有更漂亮的排版方式，请发 issue 告诉我们 -->

### 1. [solo-blog](https://github.com/Rainsheep/solo-blog) <kbd title="主要编程语言"></kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/Rainsheep/solo-blog/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/Rainsheep/solo-blog/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/Rainsheep/solo-blog/network/members "分叉数")&nbsp;&nbsp;[🏠`https://www.rainsheep.cn`](https://www.rainsheep.cn "项目主页")</span>

✍️ 雨羊的个人博客 - 咸鱼不配拥有梦想



---

### 2. [authority-management](https://github.com/Rainsheep/authority-management) <kbd title="主要编程语言">JavaScript</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/Rainsheep/authority-management/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/Rainsheep/authority-management/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/Rainsheep/authority-management/network/members "分叉数")</span>

权限管理系统



---

### 3. [vue-mall](https://github.com/Rainsheep/vue-mall) <kbd title="主要编程语言">Vue</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/Rainsheep/vue-mall/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/Rainsheep/vue-mall/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/Rainsheep/vue-mall/network/members "分叉数")</span>





---

### 4. [community](https://github.com/Rainsheep/community) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/Rainsheep/community/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/Rainsheep/community/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/Rainsheep/community/network/members "分叉数")</span>

毕设项目，社团活动管理系统



---

### 5. [pic-bed](https://github.com/Rainsheep/pic-bed) <kbd title="主要编程语言"></kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/Rainsheep/pic-bed/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/Rainsheep/pic-bed/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/Rainsheep/pic-bed/network/members "分叉数")</span>

雨羊的github图床



---

### 6. [Rainsheep.github.io](https://github.com/Rainsheep/Rainsheep.github.io) <kbd title="主要编程语言">HTML</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/Rainsheep/Rainsheep.github.io/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/Rainsheep/Rainsheep.github.io/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/Rainsheep/Rainsheep.github.io/network/members "分叉数")&nbsp;&nbsp;[🏠`https://rainsheep.github.io/`](https://rainsheep.github.io/ "项目主页")</span>

博客的静态站点



---

### 7. [heima-travel](https://github.com/Rainsheep/heima-travel) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/Rainsheep/heima-travel/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/Rainsheep/heima-travel/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/Rainsheep/heima-travel/network/members "分叉数")</span>

黑马旅游网

