title: android 权限
date: '2021-04-08 15:01:54'
updated: '2021-04-08 15:01:54'
tags: [android]
permalink: /articles/2021/04/08/1617865314380.html
---
## 1. 普通权限

不会直接威胁到用户的安全和隐私的权限，对于这部分权限申请，系统会自动帮我们进行授权，而不需要用户再去手动操作了。

## 2. 危险权限

可能会触及用户隐私，或者对设备安全性造成影响的权限，如获取设备联系人信息、定位设备的地理位置等，对于这部分权限申请，必须要由用户手动点击授权才可以，否则程序就无法使用相应的功能。

## 3. 运行时权限申请

```java
public class MainActivity extends AppCompatActivity {
 
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
 
        Button makeCall = (Button) findViewById(R.id.make_call);
        makeCall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //检查是否授权
                if (ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED){
                    //没有授权时，申请授权
                    //requestPermissions接收三个参数，第二个是储存权限名的String数组。第三个是请求码，必须为唯一值。
                    ActivityCompat.requestPermissions(MainActivity.this, new String[]{ Manifest.permission.CALL_PHONE }, 1);
                }else {
                    //有授权时，直接打电话
                    call();
                }
            }
        });
    }
 
    private void call(){
        try {
            Intent intent = new Intent(Intent.ACTION_CALL);
            intent.setData(Uri.parse("tel:10086"));
            startActivity(intent);
        } catch (SecurityException e){
            e.printStackTrace();
        }
    }
 
    //申请授权的结果会回调到onRequestPermissionsResult()方法中，封装在grantResults参数中
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode){
            case 1:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED){
                    call();
                }else {
                    Toast.makeText(this, "未获取权限", Toast.LENGTH_SHORT).show();
                }
                break;
            default:
        }
    }
}
```

* 检查是否有权限：`ContextCompat.checkSelfPermission()`
  * 第一个参数 Context
  * 第二个参数具体的权限名
* 请求权限：`ActivityCompat.requestPermissions()`
  * 第一个参数 Activity 实例
  * 第二个参数 String 权限数据
  * 第三个请求码，唯一
* 回调 `onRequestPermissionsResult()` 方法，grantResults 为授权结果

