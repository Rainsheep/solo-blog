title: Android 学习笔记
date: '2021-01-06 18:59:23'
updated: '2021-02-05 00:44:27'
tags: [android]
permalink: /articles/2021/01/06/1609930763440.html
---
# 1. 基础

## 1.1 Android 体系结构

分为四层：

* Linux kernal，linux 内核
* libraries，c/c++ 的开源库
* application framework，应用框架层，用 java 对 libraries 进行了封装
* application，应用层

![体系结构](https://b3logfile.com/file/2021/01/untitled-dc9da4cf.png)

## 1.2 安卓虚拟机

### 1.2.1 dalvik vm

安卓使用的：dalvik vm

jvm：`.java -> .class -> .jar`，基于栈的架构，栈在内存中

dalvik vm：`.java -> .class -> .dex -> .odex`，基于寄存器的架构，寄存器在 CPU 中

java 开发工具包为 jdk

android 开发工具包为 sdk

![image.png](https://b3logfile.com/file/2021/01/image-f8ce1045.png)

### 1.2.2 ART

art(android runtime)，从安卓 5.0 开始使用的虚拟机。为了解决流畅性问题。

art 在安装应用的时候，把字节码翻译成机器码，安装之后所占用空间变大(空间换时间)。

dalvik ：一般翻译一遍执行，运行慢。

## 1.3 目录结构

参考：[Android项目目录结构模板以及简单说明【简单版】](https://www.cnblogs.com/whycxb/p/9739148.html)

![1.png](https://b3logfile.com/file/2021/01/1-bad9286a.png)
![2.png](https://b3logfile.com/file/2021/01/2-b899bff0.png)
![3.png](https://b3logfile.com/file/2021/01/3-96ae7647.png)
![4.png](https://b3logfile.com/file/2021/01/4-3cd6acbd.png)
![5.png](https://b3logfile.com/file/2021/01/5-662c2816.png)

`app/src/main/assets` ：静态资源，里面的代码不会被编译，而且不会在 R.java 文件下生成资源 id，需要使用 AssetsManager 类进行访问。

`app/src/main/java/包名/activity`：BaseActivity 和与项目业务无关的 activity（比如WelcomeActivity）放到包的根目录下，其他与项目业务相关的 activity 放到新建的以业务名称命名的子包目录下，如果项目比较简单，那么就统一放到 normal 包下即可。

`app/src/main/java/包名/adapter`：适配器类集合

`app/src/main/java/包名/bean`：实体类集合

`app/src/main/java/包名/dialog`：BaseDialogFragment 放到包的根目录下，其他与项目业务相关的 dialog 放到新建的以业务名称命名的子包目录下，如果项目比较简单，那么就统一放到 normal 目录下即可。

`app/src/main/java/包名/enumtype`：枚举类集合

`app/src/main/java/包名/fragment`：BaseFragment 放到包的根目录下，其他与项目业务相关的 fragment 放到新建的以业务名称命名的子包目录下，如果项目比较简单，那么就统一放到 normal 目录下即可。

`app/src/main/java/包名/listener`：监听器类集合

`app/src/main/java/包名/mvp`：mvp 模式的根目录

`app/src/main/java/包名/mvp/iview`：mvp 模式中的 V

`app/src/main/java/包名/mvp/model`：mvp 模式中的 M

`app/src/main/java/包名/presenter`：mvp 模式中的 P

`app/src/main/java/包名/utils`：常用工具类集合（注意，区别 base 中的 utils 目录，这里是仅在 app 中用到的工具类，不是通用工具类集合，通用工具类集合在 `base/utils` 目录中）

`app/src/main/java/包名/views`：自定义 view 集合（注意，区别 base 中的 views 目录，这里是仅在 app 中用到的自定义 view，不是通用自定义 view 集合，通用自定义 view 集合在 base/views 目录中）

`app/src/main/java/包名/MyApplication.java`：项目声明的自定义 Application 类（注意：项目中所有需要在自定义 Application 中声明的方法，比如引入第三方平台时一些配置，都需要写在这里，而不是 base 中的 BaseApplication 或者 thirdlib 中的 ThirdApplication 中）

`app/src/main/res`：存放资源的，需要注意，drawable-hdpi、mdpi、xhdpi、xxhdpi、xxxhdpi 目录需要自己创建，新建项目后没有的目录或者文件。

`app/src/main/res/drawable`：图片

`app/src/main/res/layout`：布局文件

`app/src/main/res/values`：包含使用 XML 格式的参数的描述文件，如 string.xml 字符串，color.xml 颜色，style.xml 风格样式等

`app/src/main/res/values/dimens.xml`：尺寸声明

`app/src/main/res/values/string.xml`：项目中用到的字符串

`app/src/main/res/values/styles.xml`：项目用到的主题和样式

`app/src/main/res/AndroidManifest.xml`：系统的控制文件，用于告诉 Android 系统 App 所包含的一些基本信息，比如组件，资源，以及需要的权限，以及兼容的最低版本的 SDK 等

`app/src/build.gradle`：gradle 构建脚本

`app/src/proguad-rules.pro`：代码混淆配置。注意：项目中所有的代码混淆配置都写在这里，不要分开在 base 或者 thirdlib 中写。

`base`：其他module都可以引用base这个module

`base/src/main/java/包名/dialog`：通用对话框集合（比如确认取消对话框等）

`base/src/main/java/包名/utils`：通用工具类集合

`base/src/main/java/包名/views`：通用自定义 view 集合

`base/src/main/java/包名/dialog`：Application 基类，主要用于不同 module 中应用 ApplicationContext 对象。

`thirdlib`：第三方平台sdk集合

`thirdlib/libs`：第三方平台 sdk 中 jar、arr 文件集合

`thirdlib/src/main/java/包名/ThirdApplication.java`：没有什么用，主要是为了以后新建子包方便。

**R.java 介绍**

此类在新版本中已经取消，找不到其位置，不过很重要。

res 目录下保存的文件大多数都会被编译，并且都会被赋予资源ID，这些资源ID被保存在 R.java 文件中。这样我们就可以在程序中通过 ID 来访问 res 类的资源。

R 类默认有 attr、drawable、layout、string 等四个静态内部类，每个静态内部类分别对应着一种资源，如layout静态内部类对应layout中的界面文件，其中每个静态内部类中的静态常量分别定义一条资源标识符，如 `public static final int main=0x7f030000;` 对应的是 layout 目录下的 `main.xml` 文件。

即当开发者在 res 目录中任何一个子目录中添加相应类型的文件之后，ADT 会在 R.java 文件中相应的内部类中 自动生成一条静态int类型的常量，对添加的文件进行索引。如果在 layout 目录下再添加一个新的界面，那么在 `public static final class layout` 中也会添加相应的静态 int 常量。相反当我们在 res 目录下删除任何一个文件，其在 R.java 中对应的记录会被 ADT 自动删除。

R.java 文件按除了有自动标示资源的索引功能之外，还有另外一个主要的功能，如果 res 目录中的某个资源在应用中没有被使用到，在该应用被编译的时候系统就不会把对应的资源编译到该应用的 APK 包中，这样可以节省 Android 手机的资源。

在 java 程序中引用R类资源：`R.resource_type.resource_name`

在 XML 文件中引用 R 资源 ID：`@[package:]type/name`

在 XML 文件中向 R 类添加资源 ID：`@+id/string_name`

## 1.4 Android 打包过程

![package](https://b3logfile.com/file/2021/01/image-b1bd9221.png)

App 的安装流程

![30239720.jpg](https://b3logfile.com/file/2021/01/30239720-1b4ff4ec.jpg)

标志一个 android 项目的唯一性

* 项目的包名
* 项目的签名

## 1.5 ADB

android debug bridge 安卓调试桥

`adb start-server`：开启 adb 服务

`adb kill-server`：杀死 adb 服务

`adb:reset adb`：重启 adb

`adb uninstall [-k] + 包名`：卸载应用，-k 只删除程序，不删除所用数据与缓存目录

`adb uninstall --user 0 + 包名` ：root 权限卸载软件

`adb install [-r] [-s] [-d] + apk 所在路径`：安装应用，-r 重新安装，-s 安装到 sd 卡,，-d 允许降级覆盖安装

`adb push 本地地址 sdcard/`：上传到手机

`adb pull 地址`：从手机拉下来

`adb shell`：进入设备的命令行

`adb devices`：列出所有链接的设备

**问题 1**

问题：安装 apk 出现 Failure [INSTALL_FAILED_TEST_ONLY: installPackageLI] 错误

Android Studio 3.0 会在 debug apk 的 manifest 文件 application 标签里自动添加 `android:testOnly="true"` 属性，导致 IDE 中 run 跑出的 apk 在大部分手机上只能用 `adb install -t <apk>` 来安装

解决：在 gradle.properties (项目根目录或者 gradle 全局配置目录) 文件中添加 `android.injected.testOnly=false`

## 1.6 点击事件的写法

**案例：电话拨号器**

activity_main.xml

```xml
<RelativeLayout xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:tools="http://schemas.android.com/tools"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    tools:context=".MainActivity">

    <TextView
        android:id="@+id/textView1"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:text="请输入电话号码" />

    <EditText
        android:id="@+id/editText1"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:layout_below="@+id/textView1"
        android:layout_alignParentStart="true"
        android:ems="10"
        android:hint="在这里输入电话"
        android:importantForAutofill="no"
        android:inputType="phone">

        <requestFocus />
    </EditText>

    <Button
        android:id="@+id/button1"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:layout_below="@+id/editText1"
        android:layout_alignParentStart="true"
        android:text="拨打此号码" />

</RelativeLayout>
```

MainActivity.java

第一种写法：内部类实现 OnClickListener 接口

```java
public class MainActivity extends Activity {

    private EditText et_number;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        et_number = findViewById(R.id.editText1);
        Button btn_call = findViewById(R.id.button1);
        btn_call.setOnClickListener(new MyOnclickListener());

    }

    private class MyOnclickListener implements OnClickListener {

        @Override
        public void onClick(View v) {
            String number = MainActivity.this.et_number.getText().toString();
            if (TextUtils.isEmpty(number)) {
                Toast.makeText(MainActivity.this, "电话号码不能为空", Toast.LENGTH_SHORT).show();
                System.out.println("用户输入是空的");
            } else {
                System.out.println("打电话:" + number);
                Intent intent = new Intent();
                intent.setAction("android.intent.action.CALL");
                Uri data = Uri.parse("tel:" + number);
                intent.setData(data);
                startActivity(intent);
            }
        }
    }
}
```

第二种写法：匿名内部类

此方法弊端：需要为每个控件设置匿名内部类，匿名内部类无法共用

```java
public class MainActivity extends Activity {

    private EditText et_number;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        et_number = findViewById(R.id.editText1);
        Button btn_call = findViewById(R.id.button1);
        btn_call.setOnClickListener(v -> {
            String number = et_number.getText().toString().trim();
            if (TextUtils.isEmpty(number)) {
                Toast.makeText(MainActivity.this, "电话号码不能为空", Toast.LENGTH_SHORT).show();
            } else {
                Intent intent = new Intent();
                intent.setAction(Intent.ACTION_CALL);
                intent.setData(Uri.parse("tel:" + number));
                startActivity(intent);
            }
        });
    }
}
```

第三种写法：父类实现 OnClickListener 接口，根据 id 区别被点击的 View，常用

```java
public class MainActivity extends Activity implements OnClickListener {

    private EditText et_number;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        et_number = findViewById(R.id.editText1);
        Button btn_call = findViewById(R.id.button1);
        Button btn2 = findViewById(R.id.button2);
        Button btn3 = findViewById(R.id.button3);
        btn_call.setOnClickListener(this);
        btn2.setOnClickListener(this);
        btn3.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        int id = v.getId();
        switch (id) {
            case R.id.button1:
                String number = et_number.getText().toString().trim();
                if (TextUtils.isEmpty(number)) {
                    Toast.makeText(this, "电话号码不能为空", Toast.LENGTH_SHORT).show();
                } else {
                    Intent intent = new Intent();
                    intent.setAction(Intent.ACTION_CALL);
                    intent.setData(Uri.parse("tel:" + number));
                    startActivity(intent);
                }
                break;
            case R.id.button2:
                Toast.makeText(this, "电话号码不能为空2", Toast.LENGTH_SHORT).show();
                break;
            case R.id.button3:
                Toast.makeText(this, "电话号码不能为空3", Toast.LENGTH_SHORT).show();
                break;
        }
    }
}
```

第四种写法：onClick 属性，基本不用

```xml
<Button
    android:id="@+id/button1"
    android:layout_width="wrap_content"
    android:layout_height="wrap_content"
    android:layout_below="@+id/editText1"
    android:layout_alignParentStart="true"
    android:onClick="btnClick"
    android:text="拨打此号码" />
```

```java
public class MainActivity extends Activity {

    private EditText et_number;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        et_number = findViewById(R.id.editText1);
    }

    public void btnClick(View v) {
        String number = et_number.getText().toString().trim();
        if (TextUtils.isEmpty(number)) {
            Toast.makeText(this, "电话号码不能为空", Toast.LENGTH_SHORT).show();
        } else {
            Intent intent = new Intent();
            intent.setAction(Intent.ACTION_CALL);
            intent.setData(Uri.parse("tel:" + number));
            startActivity(intent);
        }
    }
}
```

## 1.7 布局

### 1.7.1 线性布局

LinearLayout

```
// 布局方向
orientation="vertical/horizontal"
// 子元素的对齐方式
gravity="left|buttom"
// 控制该组件在父容器的对齐方式
layout_gravity

// 权重，将剩余部分等比划分
weight

// 分割线图片
divider
// 设置分割线位置，none/middle/begining/end
showDividers
// 分割线 padding
dividerPadding
```

> 当 android:orientation="vertical" 时， 只有水平方向的设置才起作用，垂直方向的设置不起作用。 即：left，right，center_horizontal 是生效的。 当 android:orientation="horizontal" 时， 只有垂直方向的设置才起作用，水平方向的设置不起作用。 即：top，bottom，center_vertical 是生效的。

**weight 权重**

将剩余空间按权重划分。

当 width 为 0dp 或者 wrap_content 的时候没有问题。

当子控件 width 为 match_parent 会出现问题

```
// 控件1
android:layout_weight="1"    
android:layout_width="fill_parent" 
// 控件2
android:layout_weight="2
android:layout_width="fill_parent" 
// 控件3
android:layout_weight="3
android:layout_width="fill_parent"
```

发现比例为 2:1:0 ，

step 1：个个都是fill_parent,但是屏幕只有一个啦,那么1 - 3 = - 2 fill_parent

step 2：依次比例是1/6,2/6,3/6

step 3：剩余空间为 -2 fill_parent，先到先得,先分给one,计算: 1 + (- 2 \* (1/6)) = 2/3 fill_parent ，接着到two,计算: 1 + ( - 2 \* (2/6)) = 1/3 fill_parent， 最后到three,计算 1 + ( - 2 \* (3/6)) = 0 fill_parent

### 1.7.2 相对布局

RelativeLayout

可以相对于某一控件或者父容器对齐

所有控件从左上角开始

基本属性

```
// 设置容器内组件的对齐方式
gravity
设置了该属性为true的属性的组件,将不受 gravity 属性的影响
ignoreGravity
```

根据父容器定位

```
// 左对齐
layout_alignParentLeft
// 右对齐
layout_alignParentRight
// 顶部对齐
layout_alignParentTop
// 底部对齐
layout_alignParentBottom
// 水平居中
layout_centerHorizontal
// 垂直居中
layout_centerVertical
// 中间位置
layout_centerInParent
```

根据兄弟组件定位

```
// 参考组件的左边
layout_toleftOf
// 参考组件的右边
layout_toRightOf
// 参考组件的上方
layout_above
// 参考组件的下方
layout_below
// 对齐参考组件的上边界
layout_alignTop
// 对齐参考组件的下边界
layout_alignBottom
// 对齐参考组件的左边界
layout_alignLeft
// 对齐参考组件的右边界
layout_alignRight
```

margin 偏移

```
// 设置组件上下左右的偏移量
layout_margin
// 设置组件离左边的偏移量
layout_marginLeft
// 设置组件离右边的偏移量
layout_marginRight
// 设置组件离上面的偏移量
layout_marginTop
// 设置组件离下面的偏移量
layout_marginBottom
```

padding 填充，padding 会影响组件自身大小

```
// 往内部元素的上下左右填充一定边距
padding
// 往内部元素的左边填充一定边距
paddingLeft
// 往内部元素的右边填充一定边距
paddingRight
// 往内部元素的上方填充一定边距
paddingTop
// 往内部元素的下方填充一定边距
paddingBottom
```

### 1.7.3 帧布局

FrameLayout

只能放在(top,center,bottom)*(left,center,right) 9 个位置

```
// 前景图像:永远处于帧布局最上面,直接面对用户的图像,就是不会被覆盖的图片。
// 设置改帧布局容器的前景图像
foreground
// 设置前景图像显示的位置
foregroundGravity
```

```
// 指定控件的对齐方式
android:layout_gravity="bottom"
android:layout_gravity="center_vertical"
// 垂直居中并靠右
android:layout_gravity="center_vertical|right"
```

### 1.7.4 表格布局

TableLayout 不常用，类似于竖直方向的线性布局

`<TableRow>` ：声明控件在一行

确定行数和列数

- 如果我们直接往 TableLayout 中添加组件的话,那么这个组件将占满一行！！！
- 如果我们想一行上有多个组件的话,就要添加一个 TableRow 的容器,把组件都丢到里面！
- tablerow 中的组件个数就决定了该行有多少列,而列的宽度由该列中最宽的单元格决定
- tablerow 的 layout_width 属性,默认是 fill_parent 的,我们自己设置成其他的值也不会生效！！！ 但是 layout_height 默认是 wrapten-content的,我们却可以自己设置大小！
- 整个表格布局的宽度取决于父容器的宽度(占满父容器本身)
- 有多少行就要自己数啦,一个 tablerow 一行,一个单独的组件也一行！多少列则是看 tableRow 中的组件个数,组件最多的就是 TableLayout 的列数

常用属性

```
// 设置需要被隐藏的列的序号
collapseColumns
// 设置允许被收缩的列的列序号，为了保证表格能适应父容器的宽度
shrinkColumns
// 设置运行被拉伸的列的列序号,填满剩余空间
stretchColumns

以上这三个属性的列号都是从 0 开始算的,比如 shrinkColunmns = "2",对应的是第三列！
可以设置多个,用逗号隔开比如"0,2",如果是所有列都生效,则用"*"号即可
除了这三个常用属性,还有两个属性,分别就是跳格子以及合并单元格,这和HTML中的Table类似:

// 表示的就是跳过第二个,直接显示到第三个格子处,从1开始算的!
layout_column="2"
// 表示合并4个单元格,也就说这个组件占4个单元格
android:layout_span="4"
```

### 1.7.5 网格布局

GridLayout

使用虚细线将布局划分为行、列和单元格，也支持一个控件在行、列上都有交错排列。

```
// 排列方式
orientation="vertical/horizontal"
// 对齐方式
gravity="center/left/right/bottom"

// 布局的行列数
rowCount="4"
columnCount="4"

// 组件起始行列
layout_row="1"
layout_column="2"

// 组件跨越行列数
layout_rowSpan="2"
layout_columnSpan="3"
```

> 设置了组件横跨多行或者多列的话,如果你要让组件填满横越过的行或列的话,需要添加下面这个属性: layout_gravity = "fill"

**绝对布局**

AbsoluteLayout 已过时

```
// 设置组件的X坐标
layout_x
// 设置组件的Y坐标
layout_y
```

### 1.7.6 约束布局

参考：[约束布局ConstraintLayout看这一篇就够了](https://www.jianshu.com/p/17ec9bd6ca8a)

缺点：约束太强，不利于维护，牵一发而动全身

位置约束

```
// 左边约束在所选控件的左边
layout_constraintLeft_toLeftOf
// 左边约束在所选控件的右边
layout_constraintLeft_toRightOf
layout_constraintRight_toLeftOf
layout_constraintRight_toRightOf
layout_constraintTop_toTopOf
layout_constraintTop_toBottomOf
layout_constraintBottom_toTopOf
layout_constraintBottom_toBottomOf
layout_constraintBaseline_toBaselineOf
layout_constraintStart_toEndOf
layout_constraintStart_toStartOf
layout_constraintEnd_toStartOf
layout_constraintEnd_toEndOf
```

角度约束

```
layout_constraintCircle="@+id/TextView1"
layout_constraintCircleAngle="120"（角度）
layout_constraintCircleRadius="150dp"（距离）
```

margin 约束

```
layout_marginStart
layout_marginEnd
layout_marginLeft
layout_marginTop
layout_marginRight
layout_marginBottom
```

> 约束布局中必须约束一个相对位置 margin 才生效

goneMargin

```
// goneMargin 主要用于约束的控件可见性,约束控件被设置为 gone 的时候使用的 margin 生效
layout_goneMarginStart
layout_goneMarginEnd
layout_goneMarginLeft
layout_goneMarginTop
layout_goneMarginRight
layout_goneMarginBottom
```

居中

```
layout_constraintBottom_toBottomOf="parent"
layout_constraintLeft_toLeftOf="parent"
layout_constraintRight_toRightOf="parent"
layout_constraintTop_toTopOf="parent"
```

偏移

```
// 水平偏移
layout_constraintHorizontal_bias="0.5"  // 0 最左侧，1 最右侧
// 垂直偏移
layout_constraintVertical_bias
```

尺寸约束

```
minWidth  // 最小的宽度
minHeight // 最小的高度
maxWidth  // 最大的宽度
maxHeight // 最大的高度

// 官方不推荐在 ConstraintLayout 中使用 match_parent，可以设置 0dp
```

宽高比

```
layout_constraintDimensionRatio="1:1"
// 已知宽求高，已宽为基准求高
app:layout_constraintDimensionRatio="H,2:3"
// 已知高求宽，已高为基准就宽
app:layout_constraintDimensionRatio="W,2:3"
```

**链**

如果两个或以上控件通过下图的方式约束在一起，就可以认为是他们是一条链（图为横向的链，纵向同理）。

![2787721b3b5a73715891a53.webp](https://b3logfile.com/file/2021/01/2787721b3b5a73715891a53-94dce5e0.webp)

用代码表示：

```
<TextView
        android:id="@+id/TextView1"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        app:layout_constraintLeft_toLeftOf="parent"
        app:layout_constraintRight_toLeftOf="@+id/TextView2" />

<TextView
    android:id="@+id/TextView2"
    android:layout_width="wrap_content"
    android:layout_height="wrap_content"
    app:layout_constraintLeft_toRightOf="@+id/TextView1"
    app:layout_constraintRight_toLeftOf="@+id/TextView3"
    app:layout_constraintRight_toRightOf="parent" />

<TextView
    android:id="@+id/TextView3"
    android:layout_width="wrap_content"
    android:layout_height="wrap_content"
    app:layout_constraintLeft_toRightOf="@+id/TextView2"
    app:layout_constraintRight_toRightOf="parent" />
```

```
layout_constraintHorizontal_chainStyle 来改变整条链的样式。chains提供了3种样式
CHAIN_SPREAD —— 展开元素 (默认)；
CHAIN_SPREAD_INSIDE —— 展开元素，但链的两端贴近parent；
CHAIN_PACKED —— 链的元素将被打包在一起。
```

![27877216d3fd9ce0f0cfd75.webp](https://b3logfile.com/file/2021/01/27877216d3fd9ce0f0cfd75-1142fa16.webp)

**权重链**

```
<TextView
    android:id="@+id/TextView1"
    android:layout_width="0dp"
    android:layout_height="wrap_content"
    app:layout_constraintLeft_toLeftOf="parent"
    app:layout_constraintRight_toLeftOf="@+id/TextView2"
    app:layout_constraintHorizontal_weight="2" />

<TextView
    android:id="@+id/TextView2"
    android:layout_width="0dp"
    android:layout_height="wrap_content"
    app:layout_constraintLeft_toRightOf="@+id/TextView1"
    app:layout_constraintRight_toLeftOf="@+id/TextView3"
    app:layout_constraintRight_toRightOf="parent"
    app:layout_constraintHorizontal_weight="3" />

<TextView
    android:id="@+id/TextView3"
    android:layout_width="0dp"
    android:layout_height="wrap_content"
    app:layout_constraintLeft_toRightOf="@+id/TextView2"
    app:layout_constraintRight_toRightOf="parent"
    app:layout_constraintHorizontal_weight="4" />
```

### 1.7.7 约束布局辅助工具

**Barrier**

![2787721-d8ef7a9da9ced277](/home/rainsheep/Desktop/2787721-d8ef7a9da9ced277.webp)

假设有 3 个控件 ABC，C 在 AB 的右边，但是 AB 的宽是不固定的，这个时候 C 无论约束在 A 的右边或者 B 的右边都不对。当出现这种情况可以用 Barrier 来解决。Barrier 可以在多个控件的一侧建立一个屏障，如下所示：

![2787721-5792b4a2839fa7e9](/home/rainsheep/Desktop/2787721-5792b4a2839fa7e9.webp)

这个时候 C 只要约束在 Barrier 的右边就可以了，代码如下：

```
<TextView
    android:id="@+id/TextView1"
    android:layout_width="wrap_content"
    android:layout_height="wrap_content" />

<TextView
    android:id="@+id/TextView2"
    android:layout_width="wrap_content"
    android:layout_height="wrap_content"
    app:layout_constraintTop_toBottomOf="@+id/TextView1" />

<android.support.constraint.Barrier
    android:id="@+id/barrier"
    android:layout_width="wrap_content"
    android:layout_height="wrap_content"
    app:barrierDirection="right"
    app:constraint_referenced_ids="TextView1,TextView2" />

<TextView
    android:id="@+id/TextView3"
    android:layout_width="wrap_content"
    android:layout_height="wrap_content"
    app:layout_constraintLeft_toRightOf="@+id/barrier" />
```

**Group**

Group 可以把多个控件归为一组，方便隐藏或显示一组控件，举个例子：

```
<TextView
    android:id="@+id/TextView1"
    android:layout_width="wrap_content"
    android:layout_height="wrap_content" />

<TextView
    android:id="@+id/TextView2"
    android:layout_width="wrap_content"
    android:layout_height="wrap_content"
    app:layout_constraintLeft_toRightOf="@+id/TextView1" />

<TextView
    android:id="@+id/TextView3"
    android:layout_width="wrap_content"
    android:layout_height="wrap_content"
    app:layout_constraintLeft_toRightOf="@id/TextView2" />

<android.support.constraint.Group
    android:id="@+id/group"
    android:layout_width="wrap_content"
    android:layout_height="wrap_content"
    android:visibility="invisible"
    app:constraint_referenced_ids="TextView1,TextView3" />
```

**Placeholder**

Placeholder 指的是占位符。在 Placeholder 中可使用 setContent 设置另一个控件的 id，使这个控件移动到占位符的位置。举个例子：

```
<android.support.constraint.Placeholder
    android:id="@+id/placeholder"
    android:layout_width="wrap_content"
    android:layout_height="wrap_content"
    app:content="@+id/textview"
    app:layout_constraintLeft_toLeftOf="parent"
    app:layout_constraintTop_toTopOf="parent" />

<TextView
    android:id="@+id/textview"
    android:layout_width="wrap_content"
    android:layout_height="wrap_content"
    android:background="#cccccc"
    android:padding="16dp"
    android:text="TextView"
    android:textColor="#000000"
    app:layout_constraintRight_toRightOf="parent"
    app:layout_constraintTop_toTopOf="parent" />
```

新建一个 Placeholder 约束在屏幕的左上角，新建一个 TextView 约束在屏幕的右上角，在 Placeholder 中设置 `app:content="@+id/textview"`，这时 TextView 会跑到屏幕的左上角。

**Guideline**

```
// Guildline 像辅助线一样，在预览的时候帮助你完成布局（不会显示在界面上）。
android:orientation // 垂直vertical，水平horizontal
layout_constraintGuide_begin // 开始位置
layout_constraintGuide_end // 结束位置
layout_constraintGuide_percent // 距离顶部的百分比(orientation = horizontal时则为距离左边)

<android.support.constraint.Guideline
    android:id="@+id/guideline1"
    android:layout_width="wrap_content"
    android:layout_height="wrap_content"
    android:orientation="horizontal"
    app:layout_constraintGuide_begin="50dp" />

<android.support.constraint.Guideline
    android:id="@+id/guideline2"
    android:layout_width="wrap_content"
    android:layout_height="wrap_content"
    android:orientation="vertical"
    app:layout_constraintGuide_percent="0.5" />
```

guideline1 为水平辅助线，开始位置是距离顶部 50dp，guideline2 位垂直辅助线，开始位置为屏幕宽的 0.5 (中点位置)，效果如下：

![2787721870080d070c12e91.webp](https://b3logfile.com/file/2021/01/2787721870080d070c12e91-c2dea492.webp)

# 2. 控件

## 2.1 TextView

```
text        // 设置显示的文本内容
textColor   // 设置字体颜色
textStyle   // 设置字体风格，normal/bold/italic
textSize    // 字体大小，单位一般是用sp
background  // 控件的背景颜色，可以是图片
```

**阴影**

```
shadowColor  //设置阴影颜色,需要与shadowRadius一起使用
shadowRadius // 设置阴影的模糊程度,设为0.1就变成字体颜色了,建议使用3.0
shadowDx     // 设置阴影在水平方向的偏移
shadowDy     // 设置阴影在竖直方向的偏移
```

**边框**

```
// 自行编写一个 ShapeDrawable 的资源文件,然后 TextView 将 backgroung 设置为这个drawable 资源

// shapeDrawable资源文件的几个节点以及属性
// 这个是设置背景颜色的
<solid android:color = "xxx">  

// 这个是设置边框的粗细,以及边框颜色的
<stroke android:width = "xdp" android:color="xxx">

// 这个是设置边距的
<padding androidLbottom = "xdp"...> 

// 这个是设置圆角的
<corners android:topLeftRadius="10px"...> 

// 这个是设置渐变色的,可选属性有: 
// startColor:起始颜色 
// endColor:结束颜色 
// centerColor:中间颜色 
// angle:方向角度,等于0时,从左到右,然后逆时针方向转,当angle = 90度时从下往上 
// type:设置渐变的类型
<gradient>
```

**带图片 (drawableXxx) 的 TextView**

```
drawableTop
drawableButtom
drawableLeft
drawableRight
// 设置图片与文字间的间距
drawablePadding

// 如需设置图片大小，需通过 java 代码设置
txtZQD = (TextView) findViewById(R.id.txtZQD);  
Drawable[] drawable = txtZQD.getCompoundDrawables();  
// 数组下表0~3,依次是:左上右下  
drawable[1].setBounds(100, 0, 200, 200);  
txtZQD.setCompoundDrawables(drawable[0],drawable[1],drawable[2],drawable[3]);
```

**识别链接类型**

当文字中出现了 URL，E-Mail，电话号码，地图的时候，我们可以通过设置 autoLink 属性；当我们点击文字中对应部分的文字，即可跳转至某默认 APP，比如一串号码，点击后跳转至拨号界面！

```
autoLink="email/none/web/email/phone/map/all"
// all 就是全部都包含,自动识别协议头

//在Java代码中
setAutoLinkMask(Linkify.ALL); setMovementMethod(LinkMovementMethod.getInstance());
```

**包含 HTML**

常用标签：font、big、small、i、b、a、img

```
TextView t1 = (TextView)findViewById(R.id.txtOne);
String s1 = "<a href = 'http://www.baidu.com'>百度</a>";
t1.setText(Html.fromHtml(s1));
t1.setMovementMethod(LinkMovementMethod.getInstance());
```

**定制文本**

SpannableString(针对的是不可变文本)、SpannableStringBuilder(针对可变文本)

此处只讲解 SpannableString

```
BackgroundColorSpan  // 背景色
ClickableSpan        // 文本可点击，有点击事件
ForegroundColorSpan  // 文本颜色（前景色）
MaskFilterSpan       // 修饰效果，如模糊(BlurMaskFilter)、浮雕(EmbossMaskFilter)
MetricAffectingSpan  // 父类，一般不用
RasterizerSpan       // 光栅效果
StrikethroughSpan    // 删除线（中划线）
SuggestionSpan       // 相当于占位符
UnderlineSpan        // 下划线
AbsoluteSizeSpan     // 绝对大小（文本字体）
DynamicDrawableSpan  // 设置图片，基于文本基线或底部对齐。
ImageSpan            // 图片
RelativeSizeSpan     // 相对大小（文本字体）
ReplacementSpan      // 父类，一般不用
ScaleXSpan           // 基于 x 轴缩放
StyleSpan            // 字体样式：粗体、斜体等
SubscriptSpan        // 下标（数学公式会用到）
SuperscriptSpan      // 上标（数学公式会用到）
TextAppearanceSpan   // 文本外貌（包括字体、大小、样式和颜色）
TypefaceSpan         // 文本字体
URLSpan              // 文本超链接
```

使用例子

```
TextView t1 = (TextView) findViewById(R.id.txtOne);
SpannableString span = new SpannableString("红色打电话斜体删除线绿色下划线图片:.");
// 设置背景色,setSpan时需要指定的flag,Spanned.SPAN_EXCLUSIVE_EXCLUSIVE(前后都不包括)
span.setSpan(new ForegroundColorSpan(Color.RED), 0, 2, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
// 用超链接标记文本
span.setSpan(new URLSpan("tel:4155551212"), 2, 5, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
t1.setText(span);
```

**跑马灯**

```
singleLine="true"      // 文本一行显示
ellipsize="marquee"    // start(省略号在开头)、end、middle、marquee(跑马灯)
marqueeRepeatLimit="marquee_forever"  // 重复滚动次数，marquee_forever 无限滚动
```

## 2.2 EditText

输入框

```
hint="默认提示文本"
// 提示文本颜色
textColorHint="#95A1AA"
// 获得焦点后全选组件内所有文本内容
selectAllOnFocus="true"
```

输入类型

```
inputType="none"  
inputType="text"  
inputType="textCapCharacters"  
inputType="textCapWords"  
inputType="textCapSentences"  
inputType="textAutoCorrect"  
inputType="textAutoComplete"  
inputType="textMultiLine"  
inputType="textImeMultiLine"  
inputType="textNoSuggestions"  
inputType="textUri"  
inputType="textEmailAddress"  
inputType="textEmailSubject"  
inputType="textShortMessage"  
inputType="textLongMessage"  
inputType="textPersonName"  
inputType="textPostalAddress"  
inputType="textPassword"  
inputType="textVisiblePassword"  
inputType="textWebEditText"  
inputType="textFilter"  
inputType="textPhonetic" 

inputType="number"  
inputType="numberSigned"  
inputType="numberDecimal"  
inputType="phone"//拨号键盘  
inputType="datetime"  
inputType="date"//日期键盘  
inputType="time"//时间键盘
```

行相关

```
minLines="3"
maxLines="3"
singleLine="true"
```

文字间隔

```
// 设置字与字的水平间隔
textScaleX="1.5"    
//设置字与字的垂直间隔
textScaleY="1.5"
```

英文字母大写类型

```
capitalize="none | sentences | words | characters"
```

焦点

```
edit.requestFocus(); //请求获取焦点
edit.clearFocus(); //清除焦点

自动弹出键盘需要配置 windowSoftInputMode
```

光标位置

```
// 让 EditText 获得焦点时选中全部文本
setSelectAllOnFocus(true)
// 设置光标不显示
setCursorVisible(false)
// 获得当前光标的前后位置
getSelectionStart
getSelectionEnd
```

