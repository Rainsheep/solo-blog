title: stl-map
date: '2019-12-03 19:43:30'
updated: '2019-12-03 19:43:30'
tags: [STL, 知识点总结]
permalink: /articles/2019/12/03/1575373410663.html
---
# map 的概念

map&lt;key,value&gt; mp,map 翻译为映射，key 具有唯一性，key-value 为一对一的映射关系，map 自带的自动排序是根据 key 的值来排序的。

# map 的基本操作

map&lt;key,value&gt; mp,定义一个 map

mp.find(key);返回键为 key 的映射的迭代器，找不到则返回 mp.end();  O（logn）

mp.count(key); 有此 key 返回 1，否则返回 0；

mp.size();map 中映射的对数 O（1）

mp.clear();清空 mp 中所有元素

# pair 介绍

pair 可以用来代替具有两个元素的结构体；

pair&lt;type1,type2&gt; name;

pair&lt;char,int&gt; p(‘c’,5);初始化

若想临时构建一个 pair，pair&lt;string,int&gt;(“haha”,5)或者 make_pair(“haha”,5);

Pair 中两个元素 first 和 second，按访问结构体的方式访问；name.first 和 name.second

# map 元素的插入

第一种

map 具有两个类型，元素插入方式较为特殊，需要用到 pair；

mp.insert(make_pair(“haha”,5) );

mp.insert(pair&lt;string,int&gt;(“haha”,5) );

若已有此键值时不会覆盖原元素；

第二种

Map 可以通过下标插入

例如：mp[str]=int;

与上面不同的是若已经有此 key 键，则会覆盖原元素

# map 元素的删除

与 set 一样，map 的 key 值具有唯一性，删除函数的参数可以为迭代器或者 key 键；

Mp.erase(it);

Mp.erase(key);

Mp.erase(it1,it2);删除区间内元素；

# map 元素的访问

1. 通过下标访问

Map&lt;char,int&gt; mp;

Mp[‘c’]++;

Cout&lt;&lt;mp[‘c’];

需要注意的是，这种访问方式若没有此键值的时候会自动建立并且 value 值初始化为 0；

2. 通过迭代器访问

Map&lt;type1,type2&gt;::iterator it;

可以通过 it-&gt;first 或者(*it).first 和 it-&gt;second 或者(*it).second 来访问 key 值和 value 值

# map 的排序

map 中自动按 key 值从小到大排序，如存放结构体或者需要自定义排序规则，和 set 的更改方式一样，请自行查看 set;

此处值介绍最简单的更改排序的方式

Map&lt;char,int,greater&lt;char&gt; &gt; mp;按键值从大到小排序；

关于 map 按 value 排序，map 并不支持按 value 值排序，需要自己想办法实现；

可以将 map 的 key 和 value 值存放在 pair 数组或者 pair 类型的 vector 中，用 sort 排序；

注意：排好序后不能再放进 map 中，否则会再根据 key 值排序；

问：为什么不把 map&lt;type1,type2&gt; 放进 map&lt;type2,type1&gt; 中排序

答：value 值不是唯一的，而 key 值是唯一的，颠倒过来会自动删除重复的 value 值，从而导致 key 键减少；
