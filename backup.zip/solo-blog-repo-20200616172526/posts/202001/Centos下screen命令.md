title: Centos下screen命令
date: '2020-01-04 23:42:42'
updated: '2020-01-04 23:42:42'
tags: [Linux, 软件教程]
permalink: /articles/2020/01/04/1578152561987.html
---
参考链接：
[Linux下screen的使用方法](https://wenku.baidu.com/view/10693509f424ccbff121dd36a32d7375a517c671.htmlLi)
[linux命令之yum、screen](https://blog.csdn.net/u010476739/article/details/86571453)
[查看自己是不是在screen里边](http://blog.sciencenet.cn/blog-824391-879436.html)

### 0.使用背景

我们在使用 Linux 时，有时一些命令或脚要执行很长时间，为了防止网络或者主机中断导致命令失败退出，我们可以使用 nohup 放到后台运行，也可以使用 screen 命令

### 1.安装 screen

`yum install -y screen`

### 2.新建会话窗口

* 创建一个 screen 并指定名称
  `screen -S 名字`
* 创建一个 screen 不指定名称
  `screen`
* 创建 screen 并允许指令
  `screen 指令`

> 创建成功即会进入此 screen

### 3.退出当前的会话窗口(退出后这个 screen 就会消失)

`exit`

### 4.分离窗口

* 分离当前窗口
  `ctrl+a,d` 即先按 ctrl+a 再按 d
* 分离指定窗口
  `screen -d id或name`

### 5.列出当前所有会话窗口

`screen -ls`

输出例子：

```
There are screens on:
        3675.pts-0.yuyang       (Attached)
        3686.s1 (Detached)
2 Sockets in /var/run/screen/S-root.
```

> 3675 和 3686 即为会话 id
> pts-0.yuyang 和 s1 即为会话名称
> attached 代表此会话已经被连接，detached 代表此会话被分离
> 一个 screen 会话窗口只能被一个终端连接
> attached 状态下不能使用`screen -r id`回到此会话窗口

### 6.进入指定会话窗口

* 进入指定会话
  `screen -r id或name`
* 分离当前会话并进入指定会话
  `screen -d -r id或name`

### 7.清除会话窗口

* 杀死会话进程
  `kill -9 id`
* 清除被杀死的会话
  `screen -wipe`

### 8.查看当前所在的会话窗口

* 如果回显是空的，那么就是在终端里，否则会显示当前的 screen ID.
`echo $STY`

* 显示当前终端种类
`echo $TERM `

