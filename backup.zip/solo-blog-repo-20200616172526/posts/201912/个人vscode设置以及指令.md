title: 个人vscode设置以及指令
date: '2019-12-04 15:01:36'
updated: '2020-04-29 14:58:20'
tags: [软件教程]
permalink: /articles/2019/12/04/1575442896111.html
---
## 命令

配置语言： `Configure Display Language`

## 快捷键

显示所有命令： `ctrl+shift+p`
格式化代码： `shift+alt+f`

## 背景图插件： background-cover

本插件通过修改 vscode 的 CSS 文件运行，会显示 code-insiders 损坏，选择不再提醒，顶部会显示不受支持。

解决办法：

运行 `ext install lehni.vscode-fix-checksums` 安装插件，运行下列第一个命令然后重启即可。

`Fix Checksums: Apply` // Checks core files for changes and applies new checksums.
`Fix Checksums: Restore` // Restores original state of VSCode checkums.

插件配置：

```
//#插件background-cover
//图片路径
"backgroundCover.imagePath": "c:\\Users\\10766\\Pictures\\ideaBackground\\23.jpg",
//透明度
"backgroundCover.opacity": 0.6,
```

## 格式化插件 beautify

本插件可自定义格式化 html,js,css,json 文件。
[官方文档](https://github.com/HookyQR/VSCodeBeautify/blob/master/Settings.md)

插件配置：

```
//#beautify插件格式化代码
//设置html的默认格式化方式
"[html]": {
	"editor.defaultFormatter": "HookyQR.beautify"
},
//格式风格
"brace_style": "none,preserve-inline",
"[javascript]": {
	"editor.defaultFormatter": "HookyQR.beautify"
},
```

## 翻译插件 Comment Translate

插件特征：

1. 悬停翻译注释
2. 支持用户字符串与变量翻译，支持驼峰拆分
3. 划线翻译
4. 翻译并替换选择内容
5. 合并多行注释（两行注释合并为一行翻译）

插件配置：

```
//#Comment translate插件
//合并多行注释
 "commentTranslate.multiLineMerge": true,
```

## 运行插件 Code Runner

插件介绍：可以在 vscode 中快捷的运行代码

插件功能：

* 支持多种语言
* 支持文件运行
* 支持文件中部分代码运行

插件配置：

```
//#Code Runner插件
//运行配置
"code-runner.executorMap": {
    "javascript": "node",
    "python": "set PYTHONIOENCODING=utf8 && py -3",
    //"go": "go run",
    "html": "\"C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe\"",
    "java": "cd $dir && javac $fileName && java $fileNameWithoutExt",
    "cpp": "cd $dir && g++ $fileName -o $fileNameWithoutExt && $dir$fileNameWithoutExt",
},
//运行前保存当前文件
"code-runner.saveFileBeforeRun": true,
//清除前面的输出
"code-runner.clearPreviousOutput": true,
//在终端执行命令
//"code-runner.runInTerminal": true,
```

## 自动修改配对标签 Auto Rename Tag

插件介绍：修改标签的时候，自动修改配对的标签。

插件配置：可以用 `"*"` 代表所有语言

```json
"auto-rename-tag.activationOnLanguage": ["html", "xml", "php", "javascript"]
```

## 目前 JSON

```
{
    //#编程字体设置
    //字体样式
    "editor.fontFamily": "Source Code Pro, Consolas, 'Courier New', monospace",
    //字体大小
    "editor.fontSize": 16,

    //#终端设置
    //终端采用cmd
    "terminal.integrated.shell.windows": "C:\\WINDOWS\\System32\\cmd.exe",

    //#保存文件
    //文件自动保存
    "files.autoSave": "onFocusChange",
    //键入一行时自动格式化该行
    "editor.formatOnType": true,

    //#自动更新设置
    //禁止后台下载更新文件
    "update.enableWindowsBackgroundUpdates": false,
    //禁止自动更新，只可手动更新
    "update.mode": "manual",
    "workbench.startupEditor": "newUntitledFile",
    "explorer.confirmDelete": false,

    //#插件background-cover
    //图片路径
    "backgroundCover.imagePath": "c:\\Users\\10766\\Pictures\\ideaBackground\\23.jpg",
    //透明度
    "backgroundCover.opacity": 1,

    //#beautify插件格式化代码
    //设置html的默认格式化方式
    "[html]": {
        "editor.defaultFormatter": "HookyQR.beautify"
    },
    //格式风格
    "brace_style": "none,preserve-inline",
    "[javascript]": {
        "editor.defaultFormatter": "HookyQR.beautify"
    },
    "extensions.ignoreRecommendations": true,

    //#Comment translate插件
    //合并多行注释
    "commentTranslate.multiLineMerge": true,

    //#Code Runner插件
    //运行配置
    "code-runner.executorMap": {
        "javascript": "node",
        "python": "set PYTHONIOENCODING=utf8 && py -3",
        //"go": "go run",
        "html": "\"C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe\"",
        "java": "cd $dir && javac $fileName && java $fileNameWithoutExt",
        "cpp": "cd $dir && g++ $fileName -o $fileNameWithoutExt && $dir$fileNameWithoutExt",
    },
    //运行前保存当前文件
    "code-runner.saveFileBeforeRun": true,
    //清除前面的输出
    "code-runner.clearPreviousOutput": true,
    "[json]": {
        "editor.defaultFormatter": "HookyQR.beautify"
    },
    //在终端执行命令
    //"code-runner.runInTerminal": true,
}
```
