title: Git 学习笔记
date: '2020-03-13 17:22:56'
updated: '2020-03-13 17:22:56'
tags: [学习笔记]
permalink: /articles/2020/03/13/1584091376522.html
---
### 1. Git 基础

* Git 工作流程
  1. 从远程仓库中克隆 Git 资源作为本地仓库。
  2. 从本地仓库中 checkout 代码然后进行代码修改
  3. 在提交前先将代码提交到暂存区。
  4. 提交修改。提交到本地仓库。本地仓库中保存修改的各个历史版本。
  5. 在修改完成后，需要和团队成员共享代码时，可以将代码 push 到远程仓库。
* ![](https://raw.githubusercontent.com/Rainsheep/pic-bed/master/img/2020-03-09+13:46:30+git.png)

### 2. 使用 Git 管理文件版本

* 版本库：版本库又名仓库，英文名 repository，你可以简单理解成一个目录，这个目录里面的所有文件都可以被 Git 管理起来，每个文件的修改、删除，Git 都能跟踪，以便任何时刻都可以追踪历史，或者在将来某个时刻可以“还原”。由于 Git 是分布式版本管理工具，所以 Git 在不需要联网的情况下也具有完整的版本管理能力。
* 创建版本库：`git init`
* 版本库：`.git` 目录就是版本库，将来文件都需要保存到版本库中。
  工作目录：包含 `.git` 目录的目录，也就是 `.git` 目录的上一级目录就是工作目录。只有工作目录中的文件才能保存到版本库中。
* Git 的版本库里存了很多东西，其中最重要的就是称为 stage（或者叫 index）的暂存区，还有 Git 为我们自动创建的第一个分支 master，以及指向 master 的一个指针叫 HEAD。![](https://raw.githubusercontent.com/Rainsheep/pic-bed/master/img/2020-03-09+16:04:42+stage.jpg)
* 添加文件可将文件添加至暂存区。`git add <file name>`
* 提交后此文件将保存至版本库。
  * `git commit <file name>`
  * `git commit -m "日志信息" <file name>`
* `.gitignore` 文件保存的是要忽略的文件或文件夹，此文件也需要提交到版本库。
* 还原修改：当文件修改后不想把修改的内容提交，还想还原到未修改之前的状态。此时可以使用“还原”功能。
* 可将文件从版本库删除，删除后也需要提交。

### 3. 远程仓库

* 同步到 GitHub 可通过 SSH 和 https 两种方式，SSH 通过公钥密钥来认证，公钥需放置在 GitHub，密钥在本地，https 则通过账号密码认证。
* 生成公钥和密钥：`ssh-keygen -t rsa`，在 `C:\User\10766\.ssh` 目录下。
* GitHub → Settings → SSH and GPG keys 来配置公钥。
* 使用 SSH 方式推送：
  ```
  git remote add origin git@github.com:Rainsheep/test.git
  git push -u origin master
  ```
* https 方式推送：
  ```
  git remote add origin https://github.com/Rainsheep/test.git
  git push -u origin master
  ```
* 从远程仓库克隆：`git clone git@github.com:Rainsheep/test.git`
* 从远程仓库取代码：
  * `git fetch`：相当于是从远程获取最新版本到本地，不会自动 merge
  * `git pull`：相当于是从远程获取最新版本并 merge 到本地
  * `git fetch` 更安全一些，我们可以查看更新情况，然后再决定是否合并
