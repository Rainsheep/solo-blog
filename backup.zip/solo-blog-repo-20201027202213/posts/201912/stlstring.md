title: stl—string
date: '2019-12-03 19:35:08'
updated: '2019-12-03 19:35:08'
tags: [STL, 知识点总结]
permalink: /articles/2019/12/03/1575372908295.html
---
# string的概念
可以用来存放字符串，操作方便

# string的基本操作
头文件#include\<string>

String s;定义一个string；

初始化 string s=”abc”;定义的时候直接赋值；

Cin>>string;输入一个字符串，以空格、tab、换行结束；

getline(cin,s);输入一个字符串，以回车结束，可以包含空格；

getline(cin,s,’c’);输入一个字符串，遇到字符’c’才结束输入，可输入空格.tab、回车

string s1,s1;  s1+=s2;或者s1+=”abc”;可以直接进行拼接操作；

两个string类型可以直接使用==、！=、<、>、<=、>=比较大小，比较规则按字典序

s.size()/lenth();获取string的长度；

s.clear();清空string;

s1.swap(s2);交换s1，s2;

s.empty() ;判断字符串是否为空

 string s(num,’c’) 生成一个字符串，包含num个c字符

s=str;将s清空后，把str赋值给s;

string s(str);定义s，并将str赋值给s；

 string可直接使用sort（可自写函数定义排序规则），reverse进行排序和颠倒

 

不常用操作：

s.substr(pos,len);返回pos位开始、长度为len的字符串。O（N）

s.replace(pos,len,str);把str从pos下标开始，把长度为len的子串替换为str。

 

string的插入O(N)：

string的插入函数的参数不仅可以是迭代器还可以是坐标。

s.insert(pos,string);在pos位插入字符串string。

s.insert(it,it2,it3);在it位置插入迭代器it2~it3的元素；

 

# string元素的删除O（N）：
删除通用可以用下标可迭代器两种方式。

s.erase(it);删除一个元素；

s.erase(it1,it2);删除区间内元素

s.erase(pos,lenth);从pos下标开始,删除长度为lenth的元素;

 

string的查找O（nm）nm为两串的长度：

s.find(s2);当s2是s的子串时，返回第一次出现的下标，如果不是，返回-1；

s.find(s2,pos);从s的pos下标开始查找s2；

s.rfind();从反方向开始查找
