title: resin 记录
date: '2020-11-02 21:19:00'
updated: '2020-11-02 21:19:00'
tags: [java]
permalink: /articles/2020/11/02/1604323139963.html
---
### xmlns 错误

错误信息如下：

```
WEB-INF/web.xml:5: <web-app xmlns="http://xmlns.jcp.org/xml/ns/javaee">
is an unexpected top-level tag.

3:          xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
4:          xsi:schemaLocation="http://xmlns.jcp.org/xml/ns/javaee http://xmlns.jcp.org/xml/ns/javaee/web-app_3_1.xsd"
5:          version="3.1">
6: 
7: </web-app>


<web-app xmlns="http://caucho.com/ns/resin">,
<web-app xmlns="http://java.sun.com/xml/ns/j2ee">,
<web-app xmlns="http://java.sun.com/xml/ns/javaee">,
<web-fragment xmlns="http://java.sun.com/xml/ns/javaee"> or
<web-app xmlns=""> are expected.

Syntax: (<web-app> | <web-app> | <web-app> | <web-app> | <web-fragment>
| <web-app>)
```

解决办法：

将 web.xml 版本改为 3.0

```xml
<?xml version="1.0" encoding="UTF-8"?>
<web-app xmlns="http://java.sun.com/xml/ns/javaee"
           xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
           xsi:schemaLocation="http://java.sun.com/xml/ns/javaee
		  http://java.sun.com/xml/ns/javaee/web-app_3_0.xsd"
           version="3.0">
</web-app>
```
