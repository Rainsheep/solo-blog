title: Docker中批量删除 tag为"none"的镜像
date: '2020-08-16 14:42:39'
updated: '2020-08-16 14:42:39'
tags: [Linux]
permalink: /articles/2020/08/16/1597560159237.html
---
`docker images | grep none | awk '{print $3}' | xargs docker rmi`

docker images：列出镜像列表

grep none：筛选出带 none 的行

awk '{print $3}'：输出第三列

xargs docker rmi：将前面的每一行当做参数给后面的命令
