title: 快速输入函数（比scanf快）
date: '2019-12-03 20:28:27'
updated: '2019-12-03 20:28:27'
tags: [知识点总结, acm]
permalink: /articles/2019/12/03/1575376107775.html
---
```cpp
#include<iostream>  
using namespace std;
inline int read()   //输入外挂，输入量大时，比scanf效率高   
{  
    int x=0,f=1;  
    char ch=getchar();  
    while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}  
    while(ch>='0'&&ch<='9'){x=x*10+ch-'0';ch=getchar();}  
    return x*f;  
}
int main()  
{  
    int t;  
    while(t=read())//0进不入循环 会结束，但可以读0 
    cout<<t<<endl;  
}  

```
