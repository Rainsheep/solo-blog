title: IDEA图标解释
date: '2020-08-03 22:30:49'
updated: '2020-08-03 22:44:09'
tags: [IDEA]
permalink: /articles/2020/08/03/1596465049727.html
---
参考链接：[IDEA图标解释](https://blog.csdn.net/jenrey/article/details/80077783)

### 共同

| 图标 | 描述 |
| - | :- |
| ![classTypeJavaClass1.png](https://b3logfile.com/file/2020/08/classTypeJavaClass-51ab335c.png) | 类 |
| ![classTypeAbstractij.png](https://b3logfile.com/file/2020/08/classTypeAbstractij-a787b2ab.png) | 抽象类 |
| ![classGroovyClass.png](https://b3logfile.com/file/2020/08/classGroovyClass-f6c89fb8.png) | Groovy类 |
| ![classTypeAnnot.png](https://b3logfile.com/file/2020/08/classTypeAnnot-4afb939c.png) | 注解 |
| ![classTypeEnum.png](https://b3logfile.com/file/2020/08/classTypeEnum-70e31b5a.png) | 列举 |
| ![classTypeException.png](https://b3logfile.com/file/2020/08/classTypeException-e7d06cba.png) | 例外 |
| ![classTypeFinal.png](https://b3logfile.com/file/2020/08/classTypeFinal-c0cc4c33.png) | 最终的Java类 |
| ![classTypeInterface.png](https://b3logfile.com/file/2020/08/classTypeInterface-75ad9668.png) | 接口 |
| ![classTypeMain.png](https://b3logfile.com/file/2020/08/classTypeMain-ae540268.png) | 包含main方法声明的Java类 |
| ![classTypeTestCase.png](https://b3logfile.com/file/2020/08/classTypeTestCase-1e8fae00.png) | 测试用例 |
| ![classTypeJavaOutOfSourceRoot.png](https://b3logfile.com/file/2020/08/classTypeJavaOutOfSourceRoot-e3d813eb.png) | Java类位于Sources根目录之外 |
| ![excludeFromCompilation.png](https://b3logfile.com/file/2020/08/excludeFromCompilation-33d74a92.png) | 从编译中排除的Java类 |
| ![phpTrait.png](https://b3logfile.com/file/2020/08/phpTrait-1df7e73d.png) | PHP特质 |
| ![phpTest.png](https://b3logfile.com/file/2020/08/phpTest-3e3db604.png) | PHP测试 |
| ![method.png](https://b3logfile.com/file/2020/08/method-7ee40a81.png) | 方法 |
| ![methodabstract.png](https://b3logfile.com/file/2020/08/methodabstract-b936eafb.png) | 抽象方法 |
| ![field.png](https://b3logfile.com/file/2020/08/field-6c27e039.png) | 领域 |
| ![variable.png](https://b3logfile.com/file/2020/08/variable-d77c6745.png) | 变量 |
| ![property.png](https://b3logfile.com/file/2020/08/property-1e0d86a1.png) | 属性 |
| ![propertyyellow.png](https://b3logfile.com/file/2020/08/propertyyellow-922c2f48.png) | 参数 |
| ![xmlelement.png](https://b3logfile.com/file/2020/08/xmlelement-517a52e2.png) | 元件 |
| ![folder.png](https://b3logfile.com/file/2020/08/folder-631a91c2.png) | 目录 |
| ![moduleFolder.png](https://b3logfile.com/file/2020/08/moduleFolder-2b3d22f5.png) | 模 |
| ![groupOfModules.png](https://b3logfile.com/file/2020/08/groupOfModules-6b345325.png) | 一组模块 |
| ![packageiconlarge.png](https://b3logfile.com/file/2020/08/packageiconlarge-716095e0.png) | 包 |
| ![rootSource.png](https://b3logfile.com/file/2020/08/rootSource-09ad9605.png) | 源根 |
| ![rootTest.png](https://b3logfile.com/file/2020/08/rootTest-1eb8352f.png) | 测试根 |
| ![rootExcluded.gif](https://b3logfile.com/file/2020/08/rootExcluded-2eae7ef8.gif) | 排除的根 |
| ![rootResourceIJ.png](https://b3logfile.com/file/2020/08/rootResourceIJ-5eed05a9.png) | 资源 |
| ![rootTestResourceIJ.png](https://b3logfile.com/file/2020/08/rootTestResourceIJ-6e34b09b.png) | 测试资源 |
| ![rootGeneratedSourceIJ.png](https://b3logfile.com/file/2020/08/rootGeneratedSourceIJ-c70b8d0c.png) | 生成的源根 |
| ![rootGeneratedTestSourceIJ.png](https://b3logfile.com/file/2020/08/rootGeneratedTestSourceIJ-9b048708.png) | 生成测试源根 |

### 可见性修饰符

| 图标 | 描述 |
| - | - |
| ![lockedij.png](https://b3logfile.com/file/2020/08/lockedij-330f5041.png) | 只读类，例如来自外部库的jar |
| ![privateij.png](https://b3logfile.com/file/2020/08/privateij-d3520320.png) | 私人的 |
| ![protectedij.png](https://b3logfile.com/file/2020/08/protectedij-527da49c.png) | 保护 |
| ![packageprotected.png](https://b3logfile.com/file/2020/08/packageprotected-fc3521de.png) | 包保护 |
| ![staticMark.png](https://b3logfile.com/file/2020/08/staticMark-083368ef.png) | 静态的 |
| ![public.png](https://b3logfile.com/file/2020/08/public-4dfed0b7.png) | 上市 |

### 数据源

| 图标 | 描述 |
| - | - |
| ![DataSource.png](https://b3logfile.com/file/2020/08/DataSource-b75295e1.png) | DB数据源 |
| ![DBAmazonRedshift.png](https://b3logfile.com/file/2020/08/DBAmazonRedshift-018635c5.png) | 亚马逊红移 |
| ![DBDB2.png](https://b3logfile.com/file/2020/08/DBDB2-308b7bb9.png) | DB2 |
| ![DBDerby.png](https://b3logfile.com/file/2020/08/DBDerby-9fb6f579.png) | 德比 |
| ![DBH2.png](https://b3logfile.com/file/2020/08/DBH2-1664feba.png) | H2 |
| ![DBHSQLDB.png](https://b3logfile.com/file/2020/08/DBHSQLDB-8a7fc3c0.png) | HSQLDB |
| ![DBMicrosoftAzure.png](https://b3logfile.com/file/2020/08/DBMicrosoftAzure-2bd4145c.png) | 微软Azure |
| ![DBMySQL.png](https://b3logfile.com/file/2020/08/DBMySQL-974a2808.png) | MySQL |
| ![DBOracle.png](https://b3logfile.com/file/2020/08/DBOracle-ad2f3b06.png) | 神谕 |
| ![DBPostgresql.png](https://b3logfile.com/file/2020/08/DBPostgresql-adda176f.png) | PostgreSQL的 |
| ![DBSQLServer.png](https://b3logfile.com/file/2020/08/DBSQLServer-6185d59a.png) | SQL Server |
| ![DBSQLite.png](https://b3logfile.com/file/2020/08/DBSQLite-b101e22c.png) | SQLite的 |
| ![DBSybase.png](https://b3logfile.com/file/2020/08/DBSybase-fe61529f.png) | SYBASE |
| ![DBReadonly.png](https://b3logfile.com/file/2020/08/DBReadonly-ca565d3d.png) | 具有只读状态的数据源 |
| ![iconDDLDataSource.png](https://b3logfile.com/file/2020/08/iconDDLDataSource-40cb3bae.png) | DDL数据源 |
| ![dataDatabase.png](https://b3logfile.com/file/2020/08/dataDatabase-770e89e8.png) | 数据库 |
| ![dataSchema.png](https://b3logfile.com/file/2020/08/dataSchema-8e9f9a91.png) | 架构 |
| ![DataTables.png](https://b3logfile.com/file/2020/08/DataTables-ea1b4d77.png) | 表 |
| ![dataView.png](https://b3logfile.com/file/2020/08/dataView-0b252049.png) | 视图 |
| ![dataColumn.png](https://b3logfile.com/file/2020/08/dataColumn-0d5abb19.png) | 柱 |
| ![dataColumnNotNull.png](https://b3logfile.com/file/2020/08/dataColumnNotNull-840510ac.png) | NOT NULL列 |
| ![dataPkColumn.png](https://b3logfile.com/file/2020/08/dataPkColumn-34b4d91f.png) | 具有主键的列 |
| ![dataFkColumn.png](https://b3logfile.com/file/2020/08/dataFkColumn-f082eff6.png) | 带有外键的列 |
| ![dataIndexedColumn.png](https://b3logfile.com/file/2020/08/dataIndexedColumn-dc560577.png) | 具有索引的列 |
| ![dataPrimaryKey.png](https://b3logfile.com/file/2020/08/dataPrimaryKey-57623fec.png) | 首要的关键 |
| ![dataForeignKey.png](https://b3logfile.com/file/2020/08/dataForeignKey-0889ecc3.png) | 外键 |
| ![dataIndex.png](https://b3logfile.com/file/2020/08/dataIndex-e93eacd3.png) | 指数 |
| ![dataTrigger.png](https://b3logfile.com/file/2020/08/dataTrigger-8062215f.png) | 触发 |
| ![dataFunction.png](https://b3logfile.com/file/2020/08/dataFunction-80a0fe5a.png) | 存储过程或功能 |
