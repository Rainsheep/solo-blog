title: docker 安装 tomcat
date: '2020-08-16 12:43:28'
updated: '2020-08-16 14:21:33'
tags: [Linux]
permalink: /articles/2020/08/16/1597553008490.html
---
参考文献：

[docker运行tomcat](https://www.jianshu.com/p/a366351cc9a6)

[docker参数详解](https://blog.csdn.net/qq_15551663/article/details/89031773)

**搜索 tomcat 镜像**

```
docker search tomcat
```

**下载 tomcat 镜像**

```
docker pull tomcat
```

**查看本地镜像**

```
docker images
```

**创建映射文件夹**

```
mkdir -p /dockerData/tomcat/webapps
mkdir -p /dockerData/tomcat/conf
```

**运行 tomcat 镜像**

```
docker run --name tomcat -d -p 8083:8080 --rm tomcat 
```

* -d 后台运行
* -p 主机8083端口映射到docker容器内部的8080端口
* --rm 停止后删除此镜像

**查看镜像是否启动成功**

```
docker ps
```

**测试**

```
cd /dockerData/tomcat/webapps
mkdir test
cd test
vim hello.html
```

**书写 html**

```
<!DOCTYPE html>
<html>
<head>
  <title>Document</title>
</head>
  <body>
      Hello world111
  </body>
</html>
```

访问：http://www.rainsheep.cn:8083/test/hello.html

**导出配置文件**

```
docker cp tomcat:/usr/local/tomcat/conf /dockerData/tomcat
docker cp tomcat:/usr/local/tomcat/webapps /dockerData/tomcat
```

**修改 tomcat 端口号（防止端口冲突）**

```
vim /dockerData/tomcat/conf/server.xml
查找8080修改为8083
```

**删除 tomcat 容器**

```
docker stop tomcat
```

**启动 tomcat 容器**

```
docker run -d --name tomcat --network=host \
-v /dockerData/tomcat/conf:/usr/local/tomcat/conf \
-v /dockerData/tomcat/webapps:/usr/local/tomcat/webapps tomcat
```

* --network=host 代表使用主机网络，方便直接访问 tomcat
* 好像一大会才可以访问

访问：http://www.rainsheep.cn:8083/test/hello.html

**启用 https 访问**

编辑 nginx 配置文件，添加

```
server {
    listen 8086 ssl;
    server_name  www.rainsheep.cn;
    access_log off;
  
    ssl_certificate /ssl/3783689_www.rainsheep.cn.pem;
    ssl_certificate_key /ssl/3783689_www.rainsheep.cn.key;
    ssl_session_timeout 5m; 
    ssl_protocols TLSv1 TLSv1.1 TLSv1.2;
    ssl_ciphers ECDHE-RSA-AES128-GCM-SHA256:HIGH:!aNULL:!MD5:!RC4:!DHE;
    ssl_prefer_server_ciphers on; 

    location / { 
        proxy_pass http://localhost:8083;
    }   
}
```

重启 nginx

```
docker restart nginx
```

访问

```
https://www.rainsheep.cn:8086/test/hello.html
```
