title: flex布局
date: '2020-07-26 10:39:30'
updated: '2020-07-26 10:39:30'
tags: [前端]
permalink: /articles/2020/07/26/1595731170747.html
---
![](https://raw.githubusercontent.com/Rainsheep/pic-bed/master/img/2020-07-20+22:59:52+p_2020072022223122SS.gif)https://zhuanlan.zhihu.com/p/25303493
