title: Retrofit
date: '2021-03-08 11:13:39'
updated: '2021-03-08 11:13:39'
tags: [android]
permalink: /articles/2021/03/08/1615173219101.html
---
参考文献:

[你真的会用Retrofit2吗?Retrofit2完全教程](https://www.jianshu.com/p/308f3c54abdd/)
[官方文档](https://square.github.io/retrofit/)

