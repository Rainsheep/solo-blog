title: IDEA打包项目
date: '2019-12-04 14:23:40'
updated: '2019-12-04 14:23:40'
tags: [软件教程]
permalink: /articles/2019/12/04/1575440620790.html
---
# 打成 WAR 包：

1、打开项目结构，选择要打的 Artifacts

![20190502005353395.png](https://img.hacpai.com/file/2019/12/20190502005353395-c1f7828e.png)

2、
![2019050200551079.png](https://img.hacpai.com/file/2019/12/2019050200551079-607ea917.png)

3、
![20190502005714467.png](https://img.hacpai.com/file/2019/12/20190502005714467-5e02aafd.png)

4、成功，去路径下查看就行

# Maven 打包如下：

* 导出 war 包：

1）单击最左下角的选项按钮；
2）在右侧弹出的 maven projects 选项展开 Lifecycle/package,双击或点击上面的执行按钮，即可；
3）默认会把打好的 war 包放在在 target 目录下。

![20171024142026691.png](https://img.hacpai.com/file/2019/12/20171024142026691-7e47b6bc.png)

主意最好先使用 clean ---然后在进行 package 打包，先删除就文件重新生成 war 包；

防止修改了 XML 文件，而打完包之后未修改情况；

而后，将 war 包，放到相应的 Tomcat 下，就好。

# IDEA 导出 jar 包：

![20190502012736140.png](https://img.hacpai.com/file/2019/12/20190502012736140-2d1ea081.png)

![20190502012928872.png](https://img.hacpai.com/file/2019/12/20190502012928872-579fdf79.png)

![20190502013311752.png](https://img.hacpai.com/file/2019/12/20190502013311752-ef0c3c2d.png)

最后构建即可

[https://blog.csdn.net/lazybones_3/article/details/86626056](https://blog.csdn.net/lazybones_3/article/details/86626056)
