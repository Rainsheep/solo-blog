title: Android 学习笔记
date: '2021-01-06 18:59:23'
updated: '2021-01-06 19:32:17'
tags: [android]
permalink: /articles/2021/01/06/1609930763440.html
---
# 1. 基础

## 1.1 Android 体系结构

分为四层：

* Linux kernal，linux 内核
* libraries，c/c++ 的开源库
* application framework，应用框架层，用 java 对 libraries 进行了封装
* application，应用层

![体系结构](https://b3logfile.com/file/2021/01/untitled-dc9da4cf.png)

## 1.2 安卓虚拟机

### 1.2.1 dalvik vm

安卓使用的：dalvik vm

jvm：`.java -> .class -> .jar`，基于栈的架构，栈在内存中

dalvik vm：`.java -> .class -> .dex -> .odex`，基于寄存器的架构，寄存器在 CPU 中

java 开发工具包为 jdk

android 开发工具包为 sdk

![image.png](https://b3logfile.com/file/2021/01/image-f8ce1045.png)

### 1.2.2 ART

art(android runtime)，从安卓 5.0 开始使用的虚拟机。为了解决流畅性问题。

art 在安装应用的时候，把字节码翻译成机器码，安装之后所占用空间变大(空间换时间)。

dalvik ：一般翻译一遍执行，运行慢。

## 1.3 目录结构

参考：[Android项目目录结构模板以及简单说明【简单版】](https://www.cnblogs.com/whycxb/p/9739148.html)

![1.png](https://b3logfile.com/file/2021/01/1-bad9286a.png)
![2.png](https://b3logfile.com/file/2021/01/2-b899bff0.png)
![3.png](https://b3logfile.com/file/2021/01/3-96ae7647.png)
![4.png](https://b3logfile.com/file/2021/01/4-3cd6acbd.png)
![5.png](https://b3logfile.com/file/2021/01/5-662c2816.png)

`app/src/main/assets` ：静态资源，里面的代码不会被编译。

`app/src/main/java/包名/activity`：BaseActivity 和与项目业务无关的 activity（比如WelcomeActivity）放到包的根目录下，其他与项目业务相关的 activity 放到新建的以业务名称命名的子包目录下，如果项目比较简单，那么就统一放到 normal 包下即可。

`app/src/main/java/包名/adapter`：适配器类集合

`app/src/main/java/包名/bean`：实体类集合

`app/src/main/java/包名/dialog`：BaseDialogFragment 放到包的根目录下，其他与项目业务相关的 dialog 放到新建的以业务名称命名的子包目录下，如果项目比较简单，那么就统一放到 normal 目录下即可。

`app/src/main/java/包名/enumtype`：枚举类集合

`app/src/main/java/包名/fragment`：BaseFragment 放到包的根目录下，其他与项目业务相关的 fragment 放到新建的以业务名称命名的子包目录下，如果项目比较简单，那么就统一放到 normal 目录下即可。

`app/src/main/java/包名/listener`：监听器类集合

`app/src/main/java/包名/mvp`：mvp 模式的根目录

`app/src/main/java/包名/mvp/iview`：mvp 模式中的 V

`app/src/main/java/包名/mvp/model`：mvp 模式中的 M

`app/src/main/java/包名/presenter`：mvp 模式中的 P

`app/src/main/java/包名/utils`：常用工具类集合（注意，区别 base 中的 utils 目录，这里是仅在 app 中用到的工具类，不是通用工具类集合，通用工具类集合在 `base/utils` 目录中）

`app/src/main/java/包名/views`：自定义 view 集合（注意，区别 base 中的 views 目录，这里是仅在 app 中用到的自定义 view，不是通用自定义 view 集合，通用自定义 view 集合在 base/views 目录中）

`app/src/main/java/包名/MyApplication.java`：项目声明的自定义 Application 类（注意：项目中所有需要在自定义 Application 中声明的方法，比如引入第三方平台时一些配置，都需要写在这里，而不是 base 中的 BaseApplication 或者 thirdlib 中的 ThirdApplication 中）

`app/src/main/res`：就不需要多说了，需要注意，drawable-hdpi、mdpi、xhdpi、xxhdpi、xxxhdpi 目录需要自己创建，新建项目后没有的目录或者文件，可以从这里复制过去，当然了，自己新建目录或者文件即可。

`app/src/main/res/drawable`：图片

`app/src/main/res/layout`：布局文件

`app/src/main/res/values/dimens.xml`：尺寸声明

`app/src/main/res/values/string.xml`：项目中用到的字符串

`app/src/main/res/values/styles.xml`：项目用到的主题和样式

`app/src/main/res/AndroidManifest.xml`：清单文件

`app/src/build.gradle`：只需要引用其他 module 即可。

`app/src/proguad-rules.pro`：代码混淆配置。注意：项目中所有的代码混淆配置都写在这里，不要分开在 base 或者 thirdlib 中写。

`base`：其他module都可以引用base这个module

`base/src/main/java/包名/dialog`：通用对话框集合（比如确认取消对话框等）

`base/src/main/java/包名/utils`：通用工具类集合

`base/src/main/java/包名/views`：通用自定义 view 集合

`base/src/main/java/包名/dialog`：Application 基类，主要用于不同 module 中应用 ApplicationContext 对象。

`thirdlib`：第三方平台sdk集合

`thirdlib/libs`：第三方平台 sdk 中 jar、arr 文件集合

`thirdlib/src/main/java/包名/ThirdApplication.java`：没有什么用，主要是为了以后新建子包方便。

**R.java 介绍**

此类在新版本中已经取消，找不到其位置，不过很重要。

res 目录下保存的文件大多数都会被编译，并且都会被赋予资源ID，这些资源ID被保存在 R.java 文件中。这样我们就可以在程序中通过 ID 来访问 res 类的资源。

R 类默认有 attr、drawable、layout、string 等四个静态内部类，每个静态内部类分别对应着一种资源，如layout静态内部类对应layout中的界面文件，其中每个静态内部类中的静态常量分别定义一条资源标识符，如 `public static final int main=0x7f030000;` 对应的是 layout 目录下的 `main.xml` 文件。

即当开发者在 res 目录中任何一个子目录中添加相应类型的文件之后，ADT 会在 R.java 文件中相应的内部类中 自动生成一条静态int类型的常量，对添加的文件进行索引。如果在 layout 目录下再添加一个新的界面，那么在 `public static final class layout` 中也会添加相应的静态 int 常量。相反当我们在 res 目录下删除任何一个文件，其在 R.java 中对应的记录会被 ADT 自动删除。

R.java 文件按除了有自动标示资源的索引功能之外，还有另外一个主要的功能，如果 res 目录中的某个资源在应用中没有被使用到，在该应用被编译的时候系统就不会把对应的资源编译到该应用的 APK 包中，这样可以节省 Android 手机的资源。

在 java 程序中引用R类资源：`R.resource_type.resource_name`

在 XML 文件中引用 R 资源 ID：`@[package:]type/name`

在 XML 文件中向 R 类添加资源 ID：`@+id/string_name`

## 1.4 Android 打包过程

![package](https://b3logfile.com/file/2021/01/image-b1bd9221.png)

标志一个 android 项目的唯一性

* 项目的包名
* 项目的签名

## 1.5 ADB

android debug bridge 安卓调试桥

`adb start-server`：开启 adb 服务

`adb kill-server`：杀死 adb 服务

`adb uninstall + 包名`：卸载应用

`adb install + apk 所在路径`：安装应用

`adb push 本地地址 sdcard/`：上传到手机

`adb pull 地址`：从手机拉下来

`adb shell`：进入设备的命令行

## 1.6 案例：电话拨号器

```
// 容器的宽高
android:layout_width="wrap_content"
android:layout_height="wrap_content"

wrap_content：包裹内容
fill_parent：充满父容器，过时
match_parent：充满父容器
```

View 是所有控件的父类。

点击事件写法：

* `button.setOnClickListener`
* `android:onClick=""`

## 1.7 布局

**线性布局**

LinearLayout

```
// 布局方向
android:orientation="vertical"
android:orientation="horizontal"
```

**相对布局**

RelativeLayout

可以相对于某一控件或者父容器对齐

所有控件从左上角开始

```
// 在 textview1 控件下方
android:layout_below="@id/textview1"
// 右方
android:layout_toRightOf="@id/textview1"
// 底部对齐
android:layout_alignBottom="@id/textview1"
// 在父容器中间
android:layout_centerInParent="true"
// 水平居中
android:layout_centerHorizontal="true"
```

**帧布局**

FrameLayout

只能放在(top,center,bottom)*(left,center,right) 9 个位置

```
// 指定控件的对齐方式
android:layout_gravity="bottom"
android:layout_gravity="center_vertical"
// 垂直居中并靠右
android:layout_gravity="center_vertical|right"
```

**表格布局**

TableLayout 不常用，类似于竖直方向的线性布局

`<TableRow>` ：声明控件在一行

**网格布局**

GridLayout

使用虚细线将布局划分为行、列和单元格，也支持一个控件在行、列上都有交错排列。

```
// 排列方式
android:orientation="vertical/horizontal"
// 对齐方式
android:gravity="center/left/right/bottom"
// 布局的行列数
android:rowCount="4"
android:columnCount="4"
// 组件起始行列
android:layout_row="1"
android:layout_column="2"
// 组件跨越行列数
android:layout_rowSpan="2"
android:layout_columnSpan="3"
```

**绝对布局**

AbsoluteLayout 已过时



