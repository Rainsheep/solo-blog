title: HandlerThread
date: '2021-06-22 13:58:23'
updated: '2021-06-22 13:58:23'
tags: [android]
permalink: /articles/2021/06/22/1624341503268.html
---
参考文献：[Android多线程(HandlerThread篇)](https://blog.csdn.net/qijinglai/article/details/80735718)

## 1. 简介

HandlerThread 有那些特点：

* HandlerThread 本质上是一个线程类，它继承了 Thread；
* HandlerThread 有自己的内部 Looper 对象，可以进行 looper 循环；
* 通过获取 HandlerThread 的 looper 对象传递给 Handler 对象，**可以在 handleMessage 方法中执行异步任务；**
* 创建 HandlerThread 后必须先调用 HandlerThread.start() 方法，Thread 会先调用 run 方法，创建 Looper 对象。

## 2. 基础使用

1. 创建实例对象
   
   ```java
   // 传入参数的作用主要是标记当前线程的名字，可以任意字符串。
   HandlerThread handlerThread = new HandlerThread("downloadImage");
   ```
2. 启动线程
   
   ```java
   //必须先开启线程
   handlerThread.start();
   ```
3. 构建异步 handler
   
   ```java
   handler = new Handler(mCheckMsgThread.getLooper())
   {
       @Override
       public void handleMessage(Message msg) {
       }
   };
   ```
   
   此时，此 handleMessage 是在子线程执行的

## 3. 例子

```java
public class MainActivity extends AppCompatActivity {

    private TextView mTvServiceInfo;
    private HandlerThread mCheckMsgThread;
    private Handler mCheckMsgHandler;
    private boolean isUpdateInfo;

    private static final int MSG_UPDATE_INFO = 0x110;

    //与UI线程管理的handler
    private Handler mHandler = new Handler();

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //创建后台线程
        initBackThread();

        mTvServiceInfo = (TextView) findViewById(R.id.id_textview);

    }

    @Override
    protected void onResume()
    {
        super.onResume();
        //开始查询
        isUpdateInfo = true;
        mCheckMsgHandler.sendEmptyMessage(MSG_UPDATE_INFO);
    }

    @Override
    protected void onPause()
    {
        super.onPause();
        //停止查询
        isUpdateInfo = false;
        mCheckMsgHandler.removeMessages(MSG_UPDATE_INFO);

    }

    private void initBackThread()
    {
        mCheckMsgThread = new HandlerThread("check-message-coming");
        mCheckMsgThread.start();
        mCheckMsgHandler = new Handler(mCheckMsgThread.getLooper())
        {
            @Override
            public void handleMessage(Message msg)
            {
                checkForUpdate();
                if (isUpdateInfo)
                {
                    mCheckMsgHandler.sendEmptyMessageDelayed(MSG_UPDATE_INFO, 1000);
                }
            }
        };


    }

    /**
     * 模拟从服务器解析数据
     */
    private void checkForUpdate()
    {
        try
        {
            //模拟耗时
            Thread.sleep(1000);
            mHandler.post(new Runnable()
            {
                @Override
                public void run()
                {
                    String result = "实时更新中，当前大盘指数：<font color='red'>%d</font>";
                    result = String.format(result, (int) (Math.random() * 3000 + 1000));
                    mTvServiceInfo.setText(Html.fromHtml(result));
                }
            });

        } catch (InterruptedException e)
        {
            e.printStackTrace();
        }

    }

    @Override
    protected void onDestroy()
    {
        super.onDestroy();
        //释放资源
        mCheckMsgThread.quit();
    }
}
```



