title: Java中List, Integer[], int[]的相互转换
date: '2019-12-04 14:55:59'
updated: '2020-02-15 19:44:58'
tags: [Java, 知识点总结]
permalink: /articles/2019/12/04/1575442558951.html
---
有时候 list<Integer>和数组 int[]转换很麻烦。

List<String>和 String[]也同理。难道每次非得写一个循环遍历吗？其实一步就可以搞定。

本文涉及到一些 Java8 的特性。如果没有接触过就先学会怎么用，然后再细细研究。

```java
package package1;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Main {
    public static void main(String[] args) {
        int[] arr = {1, 2, 3, 4, 5};

        // int[] 转 List<Integer>
        List<Integer> list1 = Arrays.stream(arr).boxed().collect(Collectors.toList());
        //1.调用Arrays.stream()将int[]变为IntStream流,注意不能用Stream.of(),Stream.of()只适用于对象数组
        //2.使用IntStream中的boxed()装箱。将IntStream转换成Stream<Integer>。
        //3.使用Stream的collect()，将Stream<T>转换成List<T>，因此正是List<Integer>。

        // int[] 转 Integer[]
        Integer[] arr2 = Arrays.stream(arr).boxed().toArray(Integer[]::new);
        // 1.前两步同上，此时是Stream<Integer>。
        // 2.然后使用Stream的toArray，引用Integer[]的new方法。
        // 3.这样就可以返回Integer数组,不然默认是Object[]。

        // List<Integer> 转 Integer[]
        Integer[] arr3 = list1.toArray(new Integer[list1.size()]);
        // 1. 调用toArray。传入参数T[] a。这种用法是目前推荐的。
        // List<String>转String[]也同理。
        //当arr1能放入参数数组中的时候则放入并返回地址，放不下的话则会创建新的数组，并返回新数组的地址

        // List<Integer> 转 int[]
        int[] arr4 = list1.stream().mapToInt(Integer::intValue).toArray();
        // 1.想要转换成int[]类型，就得先转成IntStream。
        // 2.这里就通过mapToInt()把Stream<Integer>调用Integer::intValue来转成IntStream
        // 3.而IntStream中默认toArray()转成int[]。


        // Integer[] 转 int[]
        int[] arr5 = Stream.of(arr2).mapToInt(Integer::intValue).toArray();
        // 思路同上。先将Integer[]转成Stream<Integer>，再转成IntStream。

        // Integer[] 转 List<Integer>
        List<Integer> list6 = Arrays.asList(arr2);
        // 最简单的方式。String[]转List<String>也同理。
        //但是此方法返回的List是固定大小的，长度无法再改变，无法添加元素

        // Integer[] 转 List<Integer>
        List<Integer> list7 = Stream.of(arr2).collect(Collectors.toList());
        //先获取Integer[]的Stream<Integer>流，然后使用collect来收集流中元素
        //其中Collectors.toList()返回一个List的Collector
    }
}
```
