title: systemed 进程守护
date: '2020-08-17 23:37:09'
updated: '2020-08-18 00:06:31'
tags: [Linux]
permalink: /articles/2020/08/17/1597678629939.html
---
参考文献：

[CentOS7使用systemctl添加自定义服务](https://www.jianshu.com/p/79059b06a121)

[史上最全的 Systemd 服务管理中文教程](https://www.hi-linux.com/posts/55818.html)

[systemctl自定义systemd.service服务设置守护进程](https://blog.csdn.net/comprel/article/details/82750288)

[Linux06-服务、守护进程和systemd](https://www.codenong.com/cs106958003/)

### 1. 简介

Centos7开机第一个程序从init完全换成了systemd这种启动方式，同centos 5 6已经是实质差别。systemd是靠管理unit的方式来控制开机服务，开机级别等功能。

在 `/usr/lib/systemd/system` 目录下包含了各种 unit 文件，有 **.service** 后缀的服务unit，有 **.target** 后缀的开机级别 unit 等，这里介绍关于 .service 后缀的文件。因为 systemd 在开机要想执行自启动，都是通过这些 **.service** 的unit控制的。

`/usr/lib/systemd/system/` (软件包安装的单元)

`/etc/systemd/system/`(系统管理员安装的单元, 优先级更高)

### 2. 实例

以 cloudreve 进程为例

```
# 编辑配置文件
vim /usr/lib/systemd/system/cloudreve.service
```

将下文 `PATH_TO_CLOUDREVE` 更换为程序所在目录：

```
[Unit]
# 当前服务的简单描述
Description=Cloudreve
# 在 network.target 之后启动
After=network.target
# 表示弱依赖关系，network.target 启动失败也不影响继续执行
Wants=network.target

[Service]
# 可选，指定服务的工作目录，一般不带
WorkingDirectory=/PATH_TO_CLOUDREVE
# 启动当前服务的命令
ExecStart=/PATH_TO_CLOUDREVE/cloudreve
# 非正常退出时（退出状态码非0），包括被信号终止和超时，才会重启
Restart=on-failure
# 重启服务前等待的秒数
RestartSec=5s

[Install]
WantedBy=multi-user.target
```

```
# 更新配置
systemctl daemon-reload

# 启动服务
systemctl start cloudreve

# 设置开机启动
systemctl enable cloudreve
```

管理命令：

```
# 启动服务
systemctl start cloudreve

# 停止服务
systemctl stop cloudreve

# 重启服务
systemctl restart cloudreve

# 查看状态
systemctl status cloudreve
```

### 3. 解释

1. [Unit]
   主要是对这个服务的说明，内容， 文档介绍以及对一些依赖服务定义
2. [Service]
   服务的主体定义，主要定义服务的一些运行参数，及操作动作
3. [Install]
   服务安装的相关设置，一般可设置为多用户的

### 4. Unit 段

* Description：描述这个 Unit 文件的信息
* Documentation：指定服务的文档，可以是一个或多个文档的 URL 路径
* Requires：依赖的其它 Unit 列表，列在其中的 Unit 模板会在这个服务启动时的同时被启动。并且，如果其中任意一个服务启动失败，这个服务也会被终止
* Wants：与 Requires 相似，但只是在被配置的这个 Unit 启动时，触发启动列出的每个 Unit 模块，而不去考虑这些模板启动是否成功
* After：与 Requires 相似，但是在后面列出的所有模块全部启动完成以后，才会启动当前的服务
* Before：与 After 相反，在启动指定的任务一个模块之间，都会首先确证当前服务已经运行
* Binds To：与 Requires 相似，失败时失败，成功时成功，但是在这些模板中有任意一个出现意外结束或重启时，这个服务也会跟着终止或重启
* Part Of：一个 Bind To 作用的子集，仅在列出的任务模块失败或重启时，终止或重启当前服务，而不会随列出模板的启动而启动
* OnFailure：当这个模板启动失败时，就会自动启动列出的每个模块
* Conflicts：与这个模块有冲突的模块，如果列出的模块中有已经在运行的，这个服务就不能启动，反之亦然

### 5. Service 段

用来 Service 的配置，只有 Service 类型的 Unit 才有这个区块。它的主要字段分为**服务生命周期**和**服务上下文**配置两个方面。

1. **服务生命周期控制相关**

* Type：定义启动时的进程行为，它有以下几种值：
  * Type=simple：默认值，执行ExecStart指定的命令，启动主进程
  * Type=forking：以 fork 方式从父进程创建子进程，创建后父进程会立即退出
  * Type=oneshot：一次性进程，Systemd 会等当前服务退出，再继续往下执行
  * Type=dbus：当前服务通过D-Bus启动
  * Type=notify：当前服务启动完毕，会通知Systemd，再继续往下执行
  * Type=idle：若有其他任务执行完毕，当前服务才会运行
* RemainAfterExit：值为 true 或 false（默认）。当配置为 true 时，Systemd 只会负责启动服务进程，之后即便服务进程退出了，Systemd 也仍然会认为这个服务还在运行中。这个配置主要是提供给一些并非常驻内存，而是启动注册后立即退出，然后等待消息按需启动的特殊类型服务使用的。
* ExecStart：启动当前服务的命令
* ExecStartPre：启动当前服务之前执行的命令
* ExecStartPos：启动当前服务之后执行的命令
* ExecReload：重启当前服务时执行的命令
* ExecStop：停止当前服务时执行的命令
* ExecStopPost：停止当其服务之后执行的命令
* RestartSec：自动重启当前服务间隔的秒数
* Restart：定义何种情况 Systemd 会自动重启当前服务，可能的值包括 always（总是重启）、on-success、on-failure、on-abnormal、on-abort、on-watchdog，推荐设为on-failure，对于那些允许发生错误退出的服务，可以设为on-abnormal
* TimeoutStartSec：启动服务时等待的秒数，这一配置对于使用 Docker 容器而言显得尤为重要，因其第一次运行时可能需要下载镜像，严重延时会容易被 Systemd 误判为启动失败杀死。通常，对于这种服务，将此值指定为 0，从而关闭超时检测
* TimeoutStopSec：停止服务时的等待秒数，如果超过这个时间仍然没有停止，Systemd 会使用 SIGKILL 信号强行杀死服务的进程

2. **服务上下文配置相关**

* Environment：为服务指定环境变量
* EnvironmentFile：指定加载一个包含服务所需的环境变量的列表的文件，文件中的每一行都是一个环境变量的定义
* Nice：服务的进程优先级，值越小优先级越高，默认为 0。其中 -20 为最高优先级，19 为最低优先级
* WorkingDirectory：指定服务的工作目录
* RootDirectory：指定服务进程的根目录（/ 目录）。如果配置了这个参数，服务将无法访问指定目录以外的任何文件
* User：指定运行服务的用户
* Group：指定运行服务的用户组
* MountFlags：服务的 Mount Namespace 配置，会影响进程上下文中挂载点的信息，即服务是否会继承主机上已有挂载点，以及如果服务运行执行了挂载或卸载设备的操作，是否会真实地在主机上产生效果。可选值为 shared、slaved 或 private
  * shared：服务与主机共用一个 Mount Namespace，继承主机挂载点，且服务挂载或卸载设备会真实地反映到主机上
  * slave：服务使用独立的 Mount Namespace，它会继承主机挂载点，但服务对挂载点的操作只有在自己的 Namespace 内生效，不会反映到主机上
  * private：服务使用独立的 Mount Namespace，它在启动时没有任何任何挂载点，服务对挂载点的操作也不会反映到主机上
* LimitCPU / LimitSTACK / LimitNOFILE / LimitNPROC 等：限制特定服务的系统资源量，例如 CPU、程序堆栈、文件句柄数量、子进程数量等

> 注意：如果在 ExecStart、ExecStop 等属性中使用了 Linux 命令，则必须要写出完整的绝对路径。对于 ExecStartPre 和 ExecStartPost 辅助命令，若前面有个 “-” 符号，表示忽略这些命令的出错。因为有些 “辅助” 命令本来就不一定成功，比如尝试清空一个文件，但文件可能不存在。

### 6. Install 段

这部分配置的目标模块通常是特定运行目标的 .target 文件，用来使得服务在系统启动时自动运行。这个区段可以包含三种启动约束：

* WantedBy：和 Unit 段的 Wants 作用相似，只有后面列出的不是服务所依赖的模块，而是依赖当前服务的模块。它的值是一个或多个 Target，当前 Unit 激活时（enable）符号链接会放入 /etc/systemd/system 目录下面以 <Target 名> + .wants 后缀构成的子目录中，如 “/etc/systemd/system/multi-user.target.wants/“

```
# find /etc/systemd/system/* -type d
/etc/systemd/system/default.target.wants
/etc/systemd/system/getty.target.wants
/etc/systemd/system/graphical.target.wants
/etc/systemd/system/multi-user.target.wants
/etc/systemd/system/network-online.target.wants
/etc/systemd/system/paths.target.wants
/etc/systemd/system/shutdown.target.wants
/etc/systemd/system/sockets.target.wants
/etc/systemd/system/sysinit.target.wants
/etc/systemd/system/timers.target.wants
```

* RequiredBy：和 Unit 段的 Wants 作用相似，只有后面列出的不是服务所依赖的模块，而是依赖当前服务的模块。它的值是一个或多个 Target，当前 Unit 激活时，符号链接会放入 /etc/systemd/system 目录下面以 <Target 名> + .required 后缀构成的子目录中
* Also：当前 Unit enable/disable 时，同时 enable/disable 的其他 Unit
* Alias：当前 Unit 可用于启动的别名

### 7. Unit 管理

```
# 设置开机启动,先开机重启，再启动
systemctl enable apache

# 设置开机不启动
systemctl disable apache

# 立即启动一个服务
systemctl start apache

# 显示单个 Unit 的状态
systemctl status apache

# 立即停止一个服务
systemctl stop apache

# 重启一个服务
systemctl restart apache

# 杀死一个服务的所有子进程
systemctl kill apache

# 重新加载一个服务的配置文件
systemctl reload apache

# 重载所有修改过的配置文件
systemctl daemon-reload
```

status 的几种状态

loaded 系统服务已经初始化完成，加载过配置
actvie(running) 正常运行
actvie(exited) 正常结束的服务
active(waitting) 正在执行当中， 等待其他的事件才继续处理
inactive 服务关闭
enabled 服务开机启动
disabled 服务开机不自启
static 服务开机启动项不可被管理
falied 系统配置错误
