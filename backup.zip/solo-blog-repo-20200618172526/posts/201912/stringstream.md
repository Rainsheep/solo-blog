title: ' stringstream'
date: '2019-12-04 12:02:18'
updated: '2019-12-04 12:02:18'
tags: [知识点总结]
permalink: /articles/2019/12/04/1575432137997.html
---
# stringstream的基本操作
```cpp
#include<bits/stdc++.h>
using namespace std;
int main() {
	string s = "123";
	stringstream ss(s);//s作为初值
	string t = ss.str();
	//ss.str()返回一个临时的string，函数执行完以后将被析构
	//不能用此临时string进行别的操作，可以先将这个值赋值给别的string再进行操作
	//此值可以直接赋值或者直接输出
	cout << t << endl;
}
```

# stringstream经常用来类型转换
```cpp
#include<bits/stdc++.h>
using namespace std;
int main() {
	//string转int
	stringstream ss;
	string s="123";
	int x;
	ss << s;
	ss >> x;
	cout << x << endl;
}
```
```cpp
#include<bits/stdc++.h>
using namespace std;
int main() {
	//int到string
	stringstream ss;
	string s;
	int x=123;
	ss << x;
	ss >> s;
	cout << s << endl;
}
```

# stringstream用来分割字符，可以分割空格，回车，tab隔开的
```cpp
#include<bits/stdc++.h>
using namespace std;
int main() {
	//int到string
	stringstream ss;
	string s;
	getline(cin, s);
	ss << s;
	string t;
	while (ss >> t) {
		cout << t << endl;
	}
}
```

# string不能重用，重用时需要用clear清空缓存，不清空将会出错
```cpp
#include<bits/stdc++.h>
using namespace std;
int main() {
	stringstream ss;
	string s="123";
	int x;
	ss << s;
	ss >> x;
	cout << x << endl << endl;
 
	ss.clear();
 
	bool b = true;
	ss << b;
	ss >> x;
	cout << x;
}
```

# ss.clear()和ss.str("")的区别

ss.clear()可以清空缓存，重用的时候使用，不能清空内存，会导致内存越来越大
ss.str("")用来清空内存

