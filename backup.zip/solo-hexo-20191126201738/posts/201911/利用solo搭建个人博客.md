title: 利用solo搭建个人博客
date: '2019-11-26 19:40:48'
updated: '2019-11-26 19:41:06'
tags: [待分类]
permalink: /articles/2019/11/26/1574768448759.html
---
<details>
	<summary>参考链接</summary>
	<a href="https://hacpai.com/article/1565021959471">从零开始安装 solo 博客</a><br>
	<a href="https://github.com/b3log/solo">solo github</a>
</details>

***
# 搭建前提
* 购买服务器
* 购买域名（可不买）
* 域名解析与备案
* 为服务器安装系统
# 安装docker
>我的系统，Centos7.3

```shell
#使用yum更新仓库
yum update

#安装docker
yum -y install docker

#启动 Docker 后台服务
service docker start

#测试运行 hello-world
docker run hello-world
```
>出现 hello world 就证明安装正常了
# 安装mysql
>版本随意，我这里选择的 5.6，你可以选择更高版本的，这个没关系，不影响使用
```java
public class HelloWorld {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }

}
```





