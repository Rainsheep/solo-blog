title: editorconfig
date: '2020-12-16 21:53:36'
updated: '2020-12-16 21:53:36'
tags: [规范]
permalink: /articles/2020/12/16/1608126816359.html
---
[官方文档](https://github.com/editorconfig/editorconfig/wiki)

文件名：`.editorconfig`

模板

```
root=true                           # 根目录的配置文件，编辑器会由当前目录向上查找

[*]    # 匹配所有的文件
charset = utf-8                     # 文件编码是 utf-8
end_of_line = lf                    # 文件换行符
trim_trailing_whitespace = true     # 不保留行末的空格
insert_final_newline = true         # 文件末尾添加一个空行
indent_style = space                # 空格缩进
indent_size = 2                     # 缩进空格为2个

// max_line_length = 20
```



