title: zzuli 2129 DOBRI
date: '2019-12-03 12:15:02'
updated: '2019-12-03 12:15:02'
tags: [acm, 水题]
permalink: /articles/2019/12/03/1575346502036.html
---
# 题目描述

给出一个包含 N 个整数的序列 A，定义这个序列 A 的前缀和数组为 SUM 数组 ，当 SUM 数组中的第 i 个元素等于在 i 前面的三个元素的和，那么第 i 个元素就称为 GOOD。 那么这个 SUM 数组中包含多少个 GOOD 元素?

# 输入

第一行整数 T 表示数据组数（1&lt;=T&lt;=10)
每组数据以下格式：
输入的第一行包含一个整数 N (1&lt;=N&lt;=100000), 表示序列 A 的长度。
输入的第二行包含 N 个用空格隔开的整数，表示序列 A (-100000&lt;=Ai&lt;=100000).

# 输出

每组数据输出仅一行，输出这个 SUM 数组中包含多少个 GOOD 元素。

# 样例输入

3
4
1 1 1 3
4
1 2 3 10
6
5 -2 -3 1 3 3

# 样例输出

1
0
1

# 题解

一道水题，然而没一开始读懂题意，错了，注意 sum 数组并不是 A 序列，而是 A 序列中 1 到当前项的和，既序列 A 的前缀和概念

```c++
#include<iostream>
using namespace std;
int main()
{
    int t,n,s[100005],i,sum;
    cin>>t;
    while(t--)
     {
        cin>>n;
        sum=0;
        for(i=0;i<n;i++)
        cin>>s[i];
        for(i=1;i<n;i++)
        s[i]=s[i]+s[i-1];
        if(n<4)cout<<"0"<<endl;
        else
        {
            for(i=3;i<n;i++)
            if(s[i]==s[i-1]+s[i-2]+s[i-3])sum++;
            cout<<sum<<endl;
         }
          
     }
     return 0;
}

```
