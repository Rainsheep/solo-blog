title: mac 安装 brew
date: '2020-09-14 22:39:21'
updated: '2020-09-14 22:40:44'
tags: [mac]
permalink: /articles/2020/09/14/1600094361638.html
---
* mac 安装 brew 速度很慢，下面手动安装
* 复制 [https://raw.githubusercontent.com/Homebrew/install/master/install.sh](https://links.jianshu.com/go?to=https%3A%2F%2Fraw.githubusercontent.com%2FHomebrew%2Finstall%2Fmaster%2Finstall.sh) 内容，保存为 install.sh
* 搜索 `BREW_REPO="https://github.com/Homebrew/brew"` 替换为 `BREW_REPO="https://mirrors.ustc.edu.cn/brew.git"`
* ```bash
  /bin/bash /home/rainsheep/Desktop/install.sh
  cd /usr/local/Homebrew/Library/Taps/homebrew (如果没有homebrew,新建homebrew文件夹)
  git clone https://mirrors.tuna.tsinghua.edu.cn/git/homebrew/homebrew-core.git
  ```
* 把homebrew repo切换为清华镜像

  ```bash
  cd "$(brew --repo)"
  git remote set-url origin https://mirrors.tuna.tsinghua.edu.cn/git/homebrew/brew.git
  cd "$(brew --repo)/Library/Taps/homebrew/homebrew-core"
  git remote set-url origin https://mirrors.tuna.tsinghua.edu.cn/git/homebrew/homebrew-core.git
  brew update
  ```
* PS:如果有报错：curl: (7) Failed to connect to raw.githubusercontent.com port 443: Connection refused，可以通过这个命令解决：`sudo gem install redis`
