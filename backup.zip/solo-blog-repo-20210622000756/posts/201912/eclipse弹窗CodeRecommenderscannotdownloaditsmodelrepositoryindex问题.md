title: eclipse弹窗Code Recommenders cannot download its model repository index问题
date: '2019-12-26 15:58:14'
updated: '2019-12-26 16:17:12'
tags: [软件教程]
permalink: /articles/2019/12/26/1577347094403.html
---
<details>
	<summary>参考链接</summary>
	<a href="https://blog.csdn.net/Alone_in_/article/details/102821527">Eclipse弹出Code Recommenders cannot download its model repository index</a>
</details><br>

---

> eclipse 版本：Photon Release (4.8.0) Build id: 20180619-1200 即 photon 最终版
> 时间：2019 年 12 月 26 日
问题描述：刚装完 eclipse，输入快捷键 sout 的时候弹出此错误 Code Recommenders cannot download its model repository index，如图
![20191030161528184.png](https://img.hacpai.com/file/2019/12/20191030161528184-6511cf9a.png)

解决方法：网上大部分的方法都是 Window→ Preferences→ General→ Network Connections 把网络代理默认的 Native 改为 Manual 就可以了，经测试，此方法无效！

再次搜索，得到答案原因是这个项目的 model 获取地址现在被移除了，而且已经很久没有更新了。
正确的解决方法：
Window→ Preferences→ Code Recommenders→ Models 箭头将旧地址 remove 掉，如图
![2019121609323459.png](https://img.hacpai.com/file/2019/12/2019121609323459-136fbea3.png)

> 别人的图，为 oxygen 版本，所以链接结尾是 oxygen，我的版本链接最后为 photon
