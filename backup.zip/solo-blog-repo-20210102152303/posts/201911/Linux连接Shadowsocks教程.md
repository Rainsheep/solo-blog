title: Linux连接Shadowsocks教程
date: '2019-11-27 14:01:27'
updated: '2019-11-27 14:01:27'
tags: [Linux, Shadowsocks, ss]
permalink: /articles/2019/11/27/1574834487620.html
---
<details>
	<summary>参考链接</summary>
	<a href="https://www.ubuntukylin.com/ukylin/forum.php?mod=viewthread&tid=188059">如何让ss客户端支持aes-256-gcm加密方式</a><br>
	<a href="https://blog.csdn.net/qq_31396185/article/details/81179492">ss安装时，加密方式为chacha20时，libsodium安装</a><br>
	<a href="https://blog.csdn.net/hl449006540/article/details/79697066?utm_source=blogxgwz2">Ubuntu 终端使用ss代理</a><br>
	<a href="https://blog.csdn.net/Jesse_Mx/article/details/52863204">Ubuntu系统下浏览器和终端的SS代理配置</a><br>
	<a href="http://yluo.name/2019/01/24/terminal_via_ss/">Ubuntu下Shadowsocks代理及终端使用ss</a><br>
	<a href="https://blog.huihut.com/2017/08/25/LinuxInstallConfigShadowsocksClient">Linux安装配置Shadowsocks客户端及开机自动启动</a>
</details>

# 前言
>时间：2019/11/14
>系统：ubuntu 16.04 LTS

>本文插图可能较少，见谅
>ubuntu使用ss两种方式，shadowsocks-qt5(图形化界面方式)，shadowsocks终端方式。

>网上的大部分教程都是2.0版本(加密方式较少，无法使用aes-256-gcm)，因本人ss使用aes-256-gcm方式，所以需使用3.0版本，3.0版本没有图形化界面，只有shadowsocks终端方式。

# 下载shadowsocks
>此命令需要pip，自行安装

`pip install https://github.com/shadowsocks/shadowsocks/archive/master.zip -U`
防止文件删除，挂上[蓝奏云链接](https://www.lanzous.com/i7d0mli)

# 新建配置文件
> 新建本地文件，我的目录是/home/yuyang/shadowsocks.json,配置文本
```json
{
    "server":"代理服务器地址",
    "server_port":代理服务器端口,
    "local_address":"127.0.0.1",	#本地地址
    "local_port":1080, 		#本地端口可以修改为别的，只要别和自己的应用或服务端口冲突
    "password":"代理服务密码",
    "timeout":600,	#超时时长限制
    "method":"aes-256-gcm"		#加密方式，很多种，自选
}
```
# 启动服务
>注意改目录

`sslocal -c /home/yuyang/shadowsocks.json start`

# 安装libsodium
>如果出现错误load libsodium failes with path None错误，安装libsodium(支持chacha20加密)
>注意，此处必须切换到root用户进行安装

```shell
//centos
yum -y groupinstall "Development Tools"
wget https://github.com/jedisct1/libsodium/releases/download/1.0.11/libsodium-1.0.11.tar.gz
tar xf libsodium-1.0.11.tar.gz && cd libsodium-1.0.11
./configure && make -j2 && make install
echo /usr/local/lib > /etc/ld.so.conf.d/usr_local_lib.conf
ldconfig
 
//ubuntu/debian
apt-get install build-essential
wget https://github.com/jedisct1/libsodium/releases/download/1.0.11/libsodium-1.0.11.tar.gz
tar xf libsodium-1.0.11.tar.gz && cd libsodium-1.0.11
./configure && make -j2 && make install
ldconfig
```
 现在输入上面的启动服务命令，没有错误，进程运行，此时浏览器安装SwitchyOmega插件设置代理127.0.0.1 1080即可访问谷歌，设置为PAC模式，不影响网速。

这个终端窗口即为后台进程，不能关闭，下面有自启教程。

# 终端翻墙教程
* 安装proxychains(将http映射成socks5)
`sudo apt install proxychains`
* 编辑配置文件
`sudo vi /etc/proxychains.conf`
* 最后一行为socks4修改为下列行，否则添加
`socks5 127.0.0.1 1080`
* 注销重新登录，在命令前加上proxychains即可终端翻墙
`proxychains curl ip.sb`
* 出现服务器ip，成功。
>据说上面的一大堆对git没用，不知道真的假的，git换源吧
>有需要参考[Ubuntu系统下浏览器和终端的SS代理配置](https://blog.csdn.net/Jesse_Mx/article/details/52863204)

# 设置开机自启
使用Systemd来实现shadowsocks开机自启。本人使用root用户进行操作。
使用下列命令查询sslocal命令路径
`which sslocal`
![/usr/local/bin/sslocal](https://img-blog.csdnimg.cn/20191114183458815.png)

`sudo gedit /etc/systemd/system/shadowsocks.service`
在里面填写如下内容：注意修改两个路径
```
[Unit]
Description=Shadowsocks Client Service
After=network.target
 
[Service]
Type=simple
User=root
ExecStart=/usr/local/bin/sslocal -c /home/yuyang/shadowsocks.json
 
[Install]
WantedBy=multi-user.target
```
配置生效：
`systemctl enable /etc/systemd/system/shadowsocks.service`
重启即可。

# 安装chrome
参考[解决ubuntu系统root用户下Chrome无法启动问题](https://blog.csdn.net/github_38358734/article/details/81738757)
注意，root用户需要加的是" --no-snadbox",两个-，教程中一个
![](https://img-blog.csdnimg.cn/20191114200031698.png)

# SwitchyOmega安装教程
谷歌访问助手

链接：https://pan.baidu.com/s/1gUxOLoMKQQL4kE3KsQz8Yw   
提取码：a8q0 

直接拖入扩展安装，然后进入谷歌商店，搜索SwitchyOmega
![](https://img-blog.csdnimg.cn/20191114202013866.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3kyMDE2MTk4MTk=,size_16,color_FFFFFF,t_70)

安装，导入下面配置即可，或者自行百度

链接：https://pan.baidu.com/s/154g9Wss8TNEI7XOBIgEjsA   
提取码：yw2g   
 

记得选自动切换模式
