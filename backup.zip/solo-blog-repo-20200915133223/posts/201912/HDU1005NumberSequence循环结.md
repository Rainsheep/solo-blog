title: HDU-1005 Number Sequence 循环结
date: '2019-12-03 12:28:55'
updated: '2019-12-03 12:28:55'
tags: [acm, 模拟]
permalink: /articles/2019/12/03/1575347335905.html
---
一开始的思路是遇到11就开始循环，后来发现，发现当A=5555，B=666666时数列是1142142142142，这种情况不是以11开始循环的，依然超时就罢了，关按11判断的话就错了。因为两个结果都一定是0到6之间的数，所以一定会循环，而且循环节不会超过7*7=49。（因为前面2个数若相同，则第三个之后的数必相同，而在49内必能找到2个相邻的数在前面出现过）。

题目链接：[HDU-1005](http://acm.hdu.edu.cn/showproblem.php?pid=1005)
```c++
#include<stdio.h>
int main()
{
    int i,a,b,m,n,l,f[50];
    while(~scanf("%d %d %d",&a,&b,&n)&&n)
    {
        f[1]=f[2]=1;
        if(n<=2)f[n]=1;
        if(n>2)
        {
            while(n>49)
            {
                n=n-49;
            }
            for(i=3;i<=n;i++)
            {
                f[i]=(a*f[i-1]+b*f[i-2])%7;
            }
        } 
        printf("%d\n",f[n]);
    }
    return 0;
 } 

```
