title: hdu-1087 Super Jumping! Jumping! Jumping!
date: '2019-12-03 19:53:15'
updated: '2019-12-04 15:38:26'
tags: [DP, acm]
permalink: /articles/2019/12/03/1575373995139.html
---
题目链接：[hdu-1087](http://acm.hdu.edu.cn/showproblem.php?pid=1087)

题意：从起点到终点，走的值必须必前面走的值大，求到终点的时候走过的路上数字的最大和

思路：dp[i]存到当前点切以当前点为最后一步的最优解，1\~n 之间肯定有一个点是最后一个点，或者直接到终点，则依次把 1~n 当做最后一个点，求出最优解就行，最优解即为 dp[i]中最大的数，这是第一层循环，第二层循环就是 1\~i；把 j 当做 i 项前面的最后一项，求出最优的 dp[i]，从 n 个 dp[i]中选取最大的，即为最后的结果

```c++
#include<iostream>
#include<algorithm>
using namespace std;
int main()
{
	//dp[i]表示以i点为走过的最后一点的时候的最优解 
	int n, i, j, k, t, l, m, dp[1005], max1, s[1005];
	while (cin >> n, n)
	{
		for (i = 1; i <= n; i++)
			cin >> s[i];
		dp[0] = 0;//起点初始化为0 
		s[0] = 0;
		max1 = 0;//记录所有dp[i]的最大值 
		for (i = 1; i <= n; i++)
		{
			 t = 0;//临时变量，最后存的是dp[i]的最优解 
              for (j = 0; j < i; j++)
			  {
				  if (s[j] < s[i])t = max(t, dp[j] + s[i]);//当s[j]符合要求时，更新t； 
			  }
			  dp[i] = t;//t保存的是dp[i]的最优解 
			  max1 = max(dp[i], max1);//n个dp[i]的最大值 
		}
		cout << max1 << endl;
			
	}
	return 0;
}

```
