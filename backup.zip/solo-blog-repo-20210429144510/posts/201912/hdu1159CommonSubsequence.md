title: hdu-1159 Common Subsequence
date: '2019-12-03 19:49:14'
updated: '2019-12-03 19:49:14'
tags: [acm, DP]
permalink: /articles/2019/12/03/1575373753962.html
---
题目链接：[hdu-1159](http://acm.hdu.edu.cn/showproblem.php?pid=1159)

题目大意：给出两个字符串，求最长公共子序列，不一定是连续的，顺序一样便可，经典的 lcs 问题；

思路：二维 dp，dp[i][j]代表 s1 中取 i 个字符，s2 中取 j 个字符时，两者的最长公共子序列长度，当最后一个字符相等时，s1[i]=s2[j]时，dp[i][j]=dp[i-1][[j-1]+1;最后一个字符不等时，取 s1 去掉一个字符或者 s2 去掉一个字符的最大的 dp，即 dp[i][j]=max(dp[i-1][j],dp[i][j-1]);

```c++
#include<iostream>
#include<string>
#include<cstring>
#include<algorithm>
using namespace std;
int c[1005][1005];
int main()
{
	string s1, s2;
	int i, j, k, m, t, n;
	while (cin >> s1 >> s2)
	{
		m = s1.size(); n = s2.size();
		memset(c,0,sizeof(c));
		for(i=1;i<=m;i++)//第一个字符串遍历 
			for (j = 1; j <= n; j++)//第二个字符串遍历 
			{
				//最后一个字符相等时，左上方数字加1 
				if (s1[i - 1] == s2[j - 1])c[i][j] = c[i - 1][j - 1] + 1; 
				else
				{
					c[i][j] = max(c[i - 1][j], c[i][j - 1]);//取左边或者上边的最大值 
				}
			}
		cout << c[m][n] << endl;
	}
	return 0;
}

```

最长连续公共子序列，思路与上类似

```c++
// 最长连续公共子序列
#include<bits/stdc++.h>
using namespace std;
const int N = 105;
int main() {
	string s1, s2;
	int c[N][N] = { 0 };
	int maxl = 0;
	cin >> s1 >> s2;
	int m = s1.size(), n = s2.size();
	for(int i=1;i<=m;i++)
		for (int j = 1; j <= n; j++) {
			if (s1[i - 1] == s2[j - 1])c[i][j] = c[i - 1][j - 1] + 1;
			else c[i][j] = 0;
			maxl = max(maxl, c[i][j]);
		}
	cout << maxl << endl;
}

```
