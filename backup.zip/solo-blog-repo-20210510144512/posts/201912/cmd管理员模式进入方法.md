title: cmd管理员模式进入方法
date: '2019-12-04 11:59:55'
updated: '2019-12-04 11:59:55'
tags: [windows]
permalink: /articles/2019/12/04/1575431995772.html
---
一：win+s搜cmd，以管理员模式打开

二：进入任务管理器，新建cmd，勾选下面管理员模式

三：进入带命令提示符的安全模式
