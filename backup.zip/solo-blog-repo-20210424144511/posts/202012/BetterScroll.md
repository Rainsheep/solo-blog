title: BetterScroll
date: '2020-12-20 01:45:14'
updated: '2020-12-20 01:45:14'
tags: [前端, 学习笔记]
permalink: /articles/2020/12/20/1608399914825.html
---
参考文献：

[github 地址](https://github.com/ustbhuangyi/better-scroll)
[官方文档](https://better-scroll.github.io/docs/zh-CN/)

### 1. BetterScroll 是什么

为移动端（已支持 PC）各种滚动场景提供丝滑的滚动效果。

原生滚动不流畅，用此组件保证移动端长列表滚动流畅。

### 2. 安装

```
npm install better-scroll --save
```

### 3. 简单使用

```html
<div class="wrapper">
  <ul class="content">
    <li>...</li>
    <li>...</li>
    ...
  </ul>
  <!-- 这里可以放一些其它的 DOM，但不会影响滚动 -->
</div>
```

**注意：必须有父容器 wrapper，它有固定的高度。content 中存放要滚动的内容。**

```js
import BScroll from 'better-scroll'

let bs = new BScroll('.wrapper', {
  // ...
  click: true,
  probeType: 3,
  pullUpLoad: true,
  // and so on
})
```

### 4. 配置项

#### 4.1 probeType

默认值：`0`

可选值：`1|2|3`

作用：当需要知道滚动的位置。当 probeType 为 1 的时候，会非实时（屏幕滑动超过一定时间后）派发[scroll 事件](https://better-scroll.github.io/docs/zh-CN/guide/api.html#scroll)；当 probeType 为 2 的时候，会在屏幕滑动的过程中实时的派发 scroll 事件；当 probeType 为 3 的时候，不仅在屏幕滑动的过程中，而且在 momentum 滚动动画运行过程中实时派发 scroll 事件。如果没有设置该值，其默认值为 0，即不派发 scroll 事件。

#### 4.2 click

类型：`boolean`

默认值：`false`

作用：BetterScroll 默认会阻止浏览器的原生 click 事件。当设置为 true，div 等元素可以使用 click 事件。

### 5. API

#### 5.1 方法

refresh()

参数：无

返回值：无

作用：重新计算 BetterScroll，当 DOM 结构发生变化的时候务必要调用确保滚动的效果正常。

例子：当滚动列表高度变化的时候，比如图片加载完毕，新增数据，调用此方法保证滚动正常。

#### 5.2 钩子

**pullingUp**

触发时机：当底部下拉距离超过阈值

```js
const bs = new BetterScroll('.wrapper', {
  pullUpLoad: true
})

bs.on('pullingUp', () => {
  await fetchData()
  bs.finishPullUp()
})
```

> 异步操作进行完之后，必须调用 finishPullUp 后，才可以进行二次触发

**scroll**

触发时机：正在滚动

```js
bs.on('scroll', (position) => {
  console.log(position.x, position.y)
})
```



