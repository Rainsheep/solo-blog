title: 屏幕图标显示，只显示屏保-explorer出错
date: '2019-12-04 12:00:26'
updated: '2019-12-04 12:00:26'
tags: [windows]
permalink: /articles/2019/12/04/1575432026663.html
---
explorer.exe是Windows程序管理器或者文件资源管理器，它用于管理Windows图形壳，包括桌面和文件管理。删除该程序会导致Windows图形界面无法使用。win7下为explorer.exe，win10下为windows资源管理器，在任务管理器进程中可查看。

问题：屏幕图标消失，作业没保存，win7系统

解决方法：进入任务管理器，结束进程explorer.exe->新建explorer.exe，桌面图标出现


