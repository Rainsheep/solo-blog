title: Ubuntu 安装 JDK
date: '2020-08-06 23:31:54'
updated: '2020-08-06 23:34:55'
tags: [Linux]
permalink: /articles/2020/08/06/1596727913960.html
---
参考文献：[Ubuntu安装JDK](https://www.cnblogs.com/Dylansuns/p/7599750.html?utm_medium=referral&utm_source=itdadao)

系统版本：Ubuntu 16.04

JDK版本：jdk1.8.0_144

说明：**安装 Oracle 的 JDK，不推荐开源版本 Openjdk**

1.[官网下载](https://www.oracle.com/java/technologies/javase/javase-jdk8-downloads.html)JDK文件jdk-8u144-linux-x64.tar.gz

2.解压文件到 `/usr/lib/jvm`

```
sudo mv jdk-8u121-linux-x64.tar.gz /usr/lib/jvm
tar -zxvf jdk-8u121-linux-x64.tar.gz
rm -f jdk-8u121-linux-x64.tar.gz

```

3.配置所有用户环境变量

`sudo gedit /etc/profile`

在文件的最后添加以下内容：

```
#set Java environment

export JAVA_HOME=/usr/lib/jvm/jdk1.8.144
export JRE_HOME=$JAVA_HOME/jre
export CLASSPATH=.:$JAVA_HOME/lib:$JRE_HOME/lib:$CLASSPATH
export PATH=$JAVA_HOME/bin:$JRE_HOME/bin:$PATH
```

使环境变量立即生效

`source /etc/profile`

检验是否成功

`java -version`
