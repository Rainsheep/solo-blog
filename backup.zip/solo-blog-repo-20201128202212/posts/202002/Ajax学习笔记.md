title: Ajax 学习笔记
date: '2020-02-29 15:04:18'
updated: '2020-02-29 15:04:18'
tags: [前端, 学习笔记]
permalink: /articles/2020/02/29/1582959858110.html
---
### 1. AJAX 基础知识

* 概念：ASynchronous JavaScript And XML，异步的 JavaScript 和 XML
* 异步和同步：在客户端和服务器端相互通信的基础上

  * 同步：客户端必须等待服务器端的响应。在等待的期间客户端不能做其他操作。
  * 异步：客户端不需要等待服务器端的响应。在服务器处理请求的过程中，客户端可以进行其他的操作。

  ![](https://raw.githubusercontent.com/Rainsheep/pic-bed/master/img/2020-02-29+02:04:54+1.同步和异步.bmp)
* * AJAX 是一种在无需重新加载整个网页的情况下，能够更新部分网页的技术。
  * 通过在后台与服务器进行少量数据交换，AJAX 可以使网页实现异步更新。这意味着可以在不重新加载整个网页的情况下，对网页的某部分进行更新。
  * 传统的网页（不使用 AJAX）如果需要更新内容，必须重载整个网页页面。
* 原生的 JS 实现方式（了解）

  ```jsp
  <%@ page contentType="text/html;charset=UTF-8" language="java" %>
  <html lang="zh_CN">
  <head>
      <meta charset="UTF-8">
      <title>Title</title>
      <script>
          //定义方法
          function fun() {
              //发送异步请求
              //1.创建核心对象
              var xmlhttp;
              if (window.XMLHttpRequest) {// code for IE7+, Firefox, Chrome, Opera, Safari
                  xmlhttp = new XMLHttpRequest();
              } else {// code for IE6, IE5
                  xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
              }
              //2. 建立连接
              /*
                  参数：
                      1. 请求方式：GET、POST
                          * get方式，请求参数在URL后边拼接。send方法为空参
                          * post方式，请求参数在send方法中定义
                      2. 请求的URL：
                      3. 同步或异步请求：true（异步）或 false（同步）
               */
              xmlhttp.open("GET", "./ajaxServlet?username=tom", true);
              //3.发送请求
              xmlhttp.send();
              //4.接受并处理来自服务器的响应结果
              //获取方式 ：xmlhttp.responseText
              //什么时候获取？当服务器响应成功后再获取
              //当xmlhttp对象的就绪状态改变时，触发事件onreadystatechange。
              xmlhttp.onreadystatechange = function () {
                  //判断readyState就绪状态是否为4，判断status响应状态码是否为200
                  if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                      //获取服务器的响应结果
                      var responseText = xmlhttp.responseText;
                      alert(responseText);
                  }
              }
          }
      </script>
  </head>
  <body>
  <input type="button" value="发送异步请求" onclick="fun();">
  <input type="text" name="test">
  </body>
  </html>
  ```
  * 当请求方法为 GET 的时候，参数在 URL 后面，当请求方法为 POST 的时候，参数在 send 方法参数中，只有请求的方式为 POST 的时候，send 中才能带参数。
  * readyState 为 4 的时候代表请求已完成，且响应已就绪。
  * responseText 为字符串形式的响应数据，可以赋值到 innerHTML 中。
  * 当同步的时候(open 中传参 false)，当服务端没有响应回来的时候(可 Thread.sleep)，输入框没办法输入，异步的时候，则局部更新，不影响输入框输入。
* JQeury 实现方式（掌握）

  * `$.ajax({键值对})`：发送异步请求
    * ```js
      //使用$.ajax()发送异步请求
      $.ajax({
          url:"ajaxServlet" , // 请求路径
          type:"POST" , //请求方式
          //data: "username=jack&age=23",//请求参数，字符串形式
          data:{"username":"jack","age":23},//请求参数，JSON 形式
          success:function (data) {
              alert(data);
          },//响应成功后的回调函数
          error:function () {
              alert("出错啦...")
          },//表示如果请求响应出现错误，会执行的回调函数
          dataType:"text"//设置接受到的响应数据的格式
      });
      ```
  * `$.get(url, [data], [callback], [type])`：GET 方式发送异步请求
    * url：请求路径
    * data：请求参数，可以使用 JSON 的格式
    * callback：回调函数
    * type：响应结果的类型
  * `$.post(url, [data], [callback], [type])`：POST 方式发送异步请求
* 服务器在响应数据的时候，可以使用 `resopnse.setContentType("text/html;charset=uft-8");`，来设置响应数据的类型和响应数据的编码，当不设置编码的时候，前台接收到的数据会乱码，当设置 text 类型的时候，前台接收到的为 text 文本类型，若 AJAX 请求没有指定接收数据的类型，则或接收到 text 类型的响应数据，此时没办法用 JSON 的取值办法取值(如果响应数据为 JSON 的话)，有两种解决方法。

  1. 响应数据的时候，设置 response 的 ContentType 的 MIME 类型为 `application/json` 类型
  2. 发送 AJAX 请求函数中设置  data 响应数据的类型
