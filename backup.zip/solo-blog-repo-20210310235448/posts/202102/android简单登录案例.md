title: android 简单登录案例
date: '2021-02-25 01:00:33'
updated: '2021-02-25 01:00:33'
tags: [android]
permalink: /articles/2021/02/25/1614186033356.html
---
# 1. 登录案例

**布局文件**

```xml
<RelativeLayout xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:tools="http://schemas.android.com/tools"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:paddingLeft="10dp"
    android:paddingTop="10dp"
    android:paddingRight="10dp"
    android:paddingBottom="10dp"
    tools:context=".MainActivity">

    <EditText
        android:id="@+id/et_username"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:hint="请输入用户名" />

    <EditText
        android:id="@+id/et_password"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:layout_below="@+id/et_username"
        android:hint="请输入密码"
        android:inputType="textPassword" />

    <CheckBox
        android:id="@+id/cb_isSave"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:layout_below="@+id/et_password"
        android:text="勾选保存信息" />

    <Button
        android:id="@+id/btn_login"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:layout_below="@id/et_password"
        android:layout_alignParentRight="true"
        android:text="登录" />


</RelativeLayout>
```

**Activity**

```java
public class MainActivity extends Activity {

    private EditText et_username;
    private EditText et_pwd;
    private CheckBox cb_isSave;
    private Button btn_login;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        et_username = findViewById(R.id.et_username);
        et_pwd = findViewById(R.id.et_password);
        cb_isSave = findViewById(R.id.cb_isSave);
        btn_login = findViewById(R.id.btn_login);

        btn_login.setOnClickListener(v -> {
            //当按钮被点击就会走这个方法
            // ①获取用户输入
            String pwd = et_pwd.getText().toString().trim();
            String username = et_username.getText().toString().trim();//②判断输入是否为空
            if (TextUtils.isEmpty(username) || TextUtils.isEmpty(pwd)) {
                //2.1如果为空 Toast提示用户 不能为空
                Toast.makeText(this, "用户名密码不能为空", Toast.LENGTH_SHORT).show();
            } else {
                //2.2如果不为空 判断是否保存密码
                //③ 通过checkbox的状态 判断是否保存
                boolean checked = cb_isSave.isChecked();
                if (checked) {
                    boolean saveInfo = Utils.saveInfo(username, pwd);
                    // boolean saveInfo = Utils.saveInfobycontext(this, username, pwd);
                    // boolean saveInfo = Utils.saveInfo2sdcard(username, pwd);
                    if (saveInfo) {
                        Toast.makeText(MainActivity.this, "保存成功", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(MainActivity.this, "保存失败", Toast.LENGTH_SHORT).show();
                    }
                    //勾选上了 保存用户名密码
                    Log.d("MainActivity", "保存用户名:" + username + "密码:" + pwd);
                }
                //④执行登陆的业务逻辑
                Log.d("MainActivity", "开始登陆....");
            }
        });

        //获取用户保存的信息
        String[] info = Utils.readInfo();
        // String[] info = Utils.readInfobyContext(this);
        // String[] info = Utils.readInfoFromSdCard();
        //如果返回不为空 说明有信息 显示到edittext上
        if (info != null) {
            //显示用户的信息
            et_username.setText(info[0]);
            et_pwd.setText(info[1]);
        }
    }
}
```

**Utils**

```java
package com.example.test;

import android.content.Context;
import android.os.Environment;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;

public class Utils {
    /**
     * 保存用户名密码
     *
     * @param username 用户名
     * @param pwd      密码
     * @return 是否保存成功
     */
    public static boolean saveInfo(String username, String pwd) {
        String info = username + "##" + pwd;
        File file = new File("/data/data/com.example.test/info3.txt");
        try {
            FileOutputStream fos = new FileOutputStream(file);
            fos.write(info.getBytes());
            fos.close();
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * 获取用户保存的用户名和密码
     *
     * @return 数组的第一个元素是用户名 第二个元素是密码 如果为null说明获取失败
     */
    public static String[] readInfo() {
        File file = new File("/data/data/com.example.test/info.txt");
        try {
            FileInputStream fis = new FileInputStream(file);
            BufferedReader reader = new BufferedReader(new InputStreamReader(fis));
            String temp = reader.readLine();
            String[] result = temp.split("##");
            return result;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public static boolean saveInfobycontext(Context context, String username, String pwd) {
        String info = username + "##" + pwd;
        try {
            FileOutputStream fos = context.openFileOutput("info2.txt", Context.MODE_PRIVATE);
            fos.write(info.getBytes());
            fos.close();
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }


    public static String[] readInfobyContext(Context context) {
        try {
            FileInputStream fis = context.openFileInput("info2.txt");
            BufferedReader reader = new BufferedReader(new InputStreamReader(fis));
            String temp = reader.readLine();
            String[] result = temp.split("##");
            return result;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }


    public static boolean saveInfo2sdcard(String username, String pwd) {
        String info = username + "##" + pwd;
        File file = new File("mnt/sdcard/info.txt");
        try {
            FileOutputStream fos = new FileOutputStream(file);
            fos.write(info.getBytes());
            fos.close();
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public static String[] readInfoFromSdCard() {
        File file = new File(Environment.getExternalStorageDirectory().getAbsolutePath() + "/info.txt");
        Environment.getExternalStorageState();
        ;
        try {
            FileInputStream fis = new FileInputStream(file);
            BufferedReader reader = new BufferedReader(new InputStreamReader(fis));
            String temp = reader.readLine();
            String[] result = temp.split("##");
            return result;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }

    }
}
```

> 我们一般使用 context 来对要存储的数据进行操作，很少直接写死路径。

