title: merge 和 include
date: '2021-06-26 21:28:53'
updated: '2021-06-26 21:28:53'
tags: [android]
permalink: /articles/2021/06/26/1624714133592.html
---
## 1. Include

include 可以复用组件

**普通用法**

Test.xml

```xml
<?xml version="1.0" encoding="utf-8"?>
<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"
    android:id="@+id/include_ll"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:orientation="vertical">

    <Button
        android:id="@+id/include_button"
        android:layout_width="match_parent"
        android:layout_height="match_parent" />

</LinearLayout>
```

Activity_main.xml

```xml
<include layout="@layout/test" />
```

MainActivity.java

```java
button = findViewById(R.id.include_button);
```

> 可以根据原文件 id 获取, 当原文件 id 与此文件 id 重复的时候，会取最先出现的，所以 id 不要重复

**控制大小**

```xml
<include
    layout="@layout/test"
    android:layout_width="100dp"
    android:layout_height="50dp" />
```

**可以设置 id**

```xml
<include
    android:id="@+id/include_ll"
    layout="@layout/test"
    android:layout_width="100dp"
    android:layout_height="50dp" />
```

> include 设置 id 时会替换原根标签 id, 则原根标签 id 则获取不到值

**一个界面 include 两个相同的文件怎么区分**

```xml
<include
    android:id="@+id/include_ll1"
    layout="@layout/test" />

<include
    android:id="@+id/include_ll2"
    layout="@layout/test" />
```

```java
ll1 = findViewById(R.id.include_ll1);
ll2 = findViewById(R.id.include_ll2);

button1 = ll1.findViewById(R.id.include_button);
button2 = ll2.findViewById(R.id.include_button);
```

## 2. merge

参考文献：

[Android 布局优化（merge使用）](https://blog.csdn.net/u011368551/article/details/81292820)
[Android 布局 Merge的使用](https://www.jianshu.com/p/af58200d0166)

merge 标签是用来帮助在视图树中减少重复布局的，当一个 layout include 另外一个 layout 时。

**不使用 merge 时**

Layout1.xml

```xml
<FrameLayout>
   <include layout="@layout/layout2"/>
</FrameLayout>
```

Layout2.xml

```xml
<FrameLayout>
   <TextView />
</FrameLayout>
```

实际结果

```xml
<FrameLayout>
   <FrameLayout>
      <TextView />
   </FrameLayout>
</FrameLayout>
```

**使用 merge**

Layout1.xml

```xml
<FrameLayout>
   <include layout="@layout/layout2"/>
</FrameLayout>
```

Layout2.xml

```xml
<merge>
   <TextView />
</merge>
```

实际结果

```xml
<FrameLayout>
   <TextView />
</FrameLayout>
```

* merge 必须放在布局文件的根节点上。
* merge 并不是一个 ViewGroup，也不是一个 View，它相当于声明了一些视图，等待被添加。
* merge 标签被添加到 A 容器下，那么 merge 下的所有视图将被添加到 A 容器下。
* 因为 merge 标签并不是 View，所以在通过 LayoutInflate.inflate 方法渲染的时候， 第二个参数必须指定一个父容器，且第三个参数必须为 true，也就是必须为 merge 下的视图指定一个父亲节点。
* 因为 merge 不是 View，所以对 merge 标签设置的所有属性都是无效的。

> merge 视图在 AS 中无法预览怎么办？
> 
> 使用 parentTag 指定被装在的 parent 的布局容器类型，例如 tools:parentTag="android.widget.FrameLayout"，那么就可以预览到当前布局被装在进 FrameLayout 时候的效果



