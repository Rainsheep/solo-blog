title: WebView 的简单使用
date: '2021-04-13 14:40:00'
updated: '2021-04-13 14:40:00'
tags: [android]
permalink: /articles/2021/04/13/1618296000786.html
---
```xml
<?xml version="1.0" encoding="utf-8"?>
<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="match_parent"
    android:layout_height="match_parent" >

    <WebView
        android:id="@+id/web_view"
        android:layout_width="match_parent"
        android:layout_height="match_parent" />

</LinearLayout>
```

```java
public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        WebView webView = (WebView) findViewById(R.id.web_view);
        // 让 webview 支持 js 脚本
        webView.getSettings().setJavaScriptEnabled(true);
        // 当从一个网页跳转到另一个网页时，目标网页仍在 webview 中显示，而不是打开浏览器
        webView.setWebViewClient(new WebViewClient());
        webView.loadUrl("https://www.baidu.com");
    }
}
```



