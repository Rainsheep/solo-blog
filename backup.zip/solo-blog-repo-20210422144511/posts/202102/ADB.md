title: ADB
date: '2021-02-23 19:09:18'
updated: '2021-02-23 19:09:18'
tags: [android]
permalink: /articles/2021/02/23/1614078558105.html
---
android debug bridge 安卓调试桥

`adb start-server`：开启 adb 服务

`adb kill-server`：杀死 adb 服务

`adb:reset adb`：重启 adb

`adb uninstall [-k] + 包名`：卸载应用，-k 只删除程序，不删除所用数据与缓存目录

`adb uninstall --user 0 + 包名` ：root 权限卸载软件

`adb install [-r] [-s] [-d] + apk 所在路径`：安装应用，-r 重新安装，-s 安装到 sd 卡,，-d 允许降级覆盖安装

`adb push 本地地址 sdcard/`：上传到手机

`adb pull 地址`：从手机拉下来

`adb shell`：进入设备的命令行

`adb devices`：列出所有链接的设备

**问题 1**

问题：安装 apk 出现 Failure [INSTALL_FAILED_TEST_ONLY: installPackageLI] 错误

Android Studio 3.0 会在 debug apk 的 manifest 文件 application 标签里自动添加 `android:testOnly="true"` 属性，导致 IDE 中 run 跑出的 apk 在大部分手机上只能用 `adb install -t <apk>` 来安装

解决：在 gradle.properties (项目根目录或者 gradle 全局配置目录) 文件中添加 `android.injected.testOnly=false`

