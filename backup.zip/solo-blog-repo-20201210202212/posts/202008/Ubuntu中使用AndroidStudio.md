title: Ubuntu 中使用 AndroidStudio
date: '2020-08-06 23:53:26'
updated: '2020-08-07 23:45:44'
tags: [软件教程, Linux]
permalink: /articles/2020/08/06/1596729206134.html
---
参考文献：

[ubuntu16.04安装android-studio](https://blog.csdn.net/MakerCloud/article/details/84873145)

[ubuntu 删除android studio](https://blog.csdn.net/weixin_40970506/article/details/105161586)

[Android Studio 4.0 的 gradle-6.1.1-all.zip 下载（包含其他版本）](https://blog.csdn.net/QasimCyrus/article/details/78457609)

### 安装

#### 1. 安装 JDK

参考：[Ubuntu安装JDK](https://www.rainsheep.cn/articles/2020/08/06/1596727913960.html)

检测是否成功

`java -version`

#### 2. 下载 Android studio

官网：http://www.android-studio.org/

然后解压并复制到自定义的安装目录，我的安装目录是 `/opt/android-studio`

```
tar -zxvf android-studio-ide-191.5977832-linux.tar.gz
mv android-studio /opt
```

#### 3. 安装

进入 android-studio/bin 目录 使用 studio.sh 脚本进行安装

```
cd /opt/android-studio/bin
./studio.sh
```

剩余安装步骤和Windows端相同，这里就不赘述了。

#### 4. 创建快捷方式

在AndroidStudio初始化界面点击下方的Configure按选择"Create Desktop Entry"创建桌面图标

### 卸载

直接删除即可

1. android-studio文件夹;
2. 如果sdk不在android-studio目录中，删除sdk文件夹，可能在`/home/username/Android` 中
3. 删除`~/.AndroidStudio3.5`，其中包含config和system ；
4. 删除`~/.android` ；
5. 如果创建快捷方式，删除`~/.local/share/applications/jetbrains-android-studio.desktop`

### 一直 Gradle:Build Running

找到路径 `\home\username\.gradle\wrapper\dists`，在此文件夹下有一个 gradle 版本文件夹，打开后是一个名字很长的文件夹，例如我的 `\home\Rainsheep\.gradle\wrapper\dists\gradle-6.1.1-all\6r4uqcc6ovnq6ac6s0txzcpc0` 然后下载对应版本的gradle，将下载的压缩包直接放进名字很长的文件夹中即可，不需要解压

下载地址：链接：https://pan.baidu.com/s/1kYgZAioSL-Imn8BWGVDlKQ 提取码：vbgx

### 依赖库下载慢

使用开源中国的maven库

阿里云的(速度飞快)：[http://maven.aliyun.com/nexus/content/groups/public/](http://maven.aliyun.com/nexus/content/groups/public/)

**build.gradle**

```
buildscript {
    repositories {
    //    jcenter()
    //    jcenter(){ url 'http://jcenter.bintray.com/'}
        maven{url 'http://maven.aliyun.com/nexus/content/groups/public/'}
        maven { url "https://jitpack.io" }
        google()
    }
    dependencies {  
        classpath 'com.android.tools.build:gradle:3.0.0' 
    }
}

allprojects {
    repositories {l
//        jcenter()
        maven{url 'http://maven.aliyun.com/nexus/content/groups/public/'} 
        google()
    }
}
```
