title: android StateListDrawable
date: '2021-06-25 22:44:50'
updated: '2021-06-25 22:44:50'
tags: [android]
permalink: /articles/2021/06/25/1624632290144.html
---
## 1. 介绍

StateListDrawable 可供设置的属性如下：

- drawable: 引用的 Drawable 位图,我们可以把他放到最前面,就表示组件的正常状态~
- state_focused: 是否获得焦点
- state_window_focused: 是否获得窗口焦点
- state_enabled: 控件是否可用
- state_checkable: 控件可否被勾选,eg:checkbox
- state_checked: 控件是否被勾选
- state_selected: 控件是否被选择,针对有滚轮的情况
- state_pressed: 控件是否被按下
- state_active: 控件是否处于活动状态,eg:slidingTab
- state_single: 控件包含多个子控件时,确定是否只显示一个子控件
- state_first: 控件包含多个子控件时,确定第一个子控件是否处于显示状态
- state_middle: 控件包含多个子控件时,确定中间一个子控件是否处于显示状态
- state_last: 控件包含多个子控件时,确定最后一个子控件是否处于显示状态

## 2. 基本使用

先通过 shapeDrawable 来画两个圆角矩形，只是颜色不一样而已：

shape_btn_normal.xml：

```xml
<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android"
    android:shape="rectangle">
    <solid android:color="#DD788A"/>
    <corners android:radius="5dp"/>
    <padding android:top="2dp" android:bottom="2dp"/>
</shape>
```

接着我们来写个selctor：selctor_btn.xml：

```xml
<?xml version="1.0" encoding="utf-8"?>
<selector xmlns:android="http://schemas.android.com/apk/res/android">
    <item android:state_pressed="true" android:drawable="@drawable/shape_btn_pressed"/>
    <item android:drawable="@drawable/shape_btn_normal"/>
</selector>
```

然后按钮设置 `android:background="@drawable/selctor_btn"` 就可以了~ 你可以根据自己需求改成矩形或者椭圆，圆形等

