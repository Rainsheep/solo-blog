title: Windows10暂停更新教程
date: '2019-12-04 15:03:15'
updated: '2019-12-04 15:03:31'
tags: [windows]
permalink: /articles/2019/12/04/1575442995445.html
---
时间：2019/11/10

系统：windows10 1903 版本

软件：StopUpdates10_Portable_3.1.101

链接：链接：[https://pan.baidu.com/s/1itvHr7fGbpRTHNxeSOL4ow](https://pan.baidu.com/s/1itvHr7fGbpRTHNxeSOL4ow)
提取码：tw7y

教程：打开软件，运行 StopUpdates10.exe

暂停前：

![20191110004354799.png](https://img.hacpai.com/file/2019/12/20191110004354799-f933d260.png)

打开软件，点击“暂停更新”

![20191110004435915.png](https://img.hacpai.com/file/2019/12/20191110004435915-86c7b838.png)

更改时间：

![20191110004459860.png](https://img.hacpai.com/file/2019/12/20191110004459860-465081a3.png)

效果：

![20191110004534393.png](https://img.hacpai.com/file/2019/12/20191110004534393-7e99b916.png)

![20191110004710828.png](https://img.hacpai.com/file/2019/12/20191110004710828-4ffb45be.png)
