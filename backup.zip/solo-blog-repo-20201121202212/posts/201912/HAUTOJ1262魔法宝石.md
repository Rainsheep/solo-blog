title: HAUTOJ 1262 魔法宝石
date: '2019-12-03 12:17:00'
updated: '2019-12-03 12:17:00'
tags: [acm, 水题]
permalink: /articles/2019/12/03/1575346620240.html
---
# 题目描述

小 s 想要创造 n 种魔法宝石。小 s 可以用 ai 的魔力值创造一棵第 i 种魔法宝石，或是使用两个宝石合成另一种宝石（不消耗魔力值）。请你帮小 s 算出合成某种宝石的所需的最小花费。

# 输入

第一行为数据组数 T（1≤ T≤3）。
对于每组数据，首先一行为 n,m(1≤ n,m≤10^5)。分别表示魔法宝石种类数和合成魔法的数量。
之后一行 n 个数表示 a1 到 an。(1≤ ai≤10^9)。a_i 表示合成第 i 种宝石所需的魔力值。
之后 n 行，每行三个数 a,b,c(1≤ a,b,c≤ n),表示一个第 a 种宝石和第 b 种宝石，可以合成一个第 c 种宝石。

# 输出

每组数据输出一行 n 个数，其中第 i 个数表示合成第 i 种宝石的魔力值最小花费。

# 样例输入

1
3 1
1 1 10
1 2 3

# 样例输出

1 1 2

# 题解
很简单的一道题 就是注意 需要循环N次 直到最小的不再发生变化
```c++
#include<iostream>
using namespace std;
int main()
{
    int T;
    cin>>T;
    while(T--)
    {
        int n,m,s[100005],q[100005][3],i,j,k,min[100005],sum;
        cin>>n>>m;
        for(i=1;i<=n;i++)
        {
        cin>>s[i];
        min[i]=s[i];
        }
        for(i=1;i<=m;i++)
        cin>>q[i][0]>>q[i][1]>>q[i][2];
        int o=50;  //控制循环，直到最小的不再变化 
        while(o--)
        for(i=1;i<=m;i++)
        {
            sum=min[q[i][0]]+min[q[i][1]];
            if(sum<min[q[i][2]])min[q[i][2]]=sum;
        }
        cout<<min[1];
        for(i=2;i<=n;i++)
        cout<<" "<<min[i];
        cout<<endl;
    }
    return 0; 
}

```
