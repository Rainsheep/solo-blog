title: ubuntu16.04 安装 Typora
date: '2020-09-09 12:23:32'
updated: '2020-09-09 12:23:32'
tags: [Linux, 软件教程]
permalink: /articles/2020/09/09/1599625412585.html
---
```
# or use
# sudo apt-key adv --keyserver keyserver.ubuntu.com --recv-keys BA300B7755AFCFAE
wget -qO - https://typora.io/linux/public-key.asc | sudo apt-key add -

# add Typora's repository
sudo add-apt-repository 'deb https://typora.io/linux ./'
sudo apt-get update

# install typora
sudo apt-get install typora
```
