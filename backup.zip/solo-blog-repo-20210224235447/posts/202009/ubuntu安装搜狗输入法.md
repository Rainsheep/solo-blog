title: ubuntu 安装搜狗输入法
date: '2020-09-09 12:32:27'
updated: '2020-09-09 12:32:27'
tags: [Linux, 软件教程]
permalink: /articles/2020/09/09/1599625947420.html
---
> 系统：Ubuntu 16.04

* 下载sogoupinyin 链接：https://pan.baidu.com/s/1QENgpPJ3bTQ2Fy7DD9vu-g 密码：hl9v
* 双击安装
* 输入源为Sunpinyin(Fcitx)
* 系统设置→文本输入→输入法配置图标
* 将输入法设置为两个。键盘-英语(美国)和搜狗拼音，搜狗拼音不要放在第一个，防止输入时乱码![image.png](https://b3logfile.com/file/2020/09/image-dde7754e.png)
