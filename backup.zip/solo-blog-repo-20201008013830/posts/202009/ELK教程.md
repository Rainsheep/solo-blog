title: ELK 教程
date: '2020-09-14 19:28:52'
updated: '2020-09-14 19:29:32'
tags: [服务器]
permalink: /articles/2020/09/14/1600082932730.html
---
参考文献：

[ELK快速入门教程](https://www.jianshu.com/p/441298d8a9f6)

[搭建ELK日志分析平台 - 2020年7月最新版](https://blog.csdn.net/u012383839/article/details/106988402)

[ubuntu16.04 快速搭建ELK日志分析平台](https://blog.csdn.net/change_on/article/details/84182693)

[官网文献](https://www.elastic.co/guide/index.html)

> 系统版本：Ubuntu 16.04

### ELK 简介

* ElasticSearch: 负责数据的存储、处理
* LogStash、FileBeats: 负责数据的收集
* Kibana: 提供了可视化操作
* 详细介绍请看参考文献
* 流程![20181117123032314.jpg](https://b3logfile.com/file/2020/09/20181117123032314-10d6070d.jpg)

### 安装前提

* 非 root 用户
* 拥有 jdk 环境
* ElasticSearch、 LogStash、 Kibana三者的版本一定要匹配，版本对不上会报错。

### 安装 ElasticSearch

```bash
# 下载elasticsearch的tar.gz压缩包
wget https://artifacts.elastic.co/downloads/elasticsearch/elasticsearch-7.９.1-linux-x86_64.tar.gz
# 解压
tar -xzf elasticsearch-7.９.1-linux-x86_64.tar.gz
# 跳转到elasticsearch安装目录
cd elasticsearch-7.９.1/
# 启动
./bin/elasticsearch
# 验证ElasticSearch是否正常运行，返回正确　json 即为启动成功
curl localhost:9200
```

### 安装 LogStash 和 FileBeats

* 下载 filebeats

  ```bash
  # 下载 filebeats
  wget https://artifacts.elastic.co/downloads/beats/filebeat/filebeat-7.9.1-linux-x86_64.tar.gz
  # 解压
  tar -zxvf filebeat-7.9.1-linux-x86_64.tar.gz
  # 切换到filebeat目录
  cd filebeat-7.9.1-linux-x86_64
  ```
* 配置 filebeat

  ```bash
  # 编辑filebeat配置文件
  vim filebeat.yml
  # 配置filebeat的输入为log文件
  filebeat.inputs:
  - type: log
    enabled: true
    paths:
      - /home/rainsheep/manuallog/manual.log 

  # 配置filebeat的输出为logstash
  output.logstash:
    hosts: ["localhost:5044"]
  ```
* 启动 filebeat

  ```bash
  ./filebeat -e -c filebeat.yml
  ```
* 下载 logstash

  ```bash
  # 下载
  wget https://artifacts.elastic.co/downloads/logstash/logstash-7.9.1.tar.gz
  # 解压
  tar -zxvf logstash-7.9.1.tar.gz
  # 跳转到logstash目录
  cd logstash-7.9.1
  ```
* 配置 logstash

  ```
  cd config
  vim logstash.conf
  配置如下
  input {
    beats {
      port => 5044
    }
  }

  filter {
  }

  output {
    elasticsearch {
      hosts => ["http://localhost:9200"]
      index => "%{[@metadata][beat]}-%{[@metadata][version]}-%{+YYYY.MM.dd}"
      #user => "elastic"
      #password => "changeme"
    }
  }
  ```
* 启动 logstash

  ```bash
  ../bin/logstash -f logstash.conf 
  ```

### 安装 Kibana

* 安装

  ```bash
  # 下载
  wget https://artifacts.elastic.co/downloads/kibana/kibana-7.9.1-linux-x86_64.tar.gz
  # 解压kibana-7.9.1-linux-x86_64.tar.gz
  tar -zxvf 
  # 跳转到kibana安装目录
  cd kibana-7.9.1
  ```
* 配置 kibana

  ```bash
  cd config
  vim kibana.yml
  # 配置如下
  # 端口
  server.port: 5601
  # 指定本机ip让外部能访问
  server.host: "0.0.0.0"
  # 请求数据指向的elasticsearch服务器
  elasticsearch.hosts: ["http://localhost:9200"]
  # 设置为中文
  i18n.locale: "zh-CN"
  ```
* 启动 kibana

  ```bash
  cd ../bin
  ./kibana
  ```
* 测试，访问 `ip:5601`
